import argparse
import configparser
import dataclasses
import json
import logging
import os
import shutil
import tempfile

import beautifultable
import smart_open as so
import yaml

from . import aws_utils as au
from . import tdp, utility

logger = logging.getLogger("tdp_scan")

@dataclasses.dataclass
class ArchitectureConfig:
    architecture: str
    baremetal_trace: bool


@dataclasses.dataclass
class Trace:
    name: str
    path: str
    files: list[str]


@dataclasses.dataclass
class Bundle:
    name: str
    path: str
    traces: list[Trace]
    pmap_file: str = ''
    tasks_file: str = ''
    mappings_file: str = ''
    tasks_dir: str = ''
    coresight: bool = False

@dataclasses.dataclass
class Architecture:
    name: str
    path: str
    bins: list[str]
    buns: list[Bundle]
    arch: str
    bare: bool


@dataclasses.dataclass
class Version:
    name: str
    path: str
    arcs: list[Architecture]


@dataclasses.dataclass
class Project:
    name: str
    path: str
    vers: list[Version]


@dataclasses.dataclass
class FlatConfig:
    project: Project
    version: Version
    architecture: Architecture
    bundle: Bundle
    trace: Trace

    def unique_identifier(self):
        data_output_base = f'{self.project.name}_{self.version.name}_{self.architecture.name}_{self.bundle.name}'
        return f'{data_output_base}/' if self.bundle.coresight or not self.trace else f'{data_output_base}_{self.trace.name}/'


class Scanner:
    def __init__(self, root_dir: str, show_all: bool = False):
        self.root_dir = root_dir
        self.show_all = show_all

    def scan(self) -> list[Project]:
        return self.scan_projects()

    def rel_path(self, path: str) -> str:
        return os.path.relpath(au.Path.abspath(path), self.root_dir)

    def display_path(self, path: str) -> str:
        return au.Path.abspath(path)

    @staticmethod
    def parse_config(file_uri: str) -> ArchitectureConfig:
        c = ArchitectureConfig(architecture='', baremetal_trace=False)
        if au.Path.is_file(file_uri):
            config = configparser.ConfigParser()
            with so.open(file_uri) as f:
                config.read_file(f)
                section_name = 'trace'
                if config.has_section(section_name):
                    c.architecture = config.get(section_name, 'Architecture', fallback='')
                    c.baremetal_trace = config.getboolean(section_name, 'Baremetal', fallback=False)
        return c

    @staticmethod
    def check_tasks_dir(directory: str) -> str:
        if tdp.TraceDataProcessor.get_task_maps_filenames(directory):
            for filename, _, _ in au.Path.list_files(directory, dirs=False, files=True):
                if filename == 'tasks.txt':
                    return directory
        return ''

    def scan_bins(self, directory: str) -> list[str]:
        bins: list[str] = []
        for filename, filepath, is_dir in au.Path.list_files(directory):
            if is_dir:
                if filename != '.cache':
                    bins.extend(self.scan_bins(filepath))
                continue
            if utility.is_elf_file(filepath):
                bins.append(self.display_path(filepath))
        return bins

    def scan_trace_files(self, directory: str) -> list[str]:
        files: list[str] = []
        for filename, filepath, is_dir in au.Path.list_files(directory):
            if is_dir or filename.endswith('.ad'):
                # if is_dir, this is coresight bundle
                files.append(self.display_path(filepath))
        return files

    def scan_traces(self, directory: str, include_traces: list[str] = None) -> list[Trace]:
        traces: list[Trace] = []
        for filename, filepath, is_dir in au.Path.list_files(directory):
            scan_traces = include_traces is None or filepath in include_traces
            if not scan_traces:
                continue
            if is_dir:
                path = self.display_path(filepath)
                files = self.scan_trace_files(filepath)
                if self.show_all or files:
                    traces.append(Trace(name=filename, path=path, files=files))
                else:
                    logger.debug(f'discarding: {filepath}. no files')
            elif filename.endswith('.ad'):
                logger.warning(f'trace file at the root: {filepath}')
        return traces

    def scan_bundles(self, directory: str, include_traces: list[str] = None) -> list[Bundle]:
        buns: list[Bundle] = []
        for filename, filepath, _ in au.Path.list_files(directory, dirs=True, files=False):
            proc_dir: str = 'proc'
            tasks: str = au.Path.abspath(au.Path.join(filepath, proc_dir, 'target_qnx_tasks.txt'))
            pmap: str = au.Path.abspath(au.Path.join(filepath, proc_dir, 'target_processes.pmap.txt'))
            maps: str = au.Path.abspath(au.Path.join(filepath, proc_dir, 'target_processes.mappings.txt'))
            tasks = self.display_path(tasks) if au.Path.exists(tasks) else ''
            pmap = self.display_path(pmap) if au.Path.exists(pmap) else ''
            maps = self.display_path(maps) if au.Path.exists(maps) else ''
            path = self.display_path(filepath)
            traces = self.scan_traces(au.Path.abspath(au.Path.join(filepath, 'traces/')), include_traces)
            tasks_dir = self.check_tasks_dir(au.Path.abspath(au.Path.join(filepath, 'tasks/')))
            coresight = not au.Path.contains_ext(path, ".ad")
            if not self.show_all:
                if not traces:
                    logger.debug(f'discarding: {filepath}. no traces')
                    continue
                # either all should be set or none
                if not bool(pmap) == bool(tasks) == bool(maps):
                    logger.debug(f'discarding: {filepath}. inconsistent maps')
                    continue
            buns.append(Bundle(name=filename, path=path, pmap_file=pmap, tasks_file=tasks,
                                mappings_file=maps, traces=traces, tasks_dir=tasks_dir, coresight=coresight))
        return buns

    def scan_architectures(self, directory: str, include_traces: list[str] = None) -> list[Architecture]:
        architectures: list[Architecture] = []
        for filename, filepath, _ in au.Path.list_files(directory, dirs=True, files=False):
            bins = self.scan_bins(au.Path.abspath(au.Path.join(filepath, 'Bins/')))
            buns = self.scan_bundles(au.Path.abspath(au.Path.join(filepath, 'Data/')), include_traces)
            config = self.parse_config(au.Path.abspath(au.Path.join(filepath, 'config.ini')))
            arch = config.architecture
            bare = config.baremetal_trace
            path = self.display_path(filepath)
            if self.show_all or (bins and buns):
                architectures.append(Architecture(name=filename, path=path, bins=bins, buns=buns, arch=arch, bare=bare))
            else:
                logger.debug(f'discarding: {filepath}. no bins or buns')
        return architectures

    def scan_versions(self, directory: str, include_traces: list[str] = None) -> list[Version]:
        versions: list[Version] = []
        for filename, filepath, _ in au.Path.list_files(directory, dirs=True, files=False):
            path = self.display_path(filepath)
            architectures = self.scan_architectures(filepath, include_traces)
            if self.show_all or architectures:
                versions.append(Version(name=filename, path=path, arcs=architectures))
            else:
                logger.debug(f'discarding: {filepath}. no architectures')
        return versions

    def scan_projects(self, include_traces: list[str] = None) -> list[Project]:
        directory: str = self.root_dir
        projects: list[Project] = []
        for filename, filepath, _ in au.Path.list_files(directory, dirs=True, files=False):
            path = self.display_path(filepath)
            versions = self.scan_versions(filepath, include_traces)
            if self.show_all or versions:
                projects.append(Project(name=filename, path=path, vers=versions))
            else:
                logger.debug(f'discarding: {filepath}. no versions')
        return projects


def export_configuration(fc: FlatConfig, onguard: str, filename: str = ''):
    if not filename:
        filename = f'{fc.project.name}_{fc.version.name}_{fc.architecture.name}_{fc.bundle.name}_{fc.trace.name}.yml'
    if os.path.isfile(filename):
        logger.warning(f'overwriting: {filename}')
    else:
        logger.warning(f'generating : {filename}')
        print(f'exporting: {filename}')
    d = {
        'onguard': onguard,
        'proc_map': {
            'elf_dirs': sorted(set([au.Path.dirname(x) for x in fc.architecture.bins]))
        }
    }
    if fc.architecture.arch:
        d['architecture'] = fc.architecture.arch
    if fc.architecture.bare:
        d['baremetal_trace'] = True
    if fc.bundle.coresight:
        d['coresight_trace'] = True
    if fc.bundle.pmap_file:
        d['proc_map']['target_pmap_file'] = fc.bundle.pmap_file
    if fc.bundle.tasks_file:
        d['proc_map']['target_tasks_file'] = fc.bundle.tasks_file
    if fc.bundle.mappings_file:
        d['proc_map']['target_mappings_file'] = fc.bundle.mappings_file
    if fc.bundle.tasks_dir:
        d['proc_map']['task_maps_directory'] = fc.bundle.tasks_dir
    print(json.dumps(d, indent=2))
    with open(filename, 'w', encoding='utf8') as yaml_file:
        yaml.dump(d, yaml_file)


def export_configurations(configs: list[FlatConfig], config_numbers: list[int], onguard: str):
    if not onguard:
        raise ValueError('onguard path not set')
    if not os.path.isfile(onguard):
        raise RuntimeError(f'onguard file does not exist: {onguard}')
    for i in config_numbers:
        if 0 <= i < len(configs):
            export_configuration(configs[i], onguard)
            continue
        raise ValueError(f'invalid configuration number: {i}')


def process_configurations(configs: list[FlatConfig], config_numbers: list[int], onguard: str, output: str, filter_functions: bool,
                           analyse: bool, keep_temp: bool, temp_dir: str, clean: bool, recache: bool, recache_lite: bool = False,
                           process_traces: bool = True, log_level: int = None, raise_exception: bool = False, include_elfs: list[str] = []):
    if log_level is not None:
        logger.setLevel(log_level)
    logger.info(f'process_configurations: {config_numbers}. output: {output}')

    if not keep_temp and output and os.path.isdir(output):
        au.Path.rmtree(output)

    tdp_logger = logging.getLogger('tdp')
    tdp_logger.setLevel(logger.level)
    for i in config_numbers:
        fc = configs[i]
        data_output_name = fc.unique_identifier()

        out_lite: str = (
            au.to_uri(au.Path.join(output, 'AD', data_output_name))
        ) if filter_functions and output else None

        out_full: str = (
            au.to_uri(au.Path.join(output, 'LCLM', data_output_name) if out_lite
            else au.Path.join(output, data_output_name))
        ) if output else None

        out_temp: str = (
            os.path.abspath(temp_dir) if temp_dir
            else (
                os.path.join(output, 'temp', data_output_name) if output
                else tempfile.TemporaryDirectory(delete=False).name
            )
        )

        if out_lite:
            au.Path.makedirs(out_lite, exist_ok=keep_temp)
        au.Path.makedirs(out_full, exist_ok=True)
        os.makedirs(out_temp, exist_ok=True)

        cfg_path = os.path.join(out_temp, 'config.yml')
        export_configuration(fc, onguard, cfg_path)

        trace_files = fc.trace.files if (fc.trace and fc.trace.files) else [None]
        for trace_file in trace_files:
            tdp.process(config_path=cfg_path,
                        trace_file=trace_file,
                        out_lite=out_lite,
                        out_full=out_full,
                        temp_dir=out_temp,
                        keep_empty=False,
                        analyse=analyse,
                        filter_functions=filter_functions,
                        jobs=1,
                        clean=clean,
                        dryrun=False,
                        recache=recache,
                        recache_lite=recache_lite,
                        keep_temp=True,
                        show_progress=True,
                        log=tdp_logger,
                        process_traces=process_traces and bool(output),
                        include_elfs=include_elfs,
                        raise_exception=raise_exception)

        if not keep_temp and os.path.isdir(out_temp):
            shutil.rmtree(out_temp)

    logger.info('Done')

def get_formatted_size_string(size: int) -> str:
    kb = 1024
    mb = kb * kb
    gb = mb * kb
    if size > gb:
        return f'{(size / gb):.02f} GB'
    if size > mb:
        return f'{(size / mb):.02f} MB'
    if size > kb:
        return f'{(size / kb):.02f} KB'
    return f'{size} B'

def get_file_size(filename: str) -> int:
    return os.stat(filename).st_size

def get_directory_size(directory: str) -> int:
    size: int = 0
    for filename in os.listdir(directory):
        if filename.endswith('.flag'):
            continue
        if filename.endswith('.flag.metadata'):
            continue
        filepath = f'{directory}/{filename}'
        if  os.path.isfile(filepath):
            size += get_file_size(filepath)
    return size

def get_total_file_size_str(trace: Trace) -> str:
    total_size: int = 0
    for uri in trace.files:
        file = au.to_file(uri)
        if isinstance(file, au.LocalFile):
            if os.path.isfile(file.path):
                total_size += get_file_size(file.path)
            elif os.path.isdir(file.path):
                total_size += get_directory_size(file.path)
        else:
            total_size = -1
            break
    return 'N/A' if total_size < 0 else get_formatted_size_string(total_size)

def print_configurations(configs: list[FlatConfig]):
    row_number: int = 0
    table = beautifultable.BeautifulTable(default_alignment=beautifultable.ALIGN_RIGHT, detect_numerics=False)
    table.columns.header = ['#', 'project', 'version', 'arch', 'bundle', 'cs', 'trace', 'files', 'size']
    table.set_style(beautifultable.STYLE_COMPACT)
    table.maxwidth = 200
    for c in configs:
        n = len(c.trace.files)
        s = get_total_file_size_str(c.trace)
        cs = '✓' if c.bundle.coresight else ' '
        r = [row_number, c.project.name, c.version.name, c.architecture.name, c.bundle.name, cs, c.trace.name, n, s]
        table.rows.append(r)
        row_number += 1
    print(table)


def scan_project(show_all: bool, project: Project, log_level: int = None, include_traces: list[str] = None) -> list[FlatConfig]:
    if log_level is not None:
        logger.setLevel(log_level)

    scanner = Scanner(root_dir='', show_all=show_all)
    project.vers = scanner.scan_versions(project.path, include_traces)
    if not show_all and not project.vers:
        return []

    configs: list[FlatConfig] = []
    for version in project.vers:
        for arch in version.arcs:
            for bun in arch.buns:
                for trace in (bun.traces or [None]):
                    configs.append(FlatConfig(project, version, arch, bun, trace))
    return configs


def scan(root: str, show_all: bool, log_level: int = None):
    if log_level is not None:
        logger.setLevel(log_level)

    projects = Scanner(root, show_all).scan()
    logger.info(f'projects: {len(projects)}')

    configs: list[FlatConfig] = []
    for project in projects:
        for version in project.vers:
            for arch in version.arcs:
                for bun in arch.buns:
                    for trace in (bun.traces or [None]):
                        configs.append(FlatConfig(project, version, arch, bun, trace))
    return configs


def main(args):
    root: str = args.root
    configs = scan(root=root, show_all=args.all)

    if not args.configs:
        print_configurations(configs)
    elif args.export:
        export_configurations(configs, args.configs, args.onguard)
    else:
        process_configurations(configs, args.configs, args.onguard, args.output, args.filter, args.analyse, args.keep_temp, args.temp_dir, args.clean, recache=False)


def parse_args():
    parser = argparse.ArgumentParser(prog='tdp_scan', description='Trace Data Processor Scanner')
    parser.add_argument('root', help='Trace root directory')
    parser.add_argument('-a', '--all', action='store_true', help='Show all configurations')
    parser.add_argument('-g', '--onguard', help='Path to the onguard executable')
    parser.add_argument('-c', '--configs', type=int, nargs='+', help='Configurations to process')
    parser.add_argument('-o', '--output', type=str, help='Output directory for processing')
    parser.add_argument('-m', '--keep-temp', action='store_true', help='Keep temporary data')
    parser.add_argument('-f', '--filter', type=bool, action=argparse.BooleanOptionalAction,
                        default=True, help='If enabled data will be filtered (only user-code functions). If disabled, lite data output will be skipped.')
    parser.add_argument('-n', '--analyse', type=bool, action=argparse.BooleanOptionalAction,
                        default=True, help='If enabled, binary will be fully statically analysed. This will additionally dump callgraphs, segments and blocks.')
    parser.add_argument('-l', '--log', choices=['debug', 'info', 'warning', 'error', 'critical'],
                        default='warning', help='Logging level', type=lambda s: s.lower())
    parser.add_argument('--clean', action='store_true', help='Clean output directory')
    parser.add_argument('--temp-dir', type=str, help='Temporary directory')
    parser.add_argument('--export', action='store_true', help='Export configuration')
    return parser.parse_args()


if __name__ == '__main__':
    main_args = parse_args()
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(name)-7s | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S", force=True)
    logger.setLevel(main_args.log.upper())
    main(main_args)
