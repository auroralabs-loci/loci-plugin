"""Module providing a cli for tdp and asmslicer."""

import argparse
import logging
import os
import shutil
import sys
import tempfile
import urllib.parse
from pathlib import Path

from lief import parse as lief_parse
from lief.ELF import Binary

from . import asmslicer, elfgen, elfsym, elfsymres, utility
from . import aws_utils as au

DEPS_INFO_JSON_FILE_NAME = "deps-info.json"
GEN_ELF_FOR_STRIPPED_ELF = False

# pylint: disable=broad-exception-caught
try:
    from loci_base.logging import (
        configure_structured_logging,  # pyright: ignore[reportMissingImports]
    )
    configure_structured_logging()
except ImportError:
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s', datefmt="%H:%M:%S")

logger: logging.Logger = logging.getLogger('tdp-cli')


def download_file(uri: str, temp_dir: str, copy_local: bool = False) -> au.LocalFile:
    try:
        f = au.to_file(uri)
        if isinstance(f, au.LocalFile):
            if not copy_local:
                _, is_stripped = utility.get_elf_info(f.path)
                copy_local = is_stripped
            return au.LocalFile(path=shutil.copy(src=f.path, dst=temp_dir)) if copy_local else f
        if isinstance(f, au.S3File):
            return au.download_file_s3(f, temp_dir, logger=logger)
        raise RuntimeError("invalid file instance")
    except Exception as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.INTERNAL_ERROR, message=f'downloading file failed: {e}')


def upload_files(src_dir: str, dst: str, move_local: bool, skip_files: list[au.LocalFile]):
    try:
        d = au.to_file(dst)
        is_dest_local = isinstance(d, au.LocalFile)
        if is_dest_local and not os.path.isdir(d.path):
            if move_local:
                shutil.move(src=src_dir, dst=d.path)
                return
            os.makedirs(d.path)
        for filename in os.listdir(src_dir):
            filepath = os.path.normpath(os.path.abspath(os.path.join(src_dir, filename)))
            if [file for file in skip_files if file.path == filepath]:
                continue
            if is_dest_local and move_local:
                shutil.move(src=filepath, dst=d.path)
            elif is_dest_local:
                shutil.copy(src=filepath, dst=d.path)
            elif isinstance(d, au.S3File):
                s3f = au.S3File(bucket=d.bucket, key=os.path.join(d.key, filename))
                au.upload_file_s3(src=au.LocalFile(path=filepath), dst=s3f)
    except Exception as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.INTERNAL_ERROR, message=f'uploading file failed: {e}')


def ensure_elf_exists(elf: str):
    if not os.path.isfile(elf):
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.BAD_INPUT_ERROR, message=f'file not found: {elf}')
    if not utility.is_elf_file(elf):
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.BAD_INPUT_ERROR, message=f'file is not elf: {elf}')


def preprocess_elf(elf_file: au.LocalFile, zf_mode: bool, architecture: str, filter_functions: bool, show_progress: bool) -> au.LocalFile:
    try:
        if zf_mode:
            num_patched: int = 0
            binary: Binary = lief_parse(elf_file.path)
            def callback_fn(es_original_symbol_addr, es_symbol: elfsym.Symbol):
                nonlocal num_patched, binary
                if es_original_symbol_addr != es_symbol.addr:
                    found: bool = False
                    for ss in binary.symtab_symbols:
                        if ss.value == es_original_symbol_addr:
                            ss.value = es_symbol.addr
                            num_patched += 1
                            found = True
                            break
                    prefix = '+' if found else '-'
                    logger.debug(f'{prefix} patch. {es_original_symbol_addr:08x} -> {es_symbol.addr:08x}  {es_symbol.name}')
            elfsym.process_file(elf_file.path, silent=True, callback=callback_fn)
            if num_patched > 0:
                os.remove(elf_file.path)
                binary.write(elf_file.path)
        if GEN_ELF_FOR_STRIPPED_ELF:
            _, is_stripped = utility.get_elf_info(elf_file.path)
            if is_stripped:
                with tempfile.NamedTemporaryFile() as sym_temp_file:
                    sym_filepath = sym_temp_file.name
                    asmslicer.process(elf_file_path = elf_file.path,
                                    out_sym_map_file = sym_filepath,
                                    filter_functions = filter_functions,
                                    architecture = architecture,
                                    show_progress = show_progress,
                                    log = logger)
                    if os.path.isfile(sym_filepath):
                        gen_path = elf_file.path + '.elf.gen'
                        elfgen.generate_with_sym_csv(elf_file=elf_file.path, csv_file=sym_filepath, out_file=gen_path, log=logger)
                        elf_file.path = gen_path
        return elf_file
    except asmslicer.ASMSlicerException:
        raise
    except Exception as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.INTERNAL_ERROR, message=f'elf pre-processing failed: {e}')

def do_diff(elf1: str, elf2: str, arc: str, out: str, zf_mode: bool, compress_out_csv: bool, filter_functions: bool, show_progress: bool):
    try:
        logger.info('diff: %s vs %s', elf1, elf2)
        logger.info('out: %s', out)
        with tempfile.TemporaryDirectory() as temp_dir_o, tempfile.TemporaryDirectory() as temp_dir_c:
            # if elf1 or elf2 is local, use it directly
            # otherwise, download it into the temp directory and use that
            out_dir = os.path.join(temp_dir_o, 'output')
            os.makedirs(out_dir)
            file_1 = download_file(uri=elf1, temp_dir=temp_dir_o, copy_local=zf_mode)
            file_2 = download_file(uri=elf2, temp_dir=temp_dir_c, copy_local=zf_mode)
            file_1 = preprocess_elf(elf_file=file_1, zf_mode=zf_mode, architecture=arc, filter_functions=filter_functions, show_progress=show_progress)
            file_2 = preprocess_elf(elf_file=file_2, zf_mode=zf_mode, architecture=arc, filter_functions=filter_functions, show_progress=show_progress)
            ensure_elf_exists(file_1.path)
            ensure_elf_exists(file_2.path)
            asmslicer.process(elf_file_path = file_1.path,
                              comparing_elf_file_path = file_2.path,
                              compare_out = out_dir,
                              filter_functions = filter_functions,
                              compress_out_csv = compress_out_csv,
                              show_progress = show_progress,
                              log = logger)
            # clean up the output
            for filename in os.listdir(out_dir):
                if not filename.endswith(('.diff.csv', '.diff.csv.gz')):
                    os.remove(os.path.join(out_dir, filename))
            upload_files(src_dir=out_dir, dst=out, move_local=True, skip_files=[file_1, file_2])
    except asmslicer.ASMSlicerException:
        raise
    except Exception as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.INTERNAL_ERROR, message=f'diff failed: {e}')


def do_slice(elf: str, arc: str | None, dot: bool, seg: bool, blc: bool, sym: bool, var: bool, asm: bool, out: str,
             zf_mode: bool, compress_out_csv: bool, filter_functions: bool, deps_info: bool, use_angr: bool | None,
             show_progress: bool, deps_path: str | None):
    try:
        if not any((dot, seg, blc, sym, var)):
            dot = seg = blc = sym = var = True

        logger.info('slice: %s. arc: %s. dot: %d. seg: %d. blc: %d. sym: %d. var: %d. asm: %d',
                    elf, arc, dot, seg, blc, sym, var, asm)
        logger.info('out: %s', out)

        elf_filename = os.path.basename(urllib.parse.urlparse(elf).path)
        dot_filename = f'{elf_filename}.callgraph.dot' if dot else ''
        seg_filename = f'{elf_filename}.segments.csv' if seg else ''
        blc_filename = f'{elf_filename}.blocks.csv' if blc else ''
        sym_filename = f'{elf_filename}.symmap.csv' if sym else ''
        var_filename = f'{elf_filename}.vars.csv' if var else ''
        asm_filename = f'{elf_filename}.asm' if asm else ''
        elfinfo_filename = f'{elf_filename}.elfinfo.csv'
        deps_path = out if not deps_path else deps_path
        deps_filepath = (deps_path + DEPS_INFO_JSON_FILE_NAME) if deps_info else ''

        out = out.rstrip('/')
        if not au.Path.is_s3(out) and not au.Path.exists(out):
            os.makedirs(out)

        with tempfile.TemporaryDirectory() as temp_dirpath:
            elf_file = download_file(uri=elf, temp_dir=temp_dirpath, copy_local=zf_mode)
            elf_file = preprocess_elf(elf_file=elf_file, zf_mode=zf_mode, architecture=arc, filter_functions=filter_functions, show_progress=show_progress)

            ensure_elf_exists(elf_file.path)

            dot_filepath = os.path.join(out, dot_filename) if dot_filename else ''
            seg_filepath = os.path.join(out, seg_filename) if seg_filename else ''
            blc_filename = os.path.join(out, blc_filename) if blc_filename else ''
            sym_filepath = os.path.join(out, sym_filename) if sym_filename else ''
            var_filepath = os.path.join(out, var_filename) if var_filename else ''
            asm_filepath = os.path.join(out, asm_filename) if asm_filename else ''
            elfinfo_filepath = os.path.join(out, elfinfo_filename) if elfinfo_filename else ''
            # deps_filepath = os.path.join(out, deps_filename) if deps_filename else ''

            asmslicer.process(elf_file_path = elf_file.path,
                                output_file_path = seg_filepath,
                                blocks_file_path = blc_filename,
                                out_sym_map_file = sym_filepath,
                                out_vars_file = var_filepath,
                                out_plot_file = dot_filepath,
                                out_elfinfo_file = elfinfo_filepath,
                                out_asm_file = asm_filepath,
                                filter_functions = filter_functions,
                                compress_out_csv = compress_out_csv,
                                architecture = arc,
                                deps_info_file = deps_filepath,
                                use_angr = use_angr,
                                show_progress = show_progress,
                                log = logger)

    except asmslicer.ASMSlicerException:
        raise
    except Exception as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.INTERNAL_ERROR, message=f'slice failed: {e}')


def parse_args():
    try:
        parser = argparse.ArgumentParser(prog='tdp-cli')
        subparsers = parser.add_subparsers(required=True, title='subcommands', dest='command')
        # diff subparser
        parser_diff = subparsers.add_parser('diff', help='diff - find differences between two elfs')
        parser_diff.add_argument('elf1', type=str, help='1st elf to compare')
        parser_diff.add_argument('elf2', type=str, help='2nd elf to compare')
        parser_diff.add_argument('out', type=str, help='output directory')
        parser_diff.add_argument('--architecture', required=False, help='machine architecture')
        parser_diff.add_argument('--zf', action='store_true', help='ZF ELF mode')
        parser_diff.add_argument('--compress-out-csv', help='Enables compressed csv output for bindiff results', action='store_true', default=False)
        parser_diff.add_argument('--filter-functions', help='Filter functions', action='store_true', default=False)
        # slice subparser
        parser_slice = subparsers.add_parser('slice', help='slice - elf analysis and slicing')
        parser_slice.add_argument('elf', type=str, help='elf file')
        parser_slice.add_argument('out', type=str, help='output directory')
        parser_slice.add_argument('--architecture', required=False, help='machine architecture')
        parser_slice.add_argument('--callgraph', action='store_true', help='generate callgraph dot file')
        parser_slice.add_argument('--segments', action='store_true', help='generate segments csv file')
        parser_slice.add_argument('--blocks', action='store_true', help='generate blocks csv file')
        parser_slice.add_argument('--symmap', action='store_true', help='generate symmap csv file')
        parser_slice.add_argument('--vars', action='store_true', help='generate vars csv file')
        parser_slice.add_argument('--asm', action='store_true', help='generate asm file')
        parser_slice.add_argument('--zf', action='store_true', help='ZF ELF mode')
        parser_slice.add_argument('--compress-out-csv', help='Enables compressed csv output for slice data, symbol maps and var list', action='store_true', default=False)
        parser_slice.add_argument('--filter-functions', help='Filter functions', action='store_true', default=False)
        parser_slice.add_argument('--deps-info', action='store_true', default=False, help='Use deps-info.json file containing symbol dependency info')
        parser_slice.add_argument('--deps-path', required=False, help='path wwhere deps-info.json file is located')
        parser_slice.add_argument('--use-angr', action=argparse.BooleanOptionalAction, default=None, help='Use angr for processing')
        # deps subparser
        parser_deps = subparsers.add_parser('deps', help='deps - ELF Symbol Resolver')
        parser_deps.add_argument('--input', type=str, help='An input folder containing all ELFs and related binaries OR version-config.json file')
        parser_deps.add_argument('--output', type=str, help='An output folder where the deps-info.json file is to be stored in', default=DEPS_INFO_JSON_FILE_NAME)
        parser_deps.add_argument('--pregenerated', help='Path to directory where pre-generated data for dependencies resides.', type=str, default='')
        # main parser
        parser.add_argument('-p', '--progress', action='store_true', help='Show progress')
        parser.add_argument('-l', '--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                            default='INFO', help='Logging level', type=lambda s: s.upper())
        return parser.parse_args()
    except Exception as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.INTERNAL_ERROR, message=f'parsing arguments failed: {e}')


def do_deps(input_path: str, output: str, pregenerated: str):
    if output.endswith('/'):
        output = output.rstrip('/')

    if Path(output).suffix.lower() != '.json':
        output = f'{output}/{DEPS_INFO_JSON_FILE_NAME}'

    try:
        elfsymres.process(path=input_path, out_file=output, pregenerated=pregenerated)
    except FileNotFoundError as e:
        raise asmslicer.ASMSlicerException(error_code=asmslicer.ASMSlicerError.IO_ERROR_ON_OUTPUT_FILE, message=f'writing to file failed: {e}') from e


def main():
    try:
        args = parse_args()
        logger.setLevel(args.log.upper())
        if args.command == 'diff':
            do_diff(args.elf1, args.elf2, args.architecture, args.out, args.zf, args.compress_out_csv, args.filter_functions, args.progress)
        elif args.command == 'slice':
            do_slice(args.elf, args.architecture, args.callgraph, args.segments, args.blocks, args.symmap, args.vars, args.asm, args.out,
                     args.zf, args.compress_out_csv, args.filter_functions, args.deps_info, args.use_angr, args.progress, args.deps_path)
        elif args.command == 'deps':
            do_deps(args.input, args.output, args.pregenerated)

    except asmslicer.ASMSlicerException as e:
        logger.exception('ASM slicer error occurred')
        sys.exit(e.error_code)
    except Exception:
        logger.exception('Undefined error occurred')
        sys.exit(asmslicer.ASMSlicerError.UNDEFINED_ERROR)
    sys.exit(0)

if __name__ == '__main__':
    main()
