# categories
UNCONDITIONAL_BRANCHING_INSTRUCTIONS: str = 'UNCONDITIONAL_BRANCHING_INSTRUCTIONS'
CONDITIONAL_BRANCHING_INSTRUCTIONS: str = 'CONDITIONAL_BRANCHING_INSTRUCTIONS'
BRANCH_WITH_LINK_INSTRUCTIONS: str = 'BRANCH_WITH_LINK_INSTRUCTIONS'
RETURN_INSTRUCTIONS: str = 'RETURN_INSTRUCTIONS'
UNSUPPORTED_INSTRUCTIONS: str = 'UNSUPPORTED_INSTRUCTIONS'
CONDITIONS: str = 'CONDITIONS'


# architectures
ARM: str = 'arm'
AARCH64: str = 'aarch64'
X86: str = 'x86'
X86_64: str = 'x84_64'
TRICORE: str = 'tricore'
CORTEXM: str = 'cortexm'


INSTRUCTIONS: dict = {
    UNCONDITIONAL_BRANCHING_INSTRUCTIONS: {
        ARM: [],
        AARCH64: [],
        CORTEXM: [
            "mov",    # mov pc, !lr
        ],
        X86: [],
        X86_64: [],
        TRICORE: [
            "call",
            "calla",
            "calli",
            "fcall",
            "fcalla",
            "fcalli",
            "j",
            "ja",
            "ji",
            "jl",
            "jla",
            "jli",
            "ret",
            "fret",
            "rfe",
            "rfm"
        ]
    },
    CONDITIONAL_BRANCHING_INSTRUCTIONS: {
        ARM: [],
        AARCH64: [],
        CORTEXM: [],
        X86: [],
        X86_64: [],
        TRICORE: [
            "jeq.a",
            "jne.a",
            "jnz.a",
            "jz.a",
            "loop",
            "loopu",
            "jeq",
            "jge",
            "jge.u",
            "jgez",
            "jgtz",
            "jlez",
            "jlt",
            "jlt.u",
            "jltz",
            "jne",
            "jned",
            "jnei",
            "jnz",
            "jnz.t",
            "jz",
            "jz.t",
        ]
    },
    BRANCH_WITH_LINK_INSTRUCTIONS: {
        ARM: [],
        AARCH64: [],
        CORTEXM: [],
        X86: [],
        X86_64: [],
        TRICORE: [
            "call",
            "calla",
            "calli",
            "fcall",
            "fcalla",
            "fcalli",
            "jl",
            "jla",
            "jli",
        ]
    },
    RETURN_INSTRUCTIONS: {
        ARM: [],
        AARCH64: [],
        CORTEXM: [
            "bx",     # bx lr
            "ldr",    # ldr pc, ...
            "mov",    # mov pc, lr
            "movs",   # movs pc, ... 
            # From documentation (https://developer.arm.com/documentation/ddi0597/2025-09/Base-Instructions/MOV--MOVS--register---Move--register--); support movs aliases.
            "pop",    # pop   {..., pc}
            "ldm",    # ldm   ..., {..., pc}
            "ldmia",  # ldmia ..., {..., pc}
            "ldmfd",  # ldmfd ..., {..., pc}
        ],
        X86: [],
        X86_64: [],
        TRICORE: [
            "ret",
            "fret",
            "rfe",
            "rfm",
        ]
    },
    UNSUPPORTED_INSTRUCTIONS: {
        ARM: [],
        AARCH64: [],
        CORTEXM: [],
        X86: [],
        X86_64: [],
        TRICORE: []
    },
    CONDITIONS: {
        ARM: [],
        AARCH64: [],
        CORTEXM: [
            "eq",
            "ne",
            "cs",
            "cc",
            "mi",
            "pl",
            "vs",
            "vc",
            "hi",
            "ls",
            "ge",
            "lt",
            "gt",
            "le",
            "al",
            "nv",
            "hs",
            "lo",
        ],
        X86: [],
        X86_64: [],
        TRICORE: []
    }
}
