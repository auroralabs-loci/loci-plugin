"""
ELF Symbol Resolver
"""

# pylint: disable=too-many-locals
import argparse
import dataclasses
import io
import json
import logging
import os

import smart_open as so
from elftools.elf.elffile import ELFFile

from . import aws_utils as au
from . import elfplt, sdgenerator, utility

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROGRAM_NAME = os.path.splitext(os.path.basename(os.path.abspath(__file__)))[0]


logging.getLogger('smart_open.smart_open_lib').setLevel(logging.WARNING)
logger = logging.getLogger(PROGRAM_NAME)


@dataclasses.dataclass
class ElfFileInfo:
    artifact: str
    path: str

@dataclasses.dataclass
class ElfsInfo:
    elfs: list[ElfFileInfo] = dataclasses.field(default_factory=list)
    artifact_by_link: dict[str, str] = dataclasses.field(default_factory=dict)

@dataclasses.dataclass
class ElfSymResData:
    name: str
    path: str
    exports: set[str]
    imports: dict[str, str]
    needed_libs: list[str]
    plt_stubs: list[elfplt.PLTStubEntry]


def get_artifact(artifact_by_link: dict[str, str], link: str) -> str | None:
    return artifact_by_link.get(link, None)


def process_file(fileinfo: ElfFileInfo, artifact_by_link: dict[str, str]) -> ElfSymResData:
    data = ElfSymResData(
        name=fileinfo.artifact,
        path=fileinfo.path,
        exports=set(),
        imports={},
        needed_libs=[],
        plt_stubs=[],
    )

    elf_buf = None
    try:
        with so.open(fileinfo.path, 'rb') as fh:
            elf_buf = fh.read()
    except Exception as e:
        logger.error(f'Check your {fileinfo.path} file for invalid entries!')
        logger.error(f'{e}')

    if not utility.is_elf_data(elf_buf):
        logger.info("Discarding: %s (not elf file)", fileinfo.path)
        return data

    elf = ELFFile(io.BytesIO(elf_buf))
    e_type = elf.header['e_type']
    if e_type not in ('ET_DYN', 'ET_EXEC'):
        logger.info("Discarding: %s (not dyn or exec)", fileinfo.path)
        return data

    logger.info('processing: %s', fileinfo.path)

    dynamic = elf.get_section_by_name('.dynamic')
    if dynamic:
        for tag in dynamic.iter_tags():
            if tag.entry.d_tag == 'DT_NEEDED':
                needed = get_artifact(artifact_by_link, os.path.basename(str(tag.needed)).strip())
                if needed:
                    data.needed_libs.append(needed)

    dynsym = elf.get_section_by_name('.dynsym')
    if dynsym:
        vers_names: dict[int, list[str]] = utility.get_dynsym_with_versions(elf)
        zero_names: set[str] = set()
        for zero_name in vers_names.get(0, []):
            zero_names.add(zero_name)
            if '@@' in zero_name:
                zero_name = zero_name.replace('@@', '@')
                zero_names.add(zero_name)
        def _add_name(n, imp, exp):
            while True:
                if imp:
                    data.imports[n] = ''
                if exp:
                    data.exports.add(n)
                if '@@' not in n:
                    break
                n = n.replace('@@', '@')
        for symbol in dynsym.iter_symbols():
            name = symbol.name
            if not name:
                continue
            address = symbol.entry.st_value
            sec_ndx = symbol.entry.st_shndx
            binding = symbol.entry.st_info.bind
            section = sec_ndx if not isinstance(sec_ndx, str) else None
            is_import = sec_ndx == "SHN_UNDEF" and binding in ("STB_GLOBAL", "STB_WEAK")
            is_export = (section is not None or sec_ndx == "SHN_COMMON") and binding in ("STB_GLOBAL", "STB_WEAK")
            _add_name(name, is_import, is_export)
            if address > 0 and address in vers_names:
                for ver_name in vers_names[address]:
                    _add_name(ver_name, is_import, is_export)
            if '@' not in name and name in zero_names:
                for zn in zero_names:
                    if zn.startswith(f'{name}@'):
                        _add_name(zn, is_import, is_export)

    data.plt_stubs = list(elfplt.get_dyn_elf_symbols(elf, cs_arch=None, cs_mode=None, logger=logger))
    return data


def process_elfs(elfs_info: ElfsInfo) -> list[ElfSymResData]:
    result: list[ElfSymResData] = []

    for file in elfs_info.elfs:
        srd = process_file(file, elfs_info.artifact_by_link)
        if srd and srd.name:
            result.append(srd)

    return result


def get_needed_libs(srd: ElfSymResData, srds: dict[str, ElfSymResData], include_indirect: bool = True) -> list[str]:
    # BFS traversal to collect all needed libs in order, avoiding duplicates
    result: list[str] = [srd.name]
    queue: list[str] = list(srd.needed_libs)
    seen: set[str] = set(srd.name)
    while queue:
        lib = queue.pop(0)
        if lib not in seen:
            seen.add(lib)
            result.append(lib)
            if include_indirect and lib in srds:
                for dep in srds[lib].needed_libs:
                    if dep not in seen:
                        queue.append(dep)
    return result


def update_needed_libs(srds: dict[str, ElfSymResData]):
    for srd in srds.values():
        srd.needed_libs = get_needed_libs(srd, srds, include_indirect=True)


def resolve_imports(srds: dict[str, ElfSymResData]):
    for srd in srds.values():
        for imp in srd.imports:
            for lib in srd.needed_libs:
                if lib != srd.name and lib in srds and imp in srds[lib].exports:
                    srd.imports[imp] = lib
                    break
        for plt_stub in srd.plt_stubs:
            plt_name = plt_stub.symbol.name
            if plt_name in srd.exports and plt_name not in srd.imports:
                srd.imports[plt_name] = srd.name


def get_elfs_from_version_config(path: str) -> ElfsInfo:
    result = ElfsInfo()
    with so.open(path, 'r', encoding='utf-8') as fh:
        j = json.load(fh)
        for artifact in j["artifacts"]:
            artifact_name = artifact["name"]
            result.elfs.append(
                ElfFileInfo(
                    artifact=artifact_name,
                    path=artifact["url"],
                )
            )
            for link in artifact["symlinks"]:
                result.artifact_by_link[link] = artifact_name

    return result


def get_elf_files(path: str) -> ElfsInfo:
    result = ElfsInfo()
    # path may be a file or a directory
    if os.path.isfile(path):
        if utility.is_elf_file(path):
            name = os.path.basename(path)
            result.elfs.append(ElfFileInfo(artifact=name, path=path))
            result.artifact_by_link[name] = name
        else:
            logger.error("unknown file: %s", path)
    elif os.path.isdir(path):
        for filename in os.listdir(path):
            filepath = os.path.normpath(os.path.abspath(os.path.join(path, filename)))
            sub_elfs = get_elf_files(path=filepath)
            result.elfs.extend(sub_elfs.elfs)
            result.artifact_by_link.update(sub_elfs.artifact_by_link)
        return result
    else:
        logger.error("invalid path: %s", path)
    return result


def print_srd(srd: ElfSymResData):
    print()
    print(f'=== {srd.name}')

    print(f'- needed: {len(srd.needed_libs)}')
    for x in srd.needed_libs:
        print(f'  {x}')

    print(f'- exports: {len(srd.exports)}')
    for x in sorted(srd.exports):
        print(f'  {x}')

    resolved_imports: int = sum(1 for x in srd.imports.values() if x)
    print(f'- imports: {len(srd.imports)}. resolved: {resolved_imports}')
    for x in sorted(srd.imports.keys()):
        lib = srd.imports[x]
        if lib:
            print(f'  {x} [{lib}]')
        else:
            print(f'  {x} [unresolved]')


def output_results(srds: dict[str, ElfSymResData], out_file: str):
    res = {}
    for name in sorted(srds.keys()):
        res[name] = {imp_fun: imp_lib for imp_fun, imp_lib in srds[name].imports.items() if imp_lib}
    with so.open(out_file, 'w', encoding='utf-8') as fh:
        json.dump(res, fh, indent=2, ensure_ascii=False)


def process(path: str, out_file: str, pregenerated: str):
    deps_parent_dir = out_file.rsplit('/', 1)[0]
    pregenerated_dir_path = os.path.join(deps_parent_dir, 'pregenerated')
    all_pregenerated_elfs: list[tuple[str, str, bool]] = []
    all_retreived_elfs: list[tuple[str, str, bool]] = []

    elfs_info: ElfsInfo = (
        get_elfs_from_version_config(path) if path.endswith(".json") else get_elf_files(path)
    )

    project_elfs = set([pelf.artifact for pelf in elfs_info.elfs])

    # TODO: for now, all pregenerated are considered when resolving symbols, should be implemented to consider NEEDED pregenerated libs only
    pregenerated = 's3://loci-v0/pregenerated/cuda/13.0/aarch64/stub/'
    if pregenerated:
        all_pregenerated_elfs = au.Path.list_files(uri=pregenerated, dirs=False, files=True)
        for filename, filepath, is_dir in all_pregenerated_elfs:
            if filename not in project_elfs:
                all_retreived_elfs.append((filename, filepath, is_dir))
                elfs_info.elfs.append(ElfFileInfo(artifact=filename, path=filepath))
                elfs_info.artifact_by_link[filename] = filename

    srds: dict[str, ElfSymResData] = {}
    for srd in process_elfs(elfs_info):
        if srd.name in srds:
            logger.warning('duplicate elf name: %s', srd.name)
            continue
        srds[srd.name] = srd

    update_needed_libs(srds)
    resolve_imports(srds)

    def get_needed_symbols_per_lib(needed_lib: set):
        return set(imp_sym for srd in srds.keys() for imp_sym, imp_lib in srds[srd].imports.items() if imp_lib and imp_lib in needed_lib)

    # retreive symmaps only for needed pregenerated
    if pregenerated and all_retreived_elfs:
        pregenerated_dir_path = os.path.join(deps_parent_dir, 'pregenerated')
        au.Path.makedirs(file=pregenerated_dir_path, exist_ok=True)
        all_needed_libs = set(imp_lib for srd in srds.keys() for imp_lib in srds[srd].imports.values() if imp_lib)
        for filename, filepath, is_dir in all_retreived_elfs:
            if filename in all_needed_libs:
                # download stub lib
                logger.info(f'downloading stub lib {filepath} and storing on location {pregenerated_dir_path}')
                au.copy_file(au.to_file(filepath), au.to_file(os.path.join(pregenerated_dir_path, filename)))
                # generate symmap for stub
                only_needed_symbols = get_needed_symbols_per_lib(set(filename))
                logger.info(f'generating symmap for lib {filepath} and storing on location {pregenerated_dir_path}')
                gen_symmap_path = sdgenerator.generate_stub_symmap(elf_filepath=filepath, out=pregenerated_dir_path, only_symbols=only_needed_symbols)
                # generate callgraph for stub
                logger.info(f'generating callgraph for lib {filepath} and storing on location {pregenerated_dir_path}')
                gen_callgraph_path = sdgenerator.generate_stub_callgraph(symmap_filepath=gen_symmap_path)

    if out_file:
        output_results(srds, out_file)
        return

    for name in sorted(srds.keys()):
        print_srd(srds[name])


def parse_args():
    parser = argparse.ArgumentParser(prog=PROGRAM_NAME, description='ELF Symbol Resolver')
    parser.add_argument('path')
    parser.add_argument('--out')
    parser.add_argument('--pregenerated', help='URI to s3 directory where pre-generated stub elfs for dependencies reside.', type=str, default='')
    return parser.parse_args()


def main():
    args = parse_args()
    process(path=args.path, out_file=args.out, pregenerated=args.pregenerated)


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S", level=logging.INFO)
    main()
