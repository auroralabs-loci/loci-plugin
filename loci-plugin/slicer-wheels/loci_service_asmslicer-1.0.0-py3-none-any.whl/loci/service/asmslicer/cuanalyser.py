"""
cuanalyser
"""

import argparse
import csv
import dataclasses
import hashlib
import json
import logging
import multiprocessing as mp
import os
import re
import subprocess
import tempfile
import time
from concurrent.futures import ProcessPoolExecutor, as_completed

import pandas
import pydot
import smart_open as so
from elftools.elf.elffile import ELFFile

from . import aws_utils as au
from .utility import extract_symbol_simple_name

# pylint: disable=too-many-locals
# pylint: disable=unused-variable
# pylint: disable=broad-exception-caught
# pylint: disable=consider-using-dict-items

# nv/cu tools
CUDA_TOOL_FILT = os.getenv('CUDA_TOOL_FILT', '/usr/local/cuda-13/bin/cu++filt')
CUDA_TOOL_OBJDUMP = os.getenv('CUDA_TOOL_OBJDUMP', '/usr/local/cuda-13/bin/cuobjdump')
CUDA_TOOL_DISASSM = os.getenv('CUDA_TOOL_DISASSM', '/usr/local/cuda-13/bin/nvdisasm')

# defs
CUANALYSER_ANALYSE_REPORT_NAME = '.fatbin.json'

logger: logging.Logger = logging.getLogger('cuanalyser')

@dataclasses.dataclass
class CudaPtx:
    name: str

@dataclasses.dataclass
class CudaCubinSymbol:
    short_name: str
    mangled_name: str
    demangled_name: str
    host_symbol: str
    type: str

@dataclasses.dataclass
class CudaCubin:
    name: str
    symbols: list[CudaCubinSymbol]
    bbcfg: str

@dataclasses.dataclass
class CudaFatbin:
    path: str
    name: str
    symmap: str
    cubins: list[CudaCubin]
    ptxs: list[CudaPtx]
    dependencies: list[str]

@dataclasses.dataclass
class CudaFatbinAnalyses:
    is_fatbin: bool
    fatbin: CudaFatbin

@dataclasses.dataclass
class CudaAnalyser:
    def __init__(self, elf_file_path: str, sym_map_file_path: str) -> None:
        self.elf_file_path = elf_file_path
        self.elf_file_name = os.path.basename(self.elf_file_path)
        self.sym_map_file_path = sym_map_file_path
        self.df_symmap = None
        with so.open(sym_map_file_path) as f:
            self.df_symmap = pandas.read_csv(f)

    @staticmethod
    def is_cuda_fatbin(elf_file_path: str) -> tuple[bool, list[str]]:
        dependencies: list[str] = []
        try:
            result = subprocess.run([CUDA_TOOL_OBJDUMP, '-all', elf_file_path], capture_output=True, text=True, check=True)
            if result.returncode == 0:
                with so.open(elf_file_path, 'rb') as f:
                    elf = ELFFile(f)
                    is_fatbin = False
                    for section in elf.iter_sections():
                        if section.name and section.name.startswith('.nv_fatbin'):
                            is_fatbin = True
                    if is_fatbin:
                        for section in elf.iter_sections():
                            if section:
                                if section.header['sh_type'] == 'SHT_DYNAMIC':
                                    for tag in section.iter_tags():
                                        if tag.entry['d_tag'] == 'DT_NEEDED':
                                            try:
                                                dependencies.append(tag.needed)
                                            except Exception as ex:
                                                logger.warning(f'name of the needed library could not be resolved: {ex}')
                        return True, dependencies
        except Exception as e:
            # logger.warning(f'skipping file {file_path} due to {e}')
            pass
        return False, dependencies

    @staticmethod
    def generate_fatbin_report(fatbin: CudaFatbin) -> dict:
        logger.info('generating fatbin report')
        cuda_fatbin = {}
        cuda_fatbin['path'] = fatbin.path
        cuda_fatbin['name'] = fatbin.name
        cuda_fatbin['symmap'] = fatbin.symmap
        cuda_fatbin['dependencies'] = fatbin.dependencies
        cuda_fatbin['cubins'] = []
        for cubin in fatbin.cubins:
            co = {}
            co['name'] = cubin.name
            # co['bbcfg'] = cubin.bbcfg
            co['symbols'] = []
            for symbol in cubin.symbols:
                sd = {}
                sd['short_name'] = symbol.short_name
                sd['mangled_name'] = symbol.mangled_name
                sd['demangled_name'] = symbol.demangled_name
                sd['host_symbol'] = symbol.host_symbol
                sd['type'] = symbol.type
                co['symbols'].append(sd)
            cuda_fatbin['cubins'].append(co)
        cuda_fatbin['ptxs'] = [ptx.name for ptx in fatbin.ptxs]
        return cuda_fatbin

    @staticmethod
    def parse_cubin_bbcfg(bbcfg_string: str):
        # TODO: This function should be re-worked
        logger.info('parsing cubin bbcfg')
        node_re = re.compile(r'^"?([^":]+)"?(?::([^":]+))?(?::([nsew]+))?$')
        graphs = pydot.graph_from_dot_file(bbcfg_string) if au.Path.exists(bbcfg_string) else pydot.graph_from_dot_data(bbcfg_string)
        if not graphs:
            raise ValueError("No graphs found")

        def parse_endpoint(s):
            match = node_re.match(s.strip('"'))
            if not match:
                return {"name": s.strip('"')}
            name, port, compass = match.groups()
            return {"name": name, "port": port, "compass": compass}

        # def parse_attrs(attr_str):
        #     try:
        #         fake = f'digraph {{ a -> b {attr_str} }}'
        #         dummy = pydot.graph_from_dot_data(fake)[0]
        #         return dummy.get_edges()[0].get_attributes()
        #     except Exception:
        #         return {}

        def process_graph(g):
            data = {
                "attributes": g.get_attributes(),
                "nodes": {},
                "edges": [],
            }

            for node in g.get_nodes():
                name = node.get_name().strip('"').split('.')[-1]
                if name == 'node':
                    continue
                data["nodes"][name] = node.get_attributes()

            for edge in g.get_edges():
                raw = edge.to_string().strip().rstrip(';')
                if '->' in raw:
                    parts = raw.split('->')
                elif '--' in raw:
                    parts = raw.split('--')
                else:
                    continue

                src = parts[0].strip().split('.')[-1]
                rest = parts[1].strip()
                dst = rest.split('[')[0].strip().split('.')[-1]
                # attr_str = '[' + rest.split('[', 1)[1] if '[' in rest else ''

                e = {
                    "src": parse_endpoint(src),
                    "dst": parse_endpoint(dst),
                    # "attributes": parse_attrs(attr_str),
                }
                data["edges"].append(e)

            return data

        def walk(g):
            result = process_graph(g)
            result["subgraphs"] = {}
            for sg in g.get_subgraphs():
                name = sg.get_name().strip('"')
                result["subgraphs"][name] = walk(sg)
            return result

        return walk(graphs[0])

    @staticmethod
    def parse_bbcfg_block_instructions(raw_label_data: str):
        label = raw_label_data.encode('utf-8').decode('unicode_escape')
        label = label.strip('{}')

        substitutions = {
            r'\<': '<', r'\>': '>', r'\[': '[', r'\]': ']',
            r'\(': '(', r'\)': ')', r'\,': ',', r'\\': '\\',
            r'\ ': ' ', r'\-': '-', r'\`': '`',
        }

        for k, v in substitutions.items():
            label = label.replace(k, v)

        lines = label.split('\\l')

        result = {
            'metadata': {},
            'labels': [],
            'instructions': [],
            'unknown': []
        }

        instr_re = re.compile(r'^(?P<addr>[0-9a-fA-F]{4}):\s+(?P<instruction>.+?)\s*;?$')

        for line in lines:
            line = line.strip()
            if not line:
                continue

            m = instr_re.match(line)
            if m:
                result['instructions'].append({
                    'address': m.group('addr'),
                    'instruction': m.group('instruction').strip()
                })
                continue

            if line.startswith('.'):
                parts = line.split(maxsplit=1)
                if len(parts) == 2:
                    key = parts[0].lstrip('.')
                    value = parts[1]
                    result['metadata'][key] = value
                    continue

            if line.endswith(':'):
                result['labels'].append(line.rstrip(':'))
                continue

            result['unknown'].append(line)

        # return result
        return [insn['instruction'] for insn in result['instructions']]

    @staticmethod
    def generate_cubin_data(cubin: CudaCubin, cubin_symmap_dir: str, cubin_callgraph_dir: str, out_blocks_path: str, cuda_runtime_lib: str, cuda_entry_function: str):
        CudaAnalyser.generate_cubin_symmap(cubin=cubin, cubin_symmap_dir=cubin_symmap_dir, cuda_runtime_lib=cuda_runtime_lib, cuda_entry_function=cuda_entry_function)
        CudaAnalyser.generate_cubin_callgraph(cubin=cubin, cubin_callgraph_dir=cubin_callgraph_dir, cuda_runtime_lib=cuda_runtime_lib, cuda_entry_function=cuda_entry_function)
        CudaAnalyser.generate_cubin_blocks(cubin=cubin, out_blocks_path=out_blocks_path)

    @staticmethod
    def generate_cubin_symmap(cubin: CudaCubin, cubin_symmap_dir: str, cuda_runtime_lib: str, cuda_entry_function: str):
        logger.info('generating cubin symmap file')
        with so.open(f'{os.path.join(cubin_symmap_dir, cubin.name)}.symmap.csv', mode='w') as f:
            csv_writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
            csv_writer.writerow(['name', 'long_name', 'start_address', 'size', 'namespace', 'container'])
            for symbol in cubin.symbols:
                if symbol.type == 'STT_FUNC' and symbol.host_symbol:
                    _, _, symbol_short_name = extract_symbol_simple_name(symbol.demangled_name)
                    symbol_long_name = f'{cubin.name}:{symbol.mangled_name}'
                    csv_writer.writerow([symbol_short_name, symbol_long_name, 0, 0, '', cubin.name])
            if cuda_runtime_lib and cuda_entry_function:
                csv_writer.writerow([cuda_entry_function, cuda_entry_function, 0, 0, '', cuda_runtime_lib])

    @staticmethod
    def generate_cubin_callgraph(cubin: CudaCubin, cubin_callgraph_dir: str, cuda_runtime_lib: str, cuda_entry_function: str):
        logger.info('generating cubin callgraph file')
        def _get_cubin_symbols():
            for symbol in cubin.symbols:
                if symbol.type == 'STT_FUNC' and symbol.host_symbol:
                    symbol_long_name = f'{cubin.name}:{symbol.mangled_name}'
                    yield symbol_long_name
        with so.open(f'{os.path.join(cubin_callgraph_dir, cubin.name)}.callgraph.dot', mode='w') as dotfile:
            dotfile.write('digraph {\n')
            for symbol_long_name in _get_cubin_symbols():
                dotfile.write(f'"{symbol_long_name}";\n')
            if cuda_runtime_lib and cuda_entry_function:
                dotfile.write(f'"{cuda_entry_function}";\n')
                for symbol_long_name in _get_cubin_symbols():
                    dotfile.write(f'"{cuda_entry_function}" -> "{symbol_long_name}";\n')
            dotfile.write('}')

    @staticmethod
    def generate_cubin_blocks(cubin: CudaCubin, out_blocks_path: str):
        logger.info('generating cubin blocks file')
        bbcfg_obj = CudaAnalyser.parse_cubin_bbcfg(bbcfg_string=cubin.bbcfg)
        node_to_addr_map = {}
        node_data = {}
        all_relevant_gpu_symbols = {symbol.mangled_name for symbol in cubin.symbols if symbol.type == 'STT_FUNC' and symbol.host_symbol}
        with so.open(out_blocks_path, 'w') as bf:
            csv_writer = csv.writer(bf, quoting=csv.QUOTE_MINIMAL)
            csv_writer.writerow(['s1.name', 's1.long_name', 'r.from_addr', 'r.to_addr', 'r.asm', 'db.block_ids', 'r.src_location'])
            for subgraph in bbcfg_obj['subgraphs']:
                kernel_symbol = None # first node in the subgraph
                node_id: int = 0
                for node in bbcfg_obj['subgraphs'][subgraph]['nodes']:
                    if not kernel_symbol:
                        kernel_symbol = node
                    insns = CudaAnalyser.parse_bbcfg_block_instructions(bbcfg_obj['subgraphs'][subgraph]['nodes'][node]['label'])
                    if node not in node_to_addr_map:
                        # TODO: should use real instruction size, ok for now
                        # node_to_addr_map[node] = CudaAnalyser.generate_32bit_hex_address(node)
                        node_to_addr_map[node] = f"{node_id & 0xFFFFFFFF:08x}"
                        node_id += max((len(insns) * 32), 32)
                    node_data[node] = {}
                    node_data[node]['kernel'] = kernel_symbol
                    node_data[node]['targets'] = set()
                    node_data[node]['asm'] = insns
                for edge in bbcfg_obj['subgraphs'][subgraph]['edges']:
                    if edge['src']['name'] in node_data:
                        node_data[edge['src']['name']]['targets'].add(edge['dst']['name'])
                    else:
                        logger.error(f'found edge on non existing node {edge["src"]["name"]}')
            for node in node_data:
                if not node_data[node]['kernel'] in all_relevant_gpu_symbols: # consider only symbols that has mapping to host symbol
                    continue
                symbol_long_name = f'{cubin.name}:{node_data[node]["kernel"]}'
                csv_writer.writerow([symbol_long_name,
                                     symbol_long_name,
                                     f'0x{node_to_addr_map[node]}',
                                     f'0x{node_to_addr_map[node]}',
                                     "\n".join(node_data[node]['asm']),
                                     "".join([f'{symbol_long_name}\t0x{node_to_addr_map[target]}\n' for target in node_data[node]["targets"]]), cubin.name])

    @staticmethod
    def generate_32bit_hex_address(input_str: str) -> str:
        hash_bytes = hashlib.sha256(input_str.encode('utf-8')).digest()
        return hash_bytes[:4].hex()

    def analyse(self) -> CudaFatbinAnalyses:
        logger.info('fatbin analyses started')
        cuda_fatbin: CudaFatbin = CudaFatbin(path='', name='', symmap='', cubins=[], ptxs=[], dependencies=[])
        is_fatbin, dependencies = CudaAnalyser.is_cuda_fatbin(self.elf_file_path)
        if is_fatbin:
            cuda_fatbin.path = self.elf_file_path
            cuda_fatbin.name = self.elf_file_name
            cuda_fatbin.symmap = self.sym_map_file_path
            cuda_fatbin.dependencies = dependencies
            current_cuda_cubins = self.find_cubins()
            if current_cuda_cubins:
                cuda_fatbin.cubins = current_cuda_cubins
            current_cuda_ptxs = self.find_ptxs()
            if current_cuda_ptxs:
                cuda_fatbin.ptxs = current_cuda_ptxs
        return CudaFatbinAnalyses(is_fatbin=is_fatbin, fatbin=cuda_fatbin)

    def find_cubins(self) -> list[CudaCubin]:
        logger.info('searching for cubins')
        cuda_cubins: list[CudaCubin] = []
        try:
            result = subprocess.run([CUDA_TOOL_OBJDUMP, '-lelf', self.elf_file_path], capture_output=True, text=True, check=True)
            if result.returncode == 0:
                with ProcessPoolExecutor(max_workers = mp.cpu_count() - 1) as executor:
                    cubins = [line.split()[-1] for line in result.stdout.splitlines()]
                    future_to_item = {executor.submit(self.find_cubin_symbols, cubin): cubin for cubin in cubins}
                    for future in as_completed(future_to_item):
                        try:
                            item = future_to_item[future]
                            result = future.result()
                            bbcfg: str = result[0]
                            symbols: list[CudaCubinSymbol] = result[1]
                            cuda_cubin: CudaCubin = CudaCubin(name=item, symbols=symbols, bbcfg=bbcfg)
                            cuda_cubins.append(cuda_cubin)
                        except Exception as e:
                            logger.info(f'ERROR {e}')
        except Exception as e:
            logger.warning(f'error in find_cubins_inside_cuda_fatbin {e}')
        return cuda_cubins

    def find_cubin_symbols(self, cubin_file_name: str) -> tuple[str, list[CudaCubinSymbol]]:
        # logger.info('searching for cubin symbols')
        cubin_bbcfg: str = ''
        cuda_cubin_symbols: list[CudaCubinSymbol] = []
        try:
            with tempfile.TemporaryDirectory() as tempdir:
                result = subprocess.run([CUDA_TOOL_OBJDUMP, '-xelf', cubin_file_name, self.elf_file_path], capture_output=True, text=True, check=True, cwd=tempdir)
                if result.returncode == 0:
                    # retreive cubin cfg
                    result = subprocess.run([CUDA_TOOL_DISASSM, '-bbcfg', '-poff', cubin_file_name], capture_output=True, text=True, check=True, cwd=tempdir)
                    if result.returncode == 0:
                        cubin_bbcfg = result.stdout
                        result = subprocess.run([CUDA_TOOL_OBJDUMP, '-symbols', cubin_file_name], capture_output=True, text=True, check=True, cwd=tempdir)
                        if result.returncode == 0:
                            start_parsing = False
                            for line in result.stdout.splitlines():
                                if start_parsing:
                                    sym_info = line.split()
                                    sym_mangled_name = sym_info[-1]
                                    sym_demangled_name = sym_mangled_name
                                    sym_host_symbol = ''
                                    sym_type = sym_info[0]
                                    result = subprocess.run([CUDA_TOOL_FILT, '-p'], capture_output=True, text=True, input=sym_mangled_name, check=False)
                                    if result.returncode == 0:
                                        symbols_noargs_demangled = result.stdout.splitlines()
                                        if len(symbols_noargs_demangled) > 0:
                                            sym_demangled_name = symbols_noargs_demangled[0] # get first enrty
                                    _, _, sym_short_name = extract_symbol_simple_name(sym_demangled_name)
                                    host_to_cubin_symbol_condition = (self.df_symmap['container'] == self.elf_file_name) & (self.df_symmap['long_name'].str.contains(sym_mangled_name, na=False)) & (self.df_symmap['name'] == sym_short_name)
                                    filtered_cuda_fatbin_symmap = self.df_symmap[host_to_cubin_symbol_condition]
                                    if not filtered_cuda_fatbin_symmap.empty:
                                        sym_host_symbol = filtered_cuda_fatbin_symmap.iloc[0]['long_name'] # get first entry
                                    cuda_cubin_symbol = CudaCubinSymbol(short_name=sym_short_name, mangled_name=sym_mangled_name, demangled_name=sym_demangled_name, host_symbol=sym_host_symbol, type=sym_type)
                                    cuda_cubin_symbols.append(cuda_cubin_symbol)
                                if not start_parsing and line == 'symbols:':
                                    start_parsing = True
        except Exception as e:
            logger.warning(f'error in find_symbols_inside_cubin {e}')
        return cubin_bbcfg, cuda_cubin_symbols

    def find_ptxs(self) -> list[CudaPtx]:
        logger.info('searching for ptxs')
        cuda_ptxs: list[CudaPtx] = list()
        try:
            result = subprocess.run([CUDA_TOOL_OBJDUMP, '-lptx', self.elf_file_path], capture_output=True, text=True, check=True)
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    cuda_ptx: CudaPtx = CudaPtx(name=line.split()[-1])
                    cuda_ptxs.append(cuda_ptx)
        except Exception as e:
            logger.warning(f'error in find_ptxs_inside_cuda_fatbin {e}')
        return cuda_ptxs

def identify_fatbins(directory_path: str) -> dict[str, list]:
    logger.info('identifying fatbins')
    fatbins: dict[str, list] = {}
    for root, dirs, files in os.walk(directory_path):
        for file in files:
            file_path = os.path.join(root, file)
            is_fatbin, dependencies = CudaAnalyser.is_cuda_fatbin(file_path)
            if not is_fatbin:
                continue
            fatbins[file_path] = dependencies
    return fatbins

def run_cuda_analyser(input_path: str, output_path: str, symmap_path: str):
    logger.info('running cuda analyser')
    cuda_analyser: CudaAnalyser = CudaAnalyser(elf_file_path=input_path, sym_map_file_path=symmap_path)
    cuda_fatbin_analyses: CudaFatbinAnalyses = cuda_analyser.analyse()
    if cuda_fatbin_analyses.is_fatbin:
        fatbin_path = f'{output_path}/{cuda_analyser.elf_file_name}{CUANALYSER_ANALYSE_REPORT_NAME}'
        with so.open(fatbin_path, 'w') as f:
            json.dump(CudaAnalyser.generate_fatbin_report(cuda_fatbin_analyses.fatbin), f, indent=4)
    else:
        logger.warning(f'file {input_path} is not a fatbin.')

def main(args):
    logger.info('cuanalyser start')
    start_time = time.time()

    input_file_path = os.path.abspath(args.input)
    if not os.path.exists(input_file_path) or not os.path.isfile(input_file_path):
        logger.error(f'invalid input path {input_file_path}')
        return

    symmap_path = os.path.abspath(args.symmap)
    if not os.path.exists(symmap_path) or not os.path.isfile(symmap_path):
        logger.error(f'invalid symmap path {symmap_path}')
        return

    output_dir_path = os.path.abspath(args.output)
    os.makedirs(name=output_dir_path, exist_ok=True)

    run_cuda_analyser(input_path=input_file_path, output_path=output_dir_path, symmap_path=symmap_path)

    end_time = time.time()
    total_time = round((end_time - start_time), 2)
    logger.info(f'cuanalyser done in {total_time} seconds')

def parse_args():
    parser = argparse.ArgumentParser(prog='cuanalyser')
    parser.add_argument('--input', required=True, type=str, default='', help='Path to elf where to search for fatbins recursively.')
    parser.add_argument('--output', required=True, type=str, default='', help='Path to directory where .fatbin.json report will be stored.')
    parser.add_argument('--symmap', required=True, type=str, default='', help='Path to asmslicer generated .symmap.csv file.')
    parser.add_argument('-l', '--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], default='INFO', help='Logging level', type=lambda s: s.upper())
    return parser.parse_args()

if __name__ == '__main__':
    logger = logging.getLogger('cuanalyser')
    try:
        main_args = parse_args()
        logger.setLevel(main_args.log.upper())
        logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(funcName)s | %(lineno)d | %(message)s',
                            datefmt="%H:%M:%S",
                            force=True)
        main(args=main_args)
    except Exception as e:
        logger.error(e)
