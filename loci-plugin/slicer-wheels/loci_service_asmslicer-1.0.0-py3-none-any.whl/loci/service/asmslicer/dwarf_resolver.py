"""
DWARF ELF Source Location Resolver
"""

import bisect
import logging
import os
import posixpath
import re
import sys

from elftools.dwarf.descriptions import describe_form_class
from elftools.dwarf.die import DIE
from elftools.dwarf.dwarfinfo import DWARFInfo
from elftools.dwarf.lineprogram import LineProgram, LineProgramEntry, LineState
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection

from . import utility

# pylint: disable=too-many-locals
# pylint: disable=too-many-branches
# pylint: disable=too-many-statements
# pylint: disable=too-many-nested-blocks
# pylint: disable=too-many-instance-attributes
# pylint: disable=broad-exception-caught

PROGRAM_NAME = os.path.splitext(os.path.basename(os.path.abspath(__file__)))[0]

logger = logging.getLogger(PROGRAM_NAME)
logger.setLevel(level=logging.INFO)

class DWARFResolver:
    def __init__(self, elffile: str|ELFFile, arch: str, prefix_local: bool = False, skip_optimization_variants: bool = True):
        self.elffile = elffile
        self.arch = arch
        self.prefix_local = prefix_local
        self.optimization_pattern = DWARFResolver._get_optimization_pattern() if skip_optimization_variants else None
        self.elf_to_dwarf_ranges = []
        self.line_entry_list = []
        self.line_entry_addr = []
        self.cu_file_tables = {}
        self.mapping_cache = {}
        self.resolve_cache = {}
        self.addr_ranges = []
        self._build_cache()

    @staticmethod
    def _get_optimization_pattern():
        pattern = re.compile(r'''
            (?P<base>.+?)              # base symbol name (non-greedy)
            (?:
                \.constprop\.\d+    |  # constant propagation
                \.isra\.\d+         |  # interprocedural scalar replacement
                \.lto_priv\.\d+     |  # LTO internal symbol
                \.part\.\d+         |  # function splitting
                \.clone\.\d+        |  # function cloning
                \.__uniq\.\d+       |  # unique function instantiation (rare)
                \.cold\.\d+         |  # cold path split (e.g., from __cold attribute)
                \.hot\.\d+          |  # hot path split (less common)
                \.llvm\.\d+         |  # LLVM-generated clones (if applicable)
                \.localalias\.\d+   |  # local aliases from linker optimizations
                \.omp_fn\.\d+       |  # OpenMP parallel functions
                \.omp_outlined\.\d+ |  # OpenMP outlined regions
                \.i\.\d+            |  # inlined versions (rare, mostly in LTO)
                \.split\.\d+           # GCC or LTO-based function splitting
            )$
        ''', re.VERBOSE)
        return pattern

    def _build_cache(self):
        try:
            if isinstance(self.elffile, ELFFile):
                self._build_cache_for_elf(self.elffile)
            elif isinstance(self.elffile, str):
                if not os.path.isfile(self.elffile):
                    logger.error('File not found: %s', self.elffile)
                    return
                if not utility.is_elf_file(self.elffile):
                    logger.error('File is not ELF: %s', self.elffile)
                    return
                with open(self.elffile, 'rb') as fh:
                    elf = ELFFile(fh)
                    self._build_cache_for_elf(elf)
        except Exception:
            logger.exception('Failed to initialize address resolver')

    def _get_supplementary_dwarfinfo(self, elf: ELFFile) -> DWARFInfo | None:
        section = elf.get_section_by_name(".gnu_debugaltlink")
        if not section:
            return None
        data = section.data()
        # null-terminated filename, followed by 16-byte build ID
        null_pos = data.find(b'\x00')
        if null_pos == -1:
            logger.warning("Invalid %s format", section.name)
            return None
        if null_pos == 0:
            return None
        alt_path = data[:null_pos].decode('utf-8')
        if not os.path.exists(alt_path):
            logger.warning("Supplementary file not found: %s", alt_path)
            return None
        with open(alt_path, 'rb') as fh:
            alt_elf = ELFFile(fh)
            if not alt_elf.has_dwarf_info():
                logger.warning("No DWARF info in supplementary file: %s", alt_path)
                return None
            return alt_elf.get_dwarf_info()

    def _build_cache_for_elf(self, elf: ELFFile):
        if not elf.has_dwarf_info():
            logger.warning('no dwarf info: %s', elf.stream.name)
            return

        line_entries = {}
        dwarf_addresses = {}
        discarded: set[str] = set()
        dwarfinfo = elf.get_dwarf_info()
        dwarfinfo.supplementary_dwarfinfo = self._get_supplementary_dwarfinfo(elf)

        for cu in dwarfinfo.iter_CUs():
            cu_offset = cu.cu_offset
            line_prog: LineProgram | None = dwarfinfo.line_program_for_CU(cu)
            if line_prog is not None:
                include_directory = line_prog['include_directory']
                file_table = {}
                dirs = [b'.']  # DWARF 4: dir_index 0 means current compilation directory
                for dir_entry in include_directory:
                    dirs.append(self._decode_name(dir_entry))

                cu_dwarf_version = cu.structs.dwarf_version
                uses_one_based_indexing = cu_dwarf_version < 5
                if cu_dwarf_version >= 5 and include_directory:
                    # Snippet from DWARF 5 specification (https://dwarfstd.org/doc/DWARF5.pdf)
                    # "The first entry is the current directory of the compilation."
                    # "Each additional path entry is either a full path name or is relative to the current directory of the compilation."
                    top_die = cu.get_top_DIE()
                    if cd_attr:= top_die.attributes.get('DW_AT_comp_dir'):
                        compilation_dir = self._decode_name(cd_attr.value)
                        first_dir = self._decode_name(include_directory[0])
                        if compilation_dir != first_dir:
                            producer_attr = top_die.attributes.get('DW_AT_producer')
                            producer = self._decode_name(producer_attr.value) if producer_attr else ''
                            if "GNU" in producer and self.arch == 'tricore':
                                uses_one_based_indexing = True
                            else:
                                logger.warning(f"First directory ('{first_dir}') does not match compilation directory ('{compilation_dir}'). This is unusual for DWARF 5 and could indicate a non-compliant toolchain.")
                for idx, file_entry in enumerate(line_prog['file_entry']):
                    if uses_one_based_indexing:
                        dir_index = getattr(file_entry, 'dir_index', 0) - 1
                    else:
                        dir_index = getattr(file_entry, 'dir_index', 0)
                    filename = self._decode_name(file_entry.name)
                    directory = ''
                    if dir_index is not None and 0 <= dir_index < len(include_directory):
                        directory = self._decode_name(include_directory[dir_index])
                    if directory:
                        full_path = os.path.join(directory, filename)
                    else:
                        full_path = filename
                    full_path = full_path.replace('\\', '/')
                    if uses_one_based_indexing:
                        file_table[idx + 1] = posixpath.normpath(full_path)
                    else:
                        file_table[idx] = posixpath.normpath(full_path)
                self.cu_file_tables[cu_offset] = file_table

                line_prog_entry: LineProgramEntry
                for line_prog_entry in line_prog.get_entries():
                    state: LineState = line_prog_entry.state
                    if state is None or state.end_sequence:
                        continue
                    line_entries[state.address] = (line_prog_entry, cu_offset)
                    self.line_entry_list.append((state.address, line_prog_entry, cu_offset))

            for die in cu.iter_DIEs():
                if 'DW_TAG_subprogram' != die.tag:
                    continue
                if 'DW_AT_low_pc' in die.attributes and 'DW_AT_high_pc' in die.attributes:
                    low_pc = die.attributes['DW_AT_low_pc'].value
                    high_pc_attr = die.attributes['DW_AT_high_pc']
                    high_pc_form = describe_form_class(high_pc_attr.form)
                    if high_pc_form == 'address':
                        high_pc = high_pc_attr.value
                    elif high_pc_form == 'constant':
                        high_pc = low_pc + high_pc_attr.value
                    else:
                        continue
                    if not 0 < low_pc < high_pc:
                        continue
                else:
                    low_pc: int = 0
                    high_pc: int = 0
                name = self._resolve_die_name(die)
                if not name or name in discarded:
                    continue
                if name in dwarf_addresses:
                    lo, hi = dwarf_addresses[name]
                    if lo != low_pc or hi != high_pc:
                        if low_pc == 0 and high_pc == 0:
                            continue
                        if lo == 0 and hi == 0:
                            dwarf_addresses[name] = (low_pc, high_pc)
                            continue
                        discarded.add(name)
                        del dwarf_addresses[name]
                    continue
                if 0 <= low_pc < high_pc:
                    dwarf_addresses[name] = (low_pc, high_pc)

        self.addr_ranges = []
        for section in elf.iter_sections():
            if isinstance(section, SymbolTableSection):
                stt_file: str = ''
                for symbol in section.iter_symbols():
                    symbol_name = str(symbol.name)
                    symbol_type = symbol.entry.st_info.type
                    if symbol_type == 'STT_FILE':
                        stt_file = symbol_name
                        continue
                    if symbol_type != 'STT_FUNC':
                        continue
                    if symbol_name in discarded:
                        continue
                    if self.should_skip_symbol_name(symbol_name):
                        continue
                    symbol_addr = symbol.entry.st_value
                    symbol_size = symbol.entry.st_size
                    symbol_bind = symbol.entry.st_info.bind
                    if self.prefix_local and symbol_bind == 'STB_LOCAL' and stt_file:
                        symbol_name = f'{stt_file}_{symbol_name}'
                    if symbol_addr and symbol_size:
                        if symbol_name in dwarf_addresses:
                            dwarf_lo, dwarf_hi = dwarf_addresses[symbol_name]
                            if dwarf_lo and dwarf_hi and dwarf_hi > dwarf_lo:
                                self.elf_to_dwarf_ranges.append((symbol_addr, symbol_addr + symbol_size, dwarf_lo, dwarf_hi))
                        entry_tuple_elf = line_entries.get(symbol_addr, None)
                        entry_tuple_dwarf = None
                        if symbol_name in dwarf_addresses:
                            dwarf_addr = dwarf_addresses[symbol_name][0]
                            if dwarf_addr != symbol_addr:
                                entry_tuple_dwarf = line_entries.get(dwarf_addr, None)
                        # Map all addresses in the symbol's range to the line entry
                        if entry_tuple_elf:
                            self.addr_ranges.append((symbol_addr, symbol_addr + symbol_size))
                        if entry_tuple_dwarf:
                            dwarf_lo, dwarf_hi = dwarf_addresses[symbol_name]
                            self.addr_ranges.append((dwarf_lo, dwarf_hi))

        self.addr_ranges.sort()
        self.elf_to_dwarf_ranges.sort()
        self.line_entry_list.sort(key=lambda x: x[0])
        self.line_entry_addr = [x[0] for x in self.line_entry_list]
        logger.debug('line entries: %d', len(self.line_entry_list))

    def map_elf_to_dwarf(self, address: int) -> int | None:
        if address in self.mapping_cache:
            return self.mapping_cache[address]
        res = None
        obj = (address, float('inf'), float('inf'), float('inf'))
        idx = bisect.bisect_right(self.elf_to_dwarf_ranges, obj) - 1
        if 0 <= idx < len(self.elf_to_dwarf_ranges):
            elf_start, elf_end, dwarf_start, dwarf_end = self.elf_to_dwarf_ranges[idx]
            if elf_start <= address < elf_end:
                offset = address - elf_start
                dwarf_addr = dwarf_start + offset
                if dwarf_addr < dwarf_end:
                    res = dwarf_addr
        self.mapping_cache[address] = res
        return res

    def should_skip_symbol_name(self, name: str) -> bool:
        if self.optimization_pattern is not None:
            match = self.optimization_pattern.match(name)
            if match:
                base_name = match.group('base')
                logger.debug('optimized symbol base: %s', base_name)
                return True
        return False

    @staticmethod
    def _decode_name(name: bytes) -> str:
        return name.decode('utf-8')

    def _get_decl_file_name(self, die: DIE) -> str | None:
        if 'DW_AT_decl_file' not in die.attributes:
            return None
        line_prog = die.dwarfinfo.line_program_for_CU(die.cu)
        if line_prog is None:
            return None
        files = line_prog['file_entry']
        index = die.attributes['DW_AT_decl_file'].value - 1
        if not 0 <= index < len(files):
            return None
        return self._decode_name(files[index].name)

    def _get_func_prefix(self, die: DIE) -> str:
        prefix: str = ''
        if self.prefix_local:
            if 'DW_AT_external' not in die.attributes or die.attributes['DW_AT_external'].value is False:
                filename = self._get_decl_file_name(die)
                if filename:
                    prefix = os.path.basename(filename) + '_'
        return prefix

    def _get_string_from_offset(self, dwarfinfo: DWARFInfo, offset: int, alt=False):
        di = dwarfinfo.supplementary_dwarfinfo if alt else dwarfinfo
        sec = di.debug_str_sec if di else None
        if not sec:
            logger.debug('No .debug_str section. alt: %s', alt)
            return ''
        stream = sec.stream
        stream.seek(sec.global_offset + offset)
        s = b''
        while True:
            c = stream.read(1)
            if c in (b'\x00', b''):
                break
            s += c
        return s.decode('utf-8')

    def _get_referenced_name(self, die: DIE) -> str | None:
        for attr_name in ('DW_AT_linkage_name', 'DW_AT_MIPS_linkage_name', 'DW_AT_name'):
            if attr_name in die.attributes:
                attr = die.attributes[attr_name]
                if isinstance(attr.value, bytes):
                    return attr.value.decode('utf-8')
                if attr.form == 'DW_FORM_string':
                    return str(attr.value)
                if attr.form in ('DW_FORM_strp', 'DW_FORM_strp_sup'):
                    return self._get_string_from_offset(die.dwarfinfo, attr.value)
                if attr.form == 'DW_FORM_GNU_strp_alt':
                    return self._get_string_from_offset(die.dwarfinfo, attr.value, alt=True)
                logger.warning(f'Unhandled attribute form: {attr.form}')
        return None

    def _get_referenced_die(self, die: DIE) -> DIE | None:
        for ref_attr in ('DW_AT_abstract_origin', 'DW_AT_specification'):
            if ref_attr in die.attributes:
                try:
                    ref_die = die.get_DIE_from_attribute(ref_attr)
                    if ref_die:
                        return ref_die
                except NotImplementedError:
                    pass
        return None

    def _resolve_die_name(self, die: DIE):
        visited = set()
        while die is not None:
            if die.offset in visited:
                logger.debug("Cycle detected, aborting.")
                break
            visited.add(die.offset)
            name = self._get_referenced_name(die)
            if name:
                name = self._get_func_prefix(die) + name
                logger.debug(f"Resolved: {name}")
                return name
            die = self._get_referenced_die(die)
        return None

    def resolve_address(self, address: int) -> tuple[str, int, int, int] | None:
        if address in self.resolve_cache:
            return self.resolve_cache[address]
        res = None
        idx = bisect.bisect_right(self.addr_ranges, (address, float('inf'), None)) - 1
        if 0 <= idx < len(self.addr_ranges):
            start, end = self.addr_ranges[idx]
            if start <= address < end:
                line_idx = bisect.bisect_right(self.line_entry_addr, address) - 1
                if line_idx >= 0:
                    # move to the first occurrence of this address if there are duplicates
                    first_idx = bisect.bisect_left(self.line_entry_addr, self.line_entry_addr[line_idx], 0, line_idx + 1)
                    line_idx = first_idx
                    addr, entry, cu_offset = self.line_entry_list[line_idx]
                    file_idx = entry.state.file
                    file_table = self.cu_file_tables.get(cu_offset, {})
                    filename = file_table.get(file_idx, f"<unknown:{file_idx}>")
                    res = (filename, addr, entry.state.line, entry.state.column)
        self.resolve_cache[address] = res
        return res

    def resolve(self, address: int) -> tuple[str, int, int, int] | None:
        res = self.resolve_address(address)
        if res is None:
            mapped_addr = self.map_elf_to_dwarf(address)
            if mapped_addr is not None and mapped_addr != address:
                res = self.resolve_address(mapped_addr)
        return res

def resolve_all_in_elf(elf_path: str):
    num_found = 0
    num_not_found = 0
    prefix_local: bool = False
    logger.info('elf: %s', elf_path)

    with open(elf_path, 'rb') as f:
        elffile = ELFFile(f)
        resolver = DWARFResolver(elffile, prefix_local=prefix_local)
        for section in elffile.iter_sections():
            if isinstance(section, SymbolTableSection):
                stt_file: str = ''
                for symbol in section.iter_symbols():
                    symbol_name = str(symbol.name)
                    symbol_type = symbol.entry.st_info.type
                    if symbol_type == 'STT_FILE':
                        stt_file = symbol_name
                        continue
                    if symbol_type != 'STT_FUNC':
                        continue
                    symbol_addr = symbol.entry.st_value
                    symbol_size = symbol.entry.st_size
                    symbol_bind = symbol.entry.st_info.bind
                    if prefix_local and symbol_bind == 'STB_LOCAL' and stt_file:
                        symbol_name = f'{stt_file}_{symbol_name}'
                    if resolver.should_skip_symbol_name(symbol_name):
                        continue
                    if symbol_addr and symbol_size:
                        result = resolver.resolve(symbol_addr)
                        if result:
                            num_found += 1
                            # filename, addr, line, column = result
                            # print(f"{symbol_addr:08x}: {addr:08x} {filename}:{line}:{column}")
                        else:
                            num_not_found += 1
                            logger.debug(f"{symbol_addr:08x}: no source info. {symbol_name}")
        logger.info("found: %d. not found: %d", num_found, num_not_found)

def resolve_all(path: str):
    if utility.is_elf_file(path):
        resolve_all_in_elf(path)
        return

    if os.path.isdir(path):
        for filename in os.listdir(path):
            filepath = os.path.normpath(os.path.abspath(os.path.join(path, filename)))
            resolve_all(filepath)

def resolve_address(elf_path: str, address: int):
    resolver = DWARFResolver(elf_path)
    result = resolver.resolve(address)
    if result:
        filename, addr, line, column = result
        print(f"{address:08x}: {addr:08x} {filename}:{line}:{column}")
    else:
        print(f"{address:08x}: no source info")

def _main():
    if len(sys.argv) == 2:
        resolve_all(sys.argv[1])
        return

    if len(sys.argv) == 3:
        resolve_address(sys.argv[1], int(sys.argv[2], 0))
        return

    print("Usage: python find_address.py <elf_path> <address>")
    sys.exit(1)

if __name__ == "__main__":
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S")
    _main()
