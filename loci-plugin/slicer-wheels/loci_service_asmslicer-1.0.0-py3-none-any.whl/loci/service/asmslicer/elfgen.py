"""
ELF Generator and Updater
"""

import csv
import logging
import os.path
import sys
from argparse import ArgumentParser
from dataclasses import dataclass

from elftools.elf.elffile import ELFFile
from lief import parse as lief_parse
from lief.ELF import Binary, Header, Section, Symbol

from . import mapreader, utility

# pylint: disable=global-statement


@dataclass
class SectionData:
    name: str
    type: Section.TYPE
    addr: int
    offset: int
    size: int
    flags: str


SectionFlags = {
    0x1:   'W',  # SHF_WRITE
    0x2:   'A',  # SHF_ALLOC
    0x4:   'X',  # SHF_EXECINSTR
    0x10:  'M',  # SHF_MERGE
    0x20:  'S',  # SHF_STRINGS
    0x40:  'I',  # SHF_INFO_LINK
    0x80:  'L',  # SHF_LINK_ORDER
    0x100: 'O',  # SHF_OS_NONCONFORMING
    0x200: 'G',  # SHF_GROUP
    0x400: 'T',  # SHF_TLS
}


def read_elf_sections(binary: Binary) -> dict[str, SectionData]:
    def _parse_section_flags(f: int) -> str:
        flag_str = ''.join(v for k, v in SectionFlags.items() if f & k)
        return flag_str if flag_str else 'None'
    sections = {}
    binary_sections: list[Section] = [s for s in binary.sections]
    for section in binary_sections:
        name = section.name
        flags = _parse_section_flags(section.flags)
        sections[name] = SectionData(name=name, type=section.type, addr=section.virtual_address, offset=section.offset, size=section.size, flags=flags)
    return sections


def get_section_index(elf: Binary, section_name: str) -> int:
    for i, s in enumerate(elf.sections):
        if s and s.name and s.name == section_name:
            return i
    return -1


def update_elf_with_symbols(symbols: list[mapreader.SymbolEntry], sections: dict[str, SectionData],
                            binary: Binary, updated_elf: str):

    header: Header = binary.header

    strtab_section = Section(".strtab")
    strtab_section.type = Section.TYPE.STRTAB
    strtab_section.content = [0]
    binary.add(section=strtab_section, loaded=False)

    symtab_section = Section(".symtab")
    symtab_section.type = Section.TYPE.SYMTAB
    symtab_section.entry_size = 16 if header.identity_class == header.CLASS.ELF32 else 24
    symtab_section.link = get_section_index(binary, '.strtab')

    for symbol_entry in symbols:
        symbol = Symbol()
        symbol.name = symbol_entry.name
        symbol.value = symbol_entry.origin
        symbol.size = symbol_entry.size
        symbol.binding = Symbol.BINDING.GLOBAL
        section = symbol_entry.section
        section_idx = get_section_index(binary, section)
        if section in sections:
            section_data = sections[section]
            if section_idx > -1:
                symbol.shndx = section_idx
            symbol.type = Symbol.TYPE.FUNC if 'X' in section_data.flags else Symbol.TYPE.OBJECT
        binary.add_symtab_symbol(symbol)
    binary.add(section=symtab_section, loaded=False)
    binary.write(updated_elf)
    logger.debug(f"Created elf with .symtab: {updated_elf}. Symbols: {len(symbols)}")


def update_elf_with_debug_elf(binary: Binary, binary_debug: Binary, updated_elf: str):
    # copy the strtab section
    strtab_section: Section = binary_debug.get_section(".strtab")
    if not strtab_section:
        logger.error('missing strtab section')
        return
    binary.add(section=strtab_section, loaded=False)

    # copy the symtab section
    symtab_section: Section = binary_debug.get_section(".symtab")
    if not symtab_section:
        logger.error('missing symtab section')
        return
    symtab_section.link = get_section_index(binary, '.strtab')
    for symbol in binary_debug.symbols:
        binary.add_symtab_symbol(symbol)
    binary.add(section=symtab_section, loaded=False)

    # save new elf
    binary.write(updated_elf)
    logger.debug(f"Created elf with .symtab: {updated_elf}. Symbols: {len(binary_debug.symbols)}")

def create_symbol_entries_from_sym_file_csv(elf_file: str, sym_file: str) -> list[mapreader.SymbolEntry]:
    symbols: list[mapreader.SymbolEntry] = []
    try:
        sections: list[tuple[int, int, str]] | None = None
        with open(sym_file, 'r', encoding='utf-8') as sym_fh:
            header = ['name','long_name','start_address','size','namespace','container']
            reader = csv.reader(sym_fh)
            line_number = 0
            for row in reader:
                line_number += 1
                if line_number == 1:
                    if row != header:
                        raise RuntimeError(f'invalid header. file: {sym_file}. header: {row}')
                    continue
                name = row[1]
                addr = int(row[2])
                size = int(row[3])
                if sections is None:
                    sections = []
                    with open(elf_file, 'rb') as elf_fh:
                        elf = ELFFile(elf_fh)
                        for s in elf.iter_sections():
                            if s.header['sh_flags'] & 0x4: # SHF_EXECINSTR
                                section_beg = int(s.header['sh_addr'])
                                section_len = int(s.header['sh_size'])
                                sections.append((section_beg, section_beg + section_len, s.name))
                for sec_beg, sec_end, sec_name in sections:
                    if sec_beg <= addr < sec_end:
                        symbols.append(mapreader.SymbolEntry(section=sec_name, origin=addr, size=size, name=name))
                        break
    except IOError as ex:
        logger.error(f'file: {sym_file}. exception: {ex}')
        return []
    return symbols


def parse_args():
    parser = ArgumentParser(prog='ELF Generator')
    parser.add_argument('-e', '--elf', required=True, help='Stripped ELF')
    parser.add_argument('-d', '--debug_elf', required=False, help='ELF with symbols')
    parser.add_argument('-m', '--map_file', required=False, help='Map file')
    parser.add_argument('-c', '--sym_csv', required=False, help='CSV symbol file')
    parser.add_argument('-o', '--out', required=False, help='Output ELF')
    parser.add_argument('-l', '--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        default='DEBUG', help='Logging level', type=lambda s: s.upper())
    args = parser.parse_args()
    num_symbol_files = sum([bool(args.debug_elf), bool(args.map_file), bool(args.sym_csv)])
    if num_symbol_files != 1:
        print("Error: You must specify exactly one of the following options: --debug_elf, --map_file, or --sym_csv.")
        sys.exit(1)
    return args


def _prepare_gen(elf_file: str, log: logging.Logger = None) -> tuple[Binary, dict[str, SectionData]]:
    global logger
    logger = log

    binary: Binary = lief_parse(elf_file)
    if not binary:
        raise RuntimeError(f'failed to parse: {elf_file}')

    sections: dict[str, SectionData] = read_elf_sections(binary)
    if not sections:
        raise RuntimeError(f'no sections: {elf_file}')

    return binary, sections


def generate_with_debug_elf(elf_file: str, debug_elf_file: str, out_file: str, log: logging.Logger = None) -> bool:
    binary, _ = _prepare_gen(elf_file=elf_file, log=log)
    if not utility.is_elf_file(debug_elf_file):
        logger.warning(f'not elf file: {debug_elf_file}')
        return False
    binary_debug: Binary = lief_parse(debug_elf_file)
    if not binary_debug:
        logger.warning(f'failed to parse debug elf: {debug_elf_file}')
        return False
    update_elf_with_debug_elf(binary, binary_debug, out_file)
    return os.path.isfile(out_file)


def generate_with_map_file(elf_file: str, map_file: str, out_file: str, log: logging.Logger = None) -> bool:
    binary, sections = _prepare_gen(elf_file=elf_file, log=log)
    map_content: mapreader.MapContent|None = mapreader.process(map_file, log=logger)
    if not map_content or not map_content.sym_items:
        logger.warning(f'failed to parse or empty map content: {map_file}')
        return False
    update_elf_with_symbols(map_content.sym_items, sections, binary, out_file)
    return os.path.isfile(out_file)


def generate_with_sym_csv(elf_file: str, csv_file: str, out_file: str, log: logging.Logger = None) -> bool:
    binary, sections = _prepare_gen(elf_file=elf_file, log=log)
    sym_items: list[mapreader.SymbolEntry] = create_symbol_entries_from_sym_file_csv(elf_file, csv_file)
    if not sym_items:
        logger.warning(f'failed to parse or empty symbol csv file: {csv_file}')
        return False
    update_elf_with_symbols(sym_items, sections, binary, out_file)
    return os.path.isfile(out_file)


if __name__ == "__main__":
    _main_args = parse_args()
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S")
    logger = logging.getLogger('elfgen')
    logger.setLevel(_main_args.log.upper())
    _out_file: str = _main_args.out or f'{_main_args.elf}.full'
    if _main_args.debug_elf:
        generate_with_debug_elf(elf_file=_main_args.elf, debug_elf_file=_main_args.debug_elf, out_file=_out_file, log=logger)
    elif _main_args.map_file:
        generate_with_map_file(elf_file=_main_args.elf, map_file=_main_args.map_file, out_file=_out_file, log=logger)
    elif _main_args.sym_csv:
        generate_with_sym_csv(elf_file=_main_args.elf, csv_file=_main_args.sym_csv, out_file=_out_file, log=logger)
