import bisect
import dataclasses
import logging
import os.path
import pickle

import xxhash
from capstone import Cs
from elftools.elf.elffile import ELFFile

from . import utility
from .asmslicer import Architecture, ElfDisassembler, ElfFileInfo


@dataclasses.dataclass(frozen=True)
class ElfAsmSection:
    beg: int
    end: int
    ins: tuple[int, str]


@dataclasses.dataclass
class ElfAsmCache:
    sections: list[ElfAsmSection]


class ASMCache:
    def __init__(self, log: logging.Logger):
        self._logger: logging.Logger = log
        self._cache_dir: str = os.path.join(utility.get_cache_dir(), 'asm')
        self._elf_cache: dict[str, ElfAsmCache] = {} # key: ELF hash
        self._file_hash: dict[str, str] = {}
        os.makedirs(self._cache_dir, exist_ok=True)


    def set_logger(self, log: logging.Logger | None):
        self._logger = log


    def _hash_file(self, file_path: str) -> str:
        file_hash = self._file_hash.get(file_path, '')
        if not file_hash:
            file_hash = utility.hash_file_xxh128(file_path)
            self._file_hash[file_path] = file_hash
        return file_hash


    @staticmethod
    def _generate_elf_cache(elf_path: str, arch: int, mode: int, provided_architecture: str = '') -> ElfAsmCache:
        sections: list[ElfAsmSection] = []
        css = Cs(arch, mode)
        css.skipdata = provided_architecture == Architecture.ARM_CORTEXM.value
        css.detail = True

        data_seqs = []
        with open(elf_path, 'rb') as fh:
            elffile = ELFFile(fh)
            elffile_info = ElfFileInfo(elf=elffile, elf_path=elf_path, provided_architecture=provided_architecture)

            data_seqs = ElfDisassembler.marked_data_sequences(elffile_info=elffile_info, relevant_symbols={})
            if not data_seqs:
                data_seqs = ElfDisassembler.detect_data_sequences(elffile_info=elffile_info, css=css, relevant_symbols={})

            for s in elffile.iter_sections():
                if s.header['sh_flags'] & 0x4: # SHF_EXECINSTR
                    section_beg = int(s.header['sh_addr'])
                    section_len = int(s.header['sh_size'])
                    section_end = section_beg + section_len
                    csis = ElfDisassembler.disassemble_chunk(
                        dis_beg=section_beg,
                        dis_end=section_end,
                        sec_beg=section_beg,
                        sec_data=s.data(),
                        css=css,
                        architecture=elffile_info.architecture,
                        strings={},
                        data_seqs=data_seqs,
                    )
                    instructions = []
                    if csis is None:
                        continue
                    for csi in csis.instructions:
                        instructions.append((csi.address, f"{csi.mnemonic} {csi.op_str}".strip()))
                    sections.append(ElfAsmSection(beg=section_beg, end=section_end, ins=instructions))
        return ElfAsmCache(sections=sections)


    def _get_elf_cache(self, elf_path: str, arch: int, mode: int, provided_architecture: str) -> ElfAsmCache:
        cache_version = 1
        file_hash = self._hash_file(elf_path)
        key = xxhash.xxh128(f'{file_hash}:{arch}:{mode}:{cache_version}').hexdigest()
        if key in self._elf_cache:
            return self._elf_cache[key]
        cache_file_name = f'{key}.asm'
        cache_file_path = f'{self._cache_dir}/{cache_file_name}'
        if os.path.isfile(cache_file_path):
            with open(cache_file_path, 'rb') as fh:
                asm_cache: ElfAsmCache = pickle.load(fh)
                self._elf_cache[key] = asm_cache
                self._logger.info(f'loaded: {cache_file_name}. elf: {elf_path}')
                return asm_cache
        self._logger.info(f'generating: {cache_file_name}. elf: {elf_path}')
        asm_cache = ASMCache._generate_elf_cache(elf_path=elf_path, arch=arch, mode=mode, provided_architecture=provided_architecture)
        self._elf_cache[key] = asm_cache
        with open(cache_file_path, 'wb') as fh:
            # noinspection PyTypeChecker
            pickle.dump(asm_cache, fh)
        return asm_cache


    def get_asm_instructions(self, elf_path: str, arch: int, mode: int, start_addr: int, end_addr: int, provided_architecture: str = '') -> str:
        asm: str = ''
        asm_cache = self._get_elf_cache(elf_path=elf_path, arch=arch, mode=mode, provided_architecture=provided_architecture)
        for section in asm_cache.sections:
            if start_addr >= section.beg and end_addr < section.end:
                idx_start = bisect.bisect_left(section.ins, (start_addr, ''))
                for addr, ins in section.ins[idx_start:]:
                    if addr > end_addr:
                        break
                    if asm:
                        asm += '\n'
                    asm += ins
                break
        return asm
