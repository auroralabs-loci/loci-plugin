import dataclasses
import glob
import logging
import os
import shutil
import subprocess
import time
import urllib.parse
from pathlib import PurePosixPath

import boto3
from botocore.exceptions import ClientError

S3_PREFIXES = ('s3://',)
LOCAL_PREFIXES = ('file:///', 'file://')
Uri = str


@dataclasses.dataclass
class LocalFile():
    path: str


@dataclasses.dataclass
class S3File:
    bucket: str
    key: str


def to_file(uri: str) -> LocalFile|S3File|None:
    if not uri:
        return None
    uri = uri.strip()
    uri_lc = uri.lower()
    for prefix in S3_PREFIXES:
        if uri_lc.startswith(prefix):
            s3_uri = uri[len(prefix):]  # Strip the 's3://' prefix
            tokens = s3_uri.split('/', 1)
            bucket = tokens[0]
            reskey = tokens[1] if len(tokens) == 2 else ''
            return S3File(bucket=bucket, key=reskey)
    for prefix in LOCAL_PREFIXES:
        if uri_lc.startswith(prefix):
            file_uri = uri[len(prefix):]  # Strip prefix
            file_path = urllib.parse.unquote(file_uri)  # Decode URL encoding
            return LocalFile(path=file_path.replace('\\', '/'))
    return LocalFile(path=uri.replace('\\', '/'))


def to_uri(file: Uri|LocalFile|S3File) -> str:
    if isinstance(file, Uri):
        return file
    if isinstance(file, LocalFile):
        return f"file://{urllib.parse.quote(file.path)}"
    if isinstance(file, S3File):
        return f"s3://{file.bucket}/{file.key}" if file.key else f"s3://{file.bucket}/"


class Path:
    @staticmethod
    def sep(file: Uri|LocalFile|S3File) -> str:
        if isinstance(file, S3File) or (isinstance(file, Uri) and Path.is_s3(file)):
            return "/"
        return os.sep


    @staticmethod
    def is_s3(uri: Uri) -> bool:
        if not uri:
            return False
        uri = uri.strip()
        uri_lc = uri.lower()
        for prefix in S3_PREFIXES:
            if uri_lc.startswith(prefix):
                return True
        return False


    @staticmethod
    def dirname(file: Uri|LocalFile|S3File):
        f = file
        if isinstance(f, Uri):
            f = to_file(file)
        if isinstance(f, S3File):
            # Return directory component of the path.
            # Be consistent with os.path.dirname results.
            #
            # Example:
            # dirname("s3://bucket/key/") -> "s3://bucket/key"
            # dirname("s3://bucket/key") -> "s3://bucket/"
            if f.key.endswith('/'):
                f.key = f.key.rstrip('/')
            else:
                parent = str(PurePosixPath(f.key).parent)
                if parent == '.':
                    parent = ''
                f.key = "" if not parent else f"{parent}/"
            return to_uri(f)
        if isinstance(f, LocalFile):
            return os.path.dirname(f.path)
        return ''


    @staticmethod
    def join(f1: Uri|LocalFile|S3File, *f2: Uri) -> Uri:
        if any(Path.is_s3(f) for f in f2):
            return None
        if isinstance(f1, LocalFile):
            return os.path.join(f1.path, *f2)
        f1_uri = ''
        if isinstance(f1, Uri):
            if not Path.is_s3(f1):
                return os.path.join(f1, *f2)
            f1_uri = f1
        if isinstance(f1, S3File):
            f1_uri = to_uri(f1)
        return f"{f1_uri.rstrip('/')}/{'/'.join(f2)}"


    @staticmethod
    def expanduser(file: Uri|LocalFile|S3File) -> str:
        f = file
        if isinstance(f, S3File):
            return to_uri(f)
        if isinstance(f, Uri):
            if Path.is_s3(f):
                return f
            f = to_file(file)
        if isinstance(f, LocalFile):
            return os.path.expanduser(f.path)
        return ''


    @staticmethod
    def abspath(file: Uri|LocalFile|S3File) -> str:
        f = file
        if isinstance(f, S3File):
            return to_uri(f)
        if isinstance(f, Uri):
            if Path.is_s3(f):
                return f
            f = to_file(file)
        if isinstance(f, LocalFile):
            return os.path.normpath(os.path.abspath(f.path))
        return ''


    @staticmethod
    def isabs(file: Uri|LocalFile|S3File) -> bool:
        f = file
        if isinstance(f, Uri):
            f = to_file(file)
        if isinstance(f, S3File):
            return True
        if isinstance(f, LocalFile):
            return os.path.isabs(f.path)


    @staticmethod
    def _s3_exists(file: S3File):
        if not file.key or file.key.endswith('/'):
            # Directory check
            parent = to_file(Path.dirname(to_uri(file).rstrip('/')))
            if not parent.key:
                return True

            s3 = boto3.client('s3')
            try:
                response = s3.list_objects_v2(
                    Bucket=parent.bucket,
                    Delimiter="/",
                    Prefix=parent.key
                )
            except ClientError as _:
                return False
            return any(file.key == obj["Prefix"] for obj in response.get("CommonPrefixes", []))

        # File check
        s3 = boto3.client('s3')
        try:
            s3.head_object(Bucket=file.bucket, Key=file.key)
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return False
            raise


    @staticmethod
    def exists(file: Uri|LocalFile|S3File) -> bool:
        f = to_file(file) if isinstance(file, Uri) else file

        if isinstance(f, S3File):
            return Path._s3_exists(f)
        if isinstance(f, LocalFile):
            return os.path.exists(f.path)
        return False


    @staticmethod
    def rm(file: Uri|LocalFile|S3File, logger: logging.Logger = None):
        f = file
        if isinstance(f, Uri):
            f = to_file(file)
        if isinstance(f, LocalFile):
            os.remove(f.path)
        if isinstance(f, S3File):
            try:
                s3 = boto3.resource('s3')
                s3.Object(f.bucket, f.key).delete()
            except Exception as ex:
                if logger:
                    logger.error(f'Couldn\'t delete: {file}. Reason: {ex}')


    @staticmethod
    def rmtree(file: Uri|LocalFile|S3File, logger: logging.Logger = None):
        f = file
        if isinstance(f, Uri):
            f = to_file(file)
        if isinstance(f, LocalFile):
            shutil.rmtree(f.path)
        if isinstance(f, S3File):
            try:
                s3 = boto3.client('s3')
                to_delete = s3.list_objects_v2(Bucket=f.bucket, Prefix=f.key)
                if 'Contents' in to_delete:
                    delete_keys = {'Objects': [{'Key': obj['Key']} for obj in to_delete['Contents']]}
                    s3.delete_objects(Bucket=f.bucket, Delete=delete_keys)
            except Exception as ex:
                if logger:
                    logger.error(f'Couldn\'t delete: {file}. Reason: {ex}')


    @staticmethod
    def makedirs(file: Uri|LocalFile|S3File, exist_ok: bool = True):
        f = file
        if isinstance(f, Uri):
            f = to_file(file)
        if isinstance(f, S3File):
            s3 = boto3.resource("s3")
            obj = s3.Object(f.bucket, f'{f.key}/' if not f.key.endswith('/') else f.key)
            obj.put(Body="")
        if isinstance(f, LocalFile):
            os.makedirs(f.path, exist_ok=exist_ok)


    @staticmethod
    def is_file(file: Uri|LocalFile|S3File):
        f = file
        if isinstance(f, Uri):
            if Path.is_s3(f):
                return not f.endswith('/') and Path.exists(file)
            f = to_file(file)
        if isinstance(f, S3File):
            return not f.key.endswith('/') and Path.exists(file)
        if isinstance(f, LocalFile):
            return os.path.isfile(f.path)


    @staticmethod
    def is_dir(file: Uri|LocalFile|S3File):
        f = file
        if isinstance(f, Uri):
            if Path.is_s3(f):
                return Path.exists(file) and f.endswith('/')
            f = to_file(file)
        if isinstance(f, S3File):
            return (f.key.endswith('/') or not f.key) and Path.exists(f)
        if isinstance(f, LocalFile):
            return os.path.isdir(f.path)


    @staticmethod
    def list_files(uri: str, dirs: bool = True, files: bool = True) -> list[tuple[str, str, bool]]:
        f = to_file(uri)
        if not f or not Path.is_dir(f) or (not dirs and not files):
            return []
        result = []
        if isinstance(f, LocalFile):
            for file in os.listdir(f.path):
                filepath = os.path.normpath(os.path.abspath(os.path.join(f.path, file)))
                if dirs and os.path.isdir(filepath):
                    result.append((file, f"{filepath}/", True))
                if files and os.path.isfile(filepath):
                    result.append((file, filepath, False))
            return result
        if isinstance(f, S3File):
            s3 = boto3.client('s3')
            paginator = s3.get_paginator('list_objects_v2')
            response = paginator.paginate(
                Bucket=f.bucket,
                Delimiter="/",
                Prefix=f.key
            )
            if not response:
                return result
            for page in response:
                if not page:
                    continue
                if dirs:
                    for obj in page.get("CommonPrefixes", []):          # dirs
                        obj_prefix = obj["Prefix"]
                        obj_name = obj_prefix.rstrip("/").split("/")[-1]
                        obj_s3_uri = f"s3://{f.bucket}/{obj_prefix}"
                        result.append((obj_name, obj_s3_uri, True))
                if files:
                    for obj in page.get("Contents", []):                # all files
                        obj_key = obj["Key"]
                        if obj_key == f.key:
                            continue
                        obj_name = obj_key.rstrip("/").split("/")[-1]
                        obj_s3_uri = f"s3://{f.bucket}/{obj_key}"
                        result.append((obj_name, obj_s3_uri, obj["Key"].endswith("/")))
        return result


    @staticmethod
    def contains_ext(uri: str, ext: str = ".ad") -> bool:
        """Contains at least one file with provided extension"""
        if not ext or not ext.startswith("."):
            raise ValueError(f"Incorrect extension provided: {ext}")
        f = to_file(uri)
        if not f or not Path.is_dir(f):
            return False
        if isinstance(f, LocalFile):
            return bool(glob.glob(os.path.join(f.path, f"**/*{ext}"), recursive=True))
        if isinstance(f, S3File):
            s3 = boto3.client('s3')
            paginator = s3.get_paginator('list_objects_v2')
            response = paginator.paginate(
                Bucket=f.bucket,
                Prefix=f.key
            )
            if not response:
                return False
            for page in response:
                if not page:
                    continue
                for obj in page.get("Contents", []):
                    obj_key = obj["Key"]
                    if obj_key == f.key:
                        continue
                    if obj_key.endswith(ext):
                        return True
        return False


def download_file_s3(f: S3File, directory: str, basename: str = '', logger: logging.Logger = None) -> LocalFile:
    if logger:
        logger.debug('downloading from s3. bucket: %s. key: %s', f.bucket, f.key)

    s3 = boto3.resource('s3')
    bb = s3.Bucket(f.bucket)

    meta_data = s3.Object(f.bucket, f.key)
    file_size = meta_data.content_length
    bytes_cnt = 0

    def _cb_func(n_bytes: int):
        nonlocal bytes_cnt
        bytes_cnt += n_bytes
        perc = bytes_cnt / file_size * 100.0
        if logger:
            logger.debug('perc: %6.2f%%', perc)

    if not basename:
        basename = PurePosixPath(f.key).name
    filename = os.path.abspath(os.path.join(directory, basename))
    bb.download_file(Key=f.key, Filename=filename, Callback=_cb_func)
    return LocalFile(path=filename)


def upload_file_s3(src: LocalFile, dst: S3File, logger: logging.Logger = None):
    if logger:
        logger.debug('uploading to s3. bucket: %s. key: %s', dst.bucket, dst.key)

    s3 = boto3.resource('s3')
    bb = s3.Bucket(dst.bucket)

    file_size = os.stat(src.path).st_size
    bytes_cnt = 0

    def _cb_func(n_bytes: int):
        nonlocal bytes_cnt
        bytes_cnt += n_bytes
        perc = bytes_cnt / file_size * 100.0
        if logger:
            logger.debug('perc: %6.2f%%', perc)

    bb.upload_file(Filename=src.path, Key=dst.key, Callback=_cb_func)


def sync_s3_to_local(uri: str, local_directory: str, max_retries: int = 10, logger: logging.Logger = None):
    """
    Sync an S3 dir to a local directory using aws s3 sync. Should be faster approach.
    """
    if not Path.is_s3(uri):
        raise ValueError("Invalid S3 URI. Must start with 's3://'")

    command = ["aws", "s3", "sync", uri, local_directory]

    for attempt in range(1, max_retries + 1):
        try:
            if logger:
                logger.debug(f"Attempt {attempt}: Syncing {uri} to {local_directory}.")
            subprocess.run(command, check=True, capture_output=True, text=True)
            return True
        except subprocess.CalledProcessError as e:
            if logger:
                logger.warning(f"Sync failed on attempt {attempt}: {e.stderr}")
            if attempt < max_retries:
                wait_time = 2 ** attempt
                if logger:
                    logger.warning(f"Retrying in {wait_time} seconds.")
                time.sleep(wait_time)
            else:
                return False


def copy_file(src: Uri|LocalFile|S3File, dst: Uri|LocalFile|S3File, logger: logging.Logger = None):
    if logger:
        logger.info(f'Copy. From: {src}. To: {dst}')
    s = src
    d = dst
    if isinstance(s, Uri):
        s = to_file(src)
    if isinstance(d, Uri):
        d = to_file(dst)
    if isinstance(s, S3File) and isinstance(d, LocalFile):
        download_file_s3(s, Path.dirname(dst), os.path.basename(dst.path), logger=logger)
    elif isinstance(s, LocalFile) and isinstance(d, LocalFile):
        shutil.copyfile(src=s.path, dst=d.path)
    elif isinstance(s, LocalFile) and isinstance(d, S3File):
        upload_file_s3(s, d, logger=logger)
    elif isinstance(s, S3File) and isinstance(d, S3File):
        s3 = boto3.resource('s3')
        do = s3.Object(d.bucket, d.key)
        do.copy_from(CopySource={'Bucket': s.bucket, 'Key': s.key})
