import argparse
import csv
import logging
import os
import subprocess
import time
from io import BytesIO
from typing import List

import smart_open as so
from elftools.elf.elffile import ELFFile

LLVM_TOOL_IFS = os.getenv('LLVM_TOOL_IFS', '/usr/bin/llvm-ifs-18')

logger: logging.Logger = logging.getLogger('sdgenerator')

def is_elf(filepath: str) -> bool:
    try:
        with so.open(filepath, 'rb') as ef:
            _ = ELFFile(ef)
            return True
    except Exception:
        return False

def extract_dynamic_symbols(elf_filepath: str) -> list[dict]:
    exported_symbols: list[dict] = []
    try:
        with so.open(elf_filepath, mode='rb') as f:
            data = f.read()
            memfile = BytesIO(data)
            elf = ELFFile(memfile)
            for section in elf.iter_sections():
                if section['sh_type'] == 'SHT_DYNSYM':
                    for symbol in section.iter_symbols():
                        bind = symbol['st_info']['bind']
                        shndx = symbol['st_shndx']
                        if bind in ('STB_GLOBAL', 'STB_WEAK') and shndx != 'SHN_UNDEF':
                            exported_symbols.append({
                                'name': symbol.name,
                                'address': symbol['st_value'],
                                'size': symbol['st_size'],
                                'binding': bind,
                                'type': symbol['st_info']['type']
                            })
    except Exception as e:
        logger.error(e)
    return exported_symbols

def find_elf_files(directory: str) -> List[str]:
    logger.info(f'finding elf files')
    elf_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            if is_elf(file_path):
                elf_files.append(file_path)
    return elf_files

def generate_stubs(elf_files: list[str], output_dir: str) -> list[str]:
    logger.info(f'generating stubs')
    stubs: list[str] = []
    stub_dir_path = f'{output_dir}/stub'
    os.makedirs(name=stub_dir_path, exist_ok=True)
    for filepath in elf_files:
        stub_elf_basename = os.path.basename(filepath)
        stub_elf_filepath = f'{stub_dir_path}/{stub_elf_basename}'
        result = subprocess.run([LLVM_TOOL_IFS, filepath, '--output-elf', stub_elf_filepath], capture_output=True, text=True, check=True)
        if result.returncode == 0:
            stubs.append(stub_elf_filepath)
    return stubs

def generate_stub_symmap(elf_filepath: str, out: str, only_symbols: set[str]) -> str:
    logger.info(f'generating stub symmap')
    elf_file_basename = os.path.basename(elf_filepath)
    symmap_basename = f'{elf_file_basename}.symmap.csv'
    symmap_filepath = os.path.join(out, symmap_basename)
    syms = extract_dynamic_symbols(elf_filepath=elf_filepath)
    with so.open(symmap_filepath, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(['name', 'long_name', 'start_address', 'size', 'namespace', 'container'])
        for sym in syms:
            if sym['name']:
                if not only_symbols:
                    writer.writerow([sym['name'], sym['name'], sym['address'], sym['size'], '', elf_file_basename])
                else:
                    if sym['name'] in only_symbols:
                        writer.writerow([sym['name'], sym['name'], sym['address'], sym['size'], '', elf_file_basename])

    return symmap_filepath

def generate_stub_callgraph(symmap_filepath: str) -> str:
    logger.info(f'generating stub callgraph')
    callgraph_filepath = symmap_filepath.replace('.symmap.csv', '.callgraph.dot')
    with so.open(callgraph_filepath, mode='w') as dotfile:
        with so.open(symmap_filepath, mode='r') as of:
            csv_reader = csv.reader(of)
            next(csv_reader)
            dotfile.write('digraph {\n')
            for row in csv_reader:
                dotfile.write(f'"{row[1]}";\n')
            dotfile.write('}')
    return callgraph_filepath

def generate_symmaps(elf_files: list[str], output_dir: str) -> list[str]:
    logger.info(f'generating symmaps')
    symmaps: list[str] = []
    symmap_dir_path = f'{output_dir}/symmap'
    os.makedirs(name=symmap_dir_path, exist_ok=True)
    for filepath in elf_files:
        generate_stub_symmap(elf_filepath=filepath, out=symmap_dir_path)
    return symmaps

def generate_stub_data(input_dir: str, output_dir: str) -> None:
    logger.info(f'generating stub data')
    original_elf_files = find_elf_files(directory=input_dir)
    stub_elf_files = generate_stubs(elf_files=original_elf_files, output_dir=output_dir)
    symmap_files = generate_symmaps(elf_files=stub_elf_files, output_dir=output_dir)

def parse_args():
    parser = argparse.ArgumentParser(prog='sdgenerator')
    parser.add_argument('--input-dir', required=True, type=str, default='', help='Path to directory where to search for elfs for stubbing.')
    parser.add_argument('--output-dir', required=True, type=str, default='', help='Path to directory where generated stubs will be stored.')
    parser.add_argument('-l', '--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], default='INFO', help='Logging level', type=lambda s: s.upper())
    args = parser.parse_args()
    return args

def main(args) -> None:
    logger.info(f'sdgenerator start')
    start_time = time.time()
    input_path = os.path.abspath(args.input_dir)
    if not os.path.exists(input_path) or not os.path.isdir(input_path):
        logger.error(f'invalid path {input_path}')
        return
    output_path = os.path.abspath(args.output)
    os.makedirs(name=output_path, exist_ok=True)
    generate_stub_data(input_dir=input_path, output_dir=output_path)
    end_time = time.time()
    total_time = round((end_time - start_time), 2)
    logger.info(f'sdgenerator done in {total_time} seconds')

if __name__ == "__main__":
    logger = logging.getLogger('sdgenerator')
    try:
        args = parse_args()
        logger.setLevel(args.log.upper())
        logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(funcName)s | %(lineno)d | %(message)s',
                            datefmt="%H:%M:%S",
                            force=True)
        main(args=args)
    except Exception as e:
        logger.error(e)
