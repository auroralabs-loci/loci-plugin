"""
ELF PLT Resolver
"""

import dataclasses
import logging
from typing import Iterator

import capstone
from elftools.elf import sections as elftools_sections
from elftools.elf.elffile import ELFFile

from . import utility


@dataclasses.dataclass
class PLTStubEntry:
    addr: int
    size: int
    symbol: elftools_sections.Symbol


def get_dyn_elf_symbols(elf: ELFFile, cs_arch: int | None, cs_mode: int | None, logger: logging.Logger) -> Iterator[PLTStubEntry]:
    cs_arch, cs_mode, cs_skipdata, cs_error = utility.get_arch_and_mode(elf=elf)

    if cs_error:
        logger.warning(cs_error)
        return None

    plt_section = elf.get_section_by_name('.plt')
    dyn_section = elf.get_section_by_name('.dynsym')
    rel_section = elf.get_section_by_name('.rela.plt') or elf.get_section_by_name('.rel.plt')

    if not(plt_section and dyn_section and rel_section):
        return

    sym_relocs = {}
    for rel in rel_section.iter_relocations():
        sym_index = rel['r_info_sym']
        got_offset = rel['r_offset']
        sym_relocs[got_offset] = dyn_section.get_symbol(sym_index)

    if not sym_relocs:
        return

    num_sym_relocs = len(sym_relocs)

    plt_code = plt_section.data()
    plt_base = plt_section['sh_addr']
    plt_entsize = plt_section['sh_entsize']
    if not plt_entsize:
        # fallback if the plt entry size is not specified in the elf
        # this may be different on a different architecture, but for
        # x86 and aarch64, in most cases it is 16
        plt_entsize = 16
        logger.info(f'setting plt_entsize: {plt_entsize}')

    md = capstone.Cs(cs_arch, cs_mode)
    md.detail = True
    md.skipdata = cs_skipdata

    for i in range(0, len(plt_code), plt_entsize):
        plt_stub = plt_code[i:i+plt_entsize]
        plt_addr = plt_base + i
        insns = list(md.disasm(plt_stub, plt_addr))
        for r_offset, sym in sym_relocs.items():
            if _match_plt_stub(insns, r_offset, plt_base, cs_arch, logger):
                yield PLTStubEntry(addr=plt_addr, size=plt_entsize, symbol=sym)
                del sym_relocs[r_offset]
                break
        if not sym_relocs:
            break

    unresolved_sym_relocs = len(sym_relocs)
    if not unresolved_sym_relocs:
        logger.info(f'dynamic symbols: {num_sym_relocs}')
    else:
        logger.warning(f'dynamic symbols: {num_sym_relocs}. unresolved: {unresolved_sym_relocs}')

    for offset, symbol in sym_relocs.items():
        logger.warning(f'unresolved symbol: {symbol.name}. got_offset: {offset}')


def _match_plt_stub(insns, r_offset, plt_base, arch: int, logger: logging.Logger):
    if insns and (insns[0].address == plt_base):
        return False # skip matching the plt resolver

    if arch == capstone.CS_ARCH_ARM64:
        for ins in insns:
            if ins.mnemonic == 'ldr' and ins.operands[1].type == capstone.CS_OP_MEM:
                if (r_offset & 0xfff) == ins.operands[1].mem.disp:
                    return True
    elif arch == capstone.CS_ARCH_X86:
        for ins in insns:
            if ins.mnemonic == 'jmp' and ins.operands[0].type == capstone.CS_OP_MEM:
                if r_offset == ins.operands[0].mem.disp:
                    return True
    else:
        logger.warning(f"PLT stub matching not implemented for arch: {arch}")
    return False
