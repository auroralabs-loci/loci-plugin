import argparse
import dataclasses
import logging
import os.path
from enum import Enum

from .utility import get_file_lines


class MapSection(Enum):
    IMAGE_SUMMARY = 1
    MODULE_SUMMARY = 2
    GLOBAL_SYMBOLS = 3


@dataclasses.dataclass
class ImageEntry:
    section: str
    base: int
    size: int
    offs: int


@dataclasses.dataclass
class ModuleEntry:
    origin: int
    size: int
    section: str
    module: str


@dataclasses.dataclass
class SymbolEntry:
    section: str
    origin: int
    size: int
    name: str


class MapContent:
    def __init__(self, img_items: list[ImageEntry], mod_items: list[ModuleEntry], sym_items: list[SymbolEntry]):
        self.img_items: list[ImageEntry] = img_items
        self.mod_items: list[ModuleEntry] = mod_items
        self.sym_items: list[SymbolEntry] = sym_items


def parse_image_entry(tokens: list[str]) -> ImageEntry|None:
    if len(tokens) != 5:
        logger.error(f'invalid image entry. tokens: {len(tokens)}')
        return None
    sect = tokens[0]
    base = int(tokens[1], base=16)
    sz_a = int(tokens[2], base=16)
    sz_b = int(tokens[3], base=10)
    offs = int(tokens[3], base=16)
    if sz_a != sz_b:
        logger.error('invalid image entry (size mismatch)')
        return None
    return ImageEntry(section=sect, base=base, size=sz_a, offs=offs)


def parse_module_entry(tokens: list[str]) -> ModuleEntry|None:
    if len(tokens) < 3:
        logger.error(f'invalid module entry. tokens: {len(tokens)}')
        return None
    origin_and_size = tokens[0].split('+')
    if len(origin_and_size) != 2:
        logger.error(f'invalid origin+size: {tokens[0]}')
        return None
    origin = int(origin_and_size[0], base=16)
    size = int(origin_and_size[1], base=16)
    section = ' '.join(tokens[1:-1])
    module = tokens[-1]
    return ModuleEntry(origin=origin, size=size, section=section, module=module)


def parse_symbol_entry(tokens: list[str]) -> SymbolEntry|None:
    if len(tokens) < 2 or len(tokens) > 3:
        logger.error(f'invalid symbol entry. tokens: {len(tokens)}. {tokens}')
        return None
    name = tokens[-1]
    origin_and_size = tokens[-2].split('+')
    if len(origin_and_size) != 2:
        logger.error(f'invalid origin+size: {tokens[0]}')
        return None
    origin = int(origin_and_size[0], base=16)
    size = int(origin_and_size[1], base=16)
    section = tokens[0] if len(tokens) == 3 else ''
    return SymbolEntry(section=section, origin=origin, size=size, name=name)


def parse_args():
    parser = argparse.ArgumentParser(prog='mapreader')
    parser.add_argument('filename', help='map file path')
    parser.add_argument('-l', '--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        default='DEBUG', help='Logging level', type=lambda s: s.upper())
    return parser.parse_args()


def process(map_file_path: str, log: logging.Logger = None) -> MapContent|None:
    global logger
    logger = log

    if not os.path.exists(map_file_path):
        logger.error(f'map file not found: {map_file_path}')
        return

    header_img_summary = ['Section', 'Base', 'Size(hex)', 'Size(dec)', 'SecOffs']
    header_mod_summary = ['Origin+Size', 'Section', 'Module']

    img_items: list[ImageEntry] = []
    mod_items: list[ModuleEntry] = []
    sym_items: list[SymbolEntry] = []

    section = None
    section_line = 0
    section_names = set()

    for line in get_file_lines(map_file_path):
        if line == 'Image Summary':
            if img_items:
                logger.error('image summary already processed')
                return
            section = MapSection.IMAGE_SUMMARY
            section_line = 0
            continue
        if line == 'Module Summary':
            if mod_items:
                logger.error('module summary already processed')
                return
            section = MapSection.MODULE_SUMMARY
            section_line = 0
            continue
        if line == 'Global Symbols (sorted numerically)':
            if sym_items:
                logger.error('global symbols already processed')
                return
            section = MapSection.GLOBAL_SYMBOLS
            section_line = 0
            continue
        if section is None:
            continue

        section_line += 1
        tokens = line.split()

        if section_line == 1:
            if section == MapSection.IMAGE_SUMMARY:
                if tokens != header_img_summary:
                    logger.error(f'invalid image summary header: {line}')
                    return
                continue
            if section == MapSection.MODULE_SUMMARY:
                if tokens != header_mod_summary:
                    logger.error(f'invalid module summary header: {line}')
                    return
                continue

        if line.startswith('Load Map '):
            section = None
            continue

        if section == MapSection.IMAGE_SUMMARY:
            item = parse_image_entry(tokens)
            section_names.add(item.section)
            img_items.append(item)
            continue

        if section == MapSection.MODULE_SUMMARY:
            item = parse_module_entry(tokens)
            mod_items.append(item)
            continue

        if section == MapSection.GLOBAL_SYMBOLS:
            item = parse_symbol_entry(tokens)
            if item.section and item.section not in section_names:
                logger.warning(f'missing section: {item.section}')
            sym_items.append(item)
            continue

    if not img_items or not mod_items or not sym_items:
        logger.warning(f'invalid map file: {map_file_path}')
        return

    return MapContent(img_items=img_items, mod_items=mod_items, sym_items=sym_items)


if __name__ == '__main__':
    main_args = parse_args()
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S")
    logger = logging.getLogger('slicer')
    logger.setLevel(main_args.log.upper())
    mc = process(map_file_path=main_args.filename, log=logger)
    logger.info(f'map: {main_args.filename}')
    logger.info(f'img: {len(mc.img_items)}')
    logger.info(f'mod: {len(mc.mod_items)}')
    logger.info(f'sym: {len(mc.sym_items)}')
