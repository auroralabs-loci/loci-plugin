"""
Module Name: tdv.py
Description: This module validates processed trace data, performing a basic Sanity Check by default and an
             Execution Check using a Symbolic Executor. For the latter, manual adjustments may be required
             mainly when it comes to indirect calls that the trace has caught or incorrectly concluded
             execution paths by the Symbolic Executor.

Prerequisite: Install requirements.txt and test/requirements.txt

Running TestCase steps:
1. Download test bundle. s3://aurora-storage-sk/yocto_traces_20241121_reprocessed_excl_idle_time/Yocto_S32g2-01_A53_traces_tar_0_full.7z
2. Run tdv.py with --shrunk-trace option to get first TEST_NUM_CTXS contexts.
    ``` python3 ./tdv.py -b ~/Downloads/Yocto_S32g2-01_A53_traces_tar_0_full_test/ -s ```
3. Rename full trace32_full_trace_data.csv to any non-csv file so that tdv.py doesn't recognize it (ex. trace32_full_trace_data.xcsv)
4. Run tdv.py with execution validator to validate test bundle.
    ``` python3 ./tdv.py -b ~/Downloads/Yocto_S32g2-01_A53_traces_tar_0_full_test/ -e ```
"""

import argparse
import logging
import os
import sys
from dataclasses import dataclass, field

import angr
import capstone
import claripy
import pandas as pd
from angr.engines.successors import SimSuccessors
from elftools.elf.elffile import ELFFile
from rich import progress

from . import utility

logger = None

SUPPORTED_ARCHITECTURES = ['EM_AARCH64']
SUPPORTED_ARCHITECTURES_INSN_SIZE = {
    'EM_AARCH64': 4
}

CONTEXT_START = ' _ '
CONTEXT_END = '->'
NO_CONTAINER_SUFFIX = ':_'

MANUAL_ADDRESS_HOOKS: dict[str, dict[int, int]] = {
    'ffb6df5095ea67b6f952696a232799a6' : { # CtApRuntimeTests_PH00
        0x41ba84 : 0x41ba8c
    },
    '85ed8c4060ec16f907b35d582c0a368f' : { # libc.so.6
        0x7444c : 0x74450,
        0x7509c : 0x750a8,
        0x73d60 : 0x73d64,
        0xd7d3c : 0xd7d40,
        0xd7e0c : 0xd7e10,
        0x8dc00 : 0x8dc44,
        0x74208 : 0x74250,
        0xd726c : 0xd7270,
        0x74468 : 0x7448c,
        0xd8588 : 0xd858c,
        0x8af9c : 0x8afa0,
        0x8afe8 : 0x8b28c,
        0x8af74 : 0x8af78
    },
    '94e034fc7cb41223824d1f268ed42a70' : { # tar
        0x404d0 : 0x404d4,
        0x404d8 : 0x40504
    }
}

TEST_NUM_CTXS = 2
PROGRESS_WIDGETS = [
    progress.TaskProgressColumn(),
    progress.BarColumn(),
    progress.TextColumn("Elapsed Time:"),
    progress.TimeElapsedColumn(),
    progress.TextColumn("Time:"),
    progress.TimeRemainingColumn(),
    progress.TextColumn("{task.description}"),
]

"""
------------------------------------------------------------------------------------------------
Section for parsing and storing trace data
------------------------------------------------------------------------------------------------
"""

@dataclass
class BaseValidator:
    @classmethod
    def fatal_error(cls, reason: str, elf: str = ''):
        logger.error(f"{f'{elf} |' if elf else ''} {cls.__name__} validation failed. {reason}")


@dataclass
class SanityValidator(BaseValidator):
    @dataclass
    class ContextSanityData:
        link_idx: int = -1
        prev: str = None
        fr: str = None
        to: str = None
        s1_container: str = None
        s2_container: str = None
        prev_container: str = None
        finished: bool = field(init=False, default=False)

    context_data: dict[int, ContextSanityData] = field(init=False, default_factory=dict)

    def validate(self, row: pd.Series, progress: progress.Progress) -> bool:
        path_id = row['r.path_ids']
        ctx_id = int(path_id.split('_')[-1])
        link_idx = int(row['r.link_idx'])
        prev_name = row['r.prev_name']
        from_name = row['s1.name']
        to_name = row['s2.name']
        s1_container = row['s1.container']
        s2_container = row['s2.container']
        prev_container = row['r.prev_container']
        delta = row['r.delta_dt']
        cycles = row['r.cyc']
        from_addr = row['r.from_addr'] if 'r.from_addr' in row else None
        to_addr = row['r.to_addr'] if 'r.to_addr' in row else None


        if ctx_id not in self.context_data:
            if not SanityValidator.check_context_begin(prev_name):
                self.fatal_error(reason=f"Invalid context start: {{{prev_name}}}/{{{from_name}}}. Expected {CONTEXT_START}")
                return False
            self.context_data[ctx_id] = SanityValidator.ContextSanityData(link_idx, prev_name, from_name, to_name, s1_container, s2_container, prev_container)
        else:
            ctx: SanityValidator.ContextSanityData = self.context_data[ctx_id]
            if ctx.finished:
                self.fatal_error(reason=f"Unexpected occurrence of {CONTEXT_END} in the middle of the context")
                return False
            if prev_name != ctx.fr:
                self.fatal_error(reason=f"Detected mismatch between 'prev_name' and context's last 'from_name'")
                return False
            if from_name != ctx.to:
                self.fatal_error(reason=f"Detected mismatch between 'from_name' and context's last 'to_name'")
                return False
            if prev_container != ctx.s1_container:
                self.fatal_error(reason=f"Previous container '{prev_container}' different from last link's s1 container '{ctx.s1_container}'")
                return False
            if s1_container != ctx.s2_container:
                self.fatal_error(reason=f"s1 container '{s1_container}' different from last context's s2 container '{ctx.s2_container}'")
                return False
            if delta < 0:
                self.fatal_error(reason=f"Delta {delta} value is negative")
                return False
            if cycles < 0:
                self.fatal_error(reason=f"Cycles {cycles} value is negative")
                return False
            if link_idx != ctx.link_idx + 1:
                self.fatal_error(reason=f"Link index is not incremented for one digit. Was: {ctx.link_idx}. Is: {link_idx}")
                return False
            if bool(from_addr) ^ bool(to_addr):
                self.fatal_error(reason=f"Address ranges error - 'r.from_addr' and 'r.to_addr' should always be either both set or both unset")
                return False
            if from_addr and to_addr:
                try:
                    fa = [int(a, 16) for a in from_addr.split('|')]
                    ta = [int(a, 16) for a in to_addr.split('|')]
                    if len(fa) != len(ta):
                        self.fatal_error(reason=f"Address ranges error - 'r.from_addr' and 'r.to_addr' range size mismatch")
                        return False
                except ValueError:
                    self.fatal_error(reason=f"Address ranges error - addresses must be numeric: {{{from_addr}}}, {{{to_addr}}}.")
                    return False
            ctx.link_idx = link_idx
            ctx.prev = prev_name
            ctx.s1_container = s1_container
            ctx.s2_container = s2_container
            ctx.prev_container = prev_container
            ctx.fr = from_name
            ctx.to = to_name
            if ctx.to == CONTEXT_END:
                ctx.finished = True
        return True

    @staticmethod
    def check_context_begin(data: str) -> bool:
        return data == CONTEXT_START

    @staticmethod
    def check_context_end(data: str) -> bool:
        return data == CONTEXT_END


class ExecutionValidator(BaseValidator):
    def __init__(self, elf: str, is_elf_pic: bool, arch: str):
        self.elf: str = elf
        self.arch: str = arch
        if not self.elf or not os.path.isfile(self.elf):
            raise RuntimeError(f"ExecutionValidator initialization failed. ELF does not exist: {self.elf}.")
        self.angr_setup(is_elf_pic)


    def initialize_cfg(self, elf_hash: str) -> angr.analyses.cfg.CFGFast:
        if not self.project:
            return
        cfg = None
        cache_path = os.path.join(utility.get_cache_dir(), 'validator')
        if not os.path.exists(cache_path):
            os.mkdir(cache_path)
        cfg_pkl = os.path.join(cache_path, f"{elf_hash}.pkl")
        if os.path.exists(cfg_pkl):
            logger.debug(f'Loading CFG for {os.path.basename(self.elf)}')
            return utility.load_from_pickle(cfg_pkl)
        logger.debug(f'Generating CFG for {os.path.basename(self.elf)}')
        cfg = self.project.analyses.CFGFast(show_progressbar=True)
        utility.pickle_and_dump(cfg_pkl, cfg)
        return cfg


    def angr_setup(self, is_elf_pic: bool):
        elf_hash = utility.hash_file_xxh128(self.elf)
        self.project: angr.Project = angr.Project(self.elf, main_opts={'base_addr': 0} if is_elf_pic else {})
        self.cfg:angr.analyses.cfg.CFGFast = self.initialize_cfg(elf_hash)

        if elf_hash in MANUAL_ADDRESS_HOOKS:
            for fr_addr, to_addr in MANUAL_ADDRESS_HOOKS[elf_hash].items():
                def _hook_func(state):
                    to_state = self.project.factory.blank_state(addr=MANUAL_ADDRESS_HOOKS[elf_hash][state.addr])
                    print(f'Using manually hooked states. {state} -> {to_state}.')
                    self.next = [to_state]
                self.project.hook(fr_addr, _hook_func)


    def validate_addr(self, addr: int):
        for state in self.next:
            if state.addr == addr:
                try:
                    state.options.add(angr.options.LAZY_SOLVES) # Increased path explosion risk
                    sim_successors: SimSuccessors = self.project.factory.successors(state, num_inst=1)
                    self.next = sim_successors.successors
                    # if state.solver.symbolic(state.regs.pc) or any(state.solver.symbolic(getattr(state.regs, reg.name)) for reg in state.arch.register_list):
                    #     logger.warning(f"State at {hex(state.addr)} contains symbolic values!")
                    state.step()
                except angr.errors.SimError as error:
                    self.fatal_error(elf=self.elf, reason=f"Error: {error} State: {state}. Addr: {hex(addr)}. Next: {self.next}. Elf: {self.elf}")
                    return False
                except claripy.errors.ClaripyTypeError as error:
                    self.fatal_error(elf=self.elf, reason=f"Error: {error} State: {state}. Addr: {hex(addr)}. Next: {self.next}. Elf: {self.elf}")
                    return False
                return True
        return False


    def insn_data(self, trace_addr):
        is_return, is_indirect_call = False, False
        block: angr.Block = self.project.factory.block(trace_addr)
        if block and block.capstone.insns:
            last_insn: capstone.CsInsn = block.capstone.insns[-1]
            if last_insn.mnemonic == 'ret':
                is_return = True
            if last_insn.mnemonic == 'blr':
                is_indirect_call = True
        return is_return, is_indirect_call


    def validate(self, path_id: str, trace_addrs: list[int], progress: progress.Progress) -> bool:
        if not trace_addrs:
            logger.warning(f"No trace addresses for path: {path_id}. elf: {self.elf}")
            return True
        state: angr.SimState = self.project.factory.blank_state(addr=trace_addrs[0])
        self.next: list[angr.SimState] = [state]
        i = 0
        prev_func = None
        curr_func = None
        def _run_flow_recovery() -> list[angr.SimState]:
            trace_addr = trace_addrs[i]
            prev_return, prev_indirect_call = self.insn_data(trace_addrs[i - 1])
            if not prev_return and not prev_indirect_call:
                progress.stop()
                logger.warning(f'Manual validation required. If the trace appears correct, proceed with hooking. Path: {path_id}. Elf: {self.elf}. Addrs: {hex(trace_addrs[i - 1])} -> {hex(trace_addr)}')
                return []
            if prev_indirect_call:
                print(f'Encountered an indirect call. Assuming target resolution is correct.')
                state = self.project.factory.blank_state(addr=trace_addr)
                return [state]
            if prev_return:
                if not prev_func:
                    self.fatal_error(elf=self.elf, reason=f"Failed to recover incorrect data flow: Missing previous function")
                    return []
                if not curr_func:
                    self.fatal_error(elf=self.elf, reason=f"Failed to recover incorrect data flow: Missing current function")
                    return []
                # check if the previous address within this symbol, was jump to the previous symbol
                prev_addr = trace_addr - SUPPORTED_ARCHITECTURES_INSN_SIZE[self.arch]
                calls = prev_func.get_call_sites()
                if not calls:
                    self.fatal_error(elf=self.elf, reason=f"Failed to recover incorrect data flow. Returning to function with no calls. Prev trace addr: {hex(trace_addrs[i - 1])}. Curr trace addr: {hex(trace_addr)}.")
                    return []
                for call in calls:
                    addr_of_call = self.project.factory.block(call).capstone.insns[-1].address
                    callee = prev_func.get_call_target(call)
                    if addr_of_call == prev_addr:
                        if callee != curr_func:
                            self.fatal_error(elf=self.elf, reason=f"Failed to recover incorrect data flow. Returning function never calls traced function.")
                            return []
                        break
                state = self.project.factory.blank_state(addr=trace_addr)
                return [state]
            return []
        while i >= 0 and i <= (len(trace_addrs) - 1):
            trace_addr = trace_addrs[i]
            prev_func = curr_func
            curr_func = self.cfg.functions.floor_func(trace_addr)
            correct = self.validate_addr(trace_addr)
            if not correct:
                if i == 0:
                    self.fatal_error(elf=self.elf, reason='Invalid first trace address.')
                    return False
                self.next = _run_flow_recovery()
                if not self.next:
                    self.fatal_error(elf=self.elf, reason='Incorrect trace data flow')
                    return False
                continue
            progress.advance(task_id=0)
            i += 1
        return True


"""
------------------------------------------------------------------------------------------------
Section for parsing and storing trace data
------------------------------------------------------------------------------------------------
"""


class TraceDataValidator:
    """ TraceData class that serves as parser and storage of essential context data that is to be validated. """
    @dataclass
    class ContextData:
        id: int
        elf: str
        trace_addrs: list[int] = field(init=False, default_factory=list)


    def __init__(self, file: str, elfs: dict[str, bool], run_execution_validator: bool, arch: str):
        self.elfs = elfs
        self.file: str = file
        self.arch: str = arch
        self.sanity_validator: SanityValidator = SanityValidator()
        self.execution_validators: dict[str, ExecutionValidator] = {} if run_execution_validator else None


    @staticmethod
    def is_trace_file(trace: str) -> bool:
        if not trace or not os.path.isfile(trace) or not trace.endswith('.csv'):
            return False
        header = pd.read_csv(trace, nrows=0).columns.to_list()
        return 'r.prev_name' in header and \
            's1.name' in header and \
            's2.name' in header and \
            's1.container' in header and \
            's1.long_name' in header and \
            's2.container' in header and \
            's2.long_name' in header and \
            'r.dt' in header and \
            'r.delta_dt' in header and \
            'r.cyc' in header and \
            'r.prev_container' in header and \
            'r.prev' in header and \
            'r.prev_delta_dt' in header and \
            'r.prev_cyc' in header and \
            'r.ctx_switch' in header and \
            'r.is_lbl' in header and \
            'r.type' in header and \
            'r.path_ids' in header and \
            'r.link_idx'


    def get_addrs_in_range(self, from_addrs: str, to_addrs: str) -> list:
        if not from_addrs and not to_addrs:
            return []
        fa = from_addrs.split('|')
        ta = to_addrs.split('|')
        if len(fa) != len(ta):
            # covered by SanityValidator
            return []
        addrs = []
        insn_size = SUPPORTED_ARCHITECTURES_INSN_SIZE[self.arch]
        for idx, addr in enumerate(fa):
            fr_addr = int(addr, 16)
            to_addr = int(ta[idx], 16)
            sub_addrs = []
            for insn_addr in range(fr_addr, to_addr + insn_size, insn_size):
                sub_addrs.append(insn_addr)
            # logger.debug(f'{addr} - {ta[idx]}. Addrs: {[hex(s) for s in sub_addrs]}')
            addrs.extend(sub_addrs)
        return addrs


    def update_contexts(self, row: pd.Series, contexts: dict[str, list[ContextData]]):
        path_id = row['r.path_ids']
        id = int(path_id.split('_')[-1])
        elf_name = row['s1.container'].split(':')[1]
        elf_path = ''
        for elf in self.elfs:
            if elf_name == os.path.basename(elf):
                elf_path = elf
                break
        if not elf_path:
            raise RuntimeError(f"Cannot match elf path in bundle from trace data elf basename {elf_name}.")
        if not path_id in contexts:
            contexts[path_id] = [TraceDataValidator.ContextData(id, elf_path)]
        expanded_addrs = self.get_addrs_in_range(row['r.from_addr'], row['r.to_addr'])
        last_elf = contexts[path_id][-1].elf
        if last_elf != elf_path:
            contexts[path_id].append(TraceDataValidator.ContextData(id, elf_path))
        contexts[path_id][-1].trace_addrs.extend(expanded_addrs)


    def validate(self) -> bool:
        contexts: dict[str, list[TraceDataValidator.ContextData]] = {}
        if not self.file or not os.path.isfile(self.file):
            logger.error(f'Trace file {self.file} does not exist')
            return False
        df = pd.read_csv(self.file)

        sanity_progress = initialize_progress_bar(title='Sanity Validation', total=df.shape[0])
        sanity_progress.start()
        for idx, row in df.iterrows():
            if not self.sanity_validator.validate(row, progress=sanity_progress):
                return False
            if self.execution_validators is not None:
                self.update_contexts(row, contexts)
            sanity_progress.advance(task_id=0)
        sanity_progress.stop()
        logger.info('Sanity Validation Completed Successfully')

        if contexts:
            logger.info(f'Preparing Execution Validators')
            for _, sub_contexts in contexts.items():
                for context in sub_contexts:
                    if context.elf not in self.execution_validators:
                        self.execution_validators[context.elf] = ExecutionValidator(context.elf, self.elfs[context.elf], self.arch)
                        if len(self.elfs) == len(self.execution_validators):
                            # all possible execution validators have been initialized
                            break
            logger.info('Running Execution Validation')
            for _idx, [path_id, sub_contexts] in enumerate(contexts.items()):
                exec_progress = initialize_progress_bar(title=f"Execution Validation of {path_id}", total=sum([len(c.trace_addrs) for c in sub_contexts]))
                exec_progress.start()
                for context in sub_contexts:
                    if not self.execution_validators[context.elf].validate(path_id, context.trace_addrs, exec_progress):
                        exec_progress.stop()
                        logger.error(f"Execution validation failed for path: {path_id}. elf: {context.elf}")
                        return False
                exec_progress.stop()
            logger.info('Execution Validation Completed Successfully')
        return True


"""
------------------------------------------------------------------------------------------------
Global utils section
------------------------------------------------------------------------------------------------
"""


def parse_args():
    parser = argparse.ArgumentParser(prog='TraceDataValidator',
                                    description='Validator of processed trace data execution flow.')

    parser.add_argument('-b', '--bundle',
                        required=True,
                        help='Path to a processed bundle as generated by TraceDataProcessor (TDP).')

    parser.add_argument('-e', '--run-execution-validator',
                        action='store_true',
                        default=False,
                        help='Run execution validator which will perform Symbolic Execution. Experimental.')

    parser.add_argument('-s', '--shrink-trace',
                        action='store_true',
                        default=False,
                        help='Shrink trace data for testing.')

    return parser.parse_args()


def get_bundle_data(bundle: str):
    if not bundle or not os.path.isdir(bundle):
        raise RuntimeError(f"Error parsing arguments. Bundle path {bundle} is not a directory.")
    arch = ''
    trace = ''
    symbols = ''
    elfs: dict[str, bool] = {}
    for entry in os.listdir(bundle):
        entry_path = os.path.realpath(os.path.join(bundle, entry))
        if not trace and TraceDataValidator.is_trace_file(entry_path):
            trace = entry_path
        elif not symbols and os.path.isdir(entry_path) and entry == 'symbols':
            symbols = entry_path
        if trace and symbols:
            break

    if symbols:
        for entry in os.listdir(symbols):
            entry_path = os.path.realpath(os.path.join(symbols, entry))
            with open(entry_path, 'rb') as file:
                if file.read(4) == b'\x7fELF':
                    elf = ELFFile(file)
                    elf_arch = elf.header['e_machine']
                    if elf_arch in SUPPORTED_ARCHITECTURES:
                        if arch and elf_arch != arch:
                            logger.warning(f"ELF architecture {{{elf_arch}}} mismatch with previous {{{arch}}}. Skipping elf and proceeding with first encountered architecture.")
                            continue
                        elif not arch:
                            arch = elf_arch
                        elfs[entry_path] = utility.is_pic(elf)

    return trace, elfs, arch


def validate(bundle: str, logger_obj: logging.Logger) -> bool:
    global logger
    logger = logger_obj

    trace, elfs, arch = get_bundle_data(args.bundle)
    if not trace or not elfs:
        logger.error(f"Bundle structure is incorrect or the architecture is not supported for validation.")
        return False

    align = 6
    msg = f"Validating data\n{'-'*50}\n"
    msg += f"{'Bundle'.ljust(align)} | {bundle}\n"
    msg += f"{'Trace'.ljust(align)} | {os.path.basename(trace)}\n"
    for idx, elf in enumerate(elfs):
        msg += f"{'ELF'.ljust(align)} | {os.path.basename(elf)}"
        if idx < len(elfs) - 1:
            msg += "\n"
    logger.info(msg)
    tdv = TraceDataValidator(file=trace, elfs=elfs, run_execution_validator=args.run_execution_validator, arch=arch)
    return tdv.validate()


def initialize_progress_bar(title: str, total: int):
    progressbar = progress.Progress(*PROGRESS_WIDGETS)
    _task_id = progressbar.add_task(description=title, total=total)
    return progressbar


def silence_loggers():
    external_loggers = [
        'cle.loader',
        'cle.backends.externs',
        'cle.backends.elf.elf',
        'angr.analyses.cfg.cfg_fast',
        'angr.analyses.propagator.engine_vex.SimEnginePropagatorVEX',
        'angr.simos.userland',
        'angr.engines.successors',
        'angr.analyses.cfg.cfg_base',
        'angr.storage.memory_mixins.default_filler_mixin',
    ]
    for ext_logger_name in external_loggers:
        logging.getLogger(name=ext_logger_name).setLevel(logging.FATAL)


def shrink_trace_data(trace: str) -> str:
    if not trace or not os.path.isfile(trace):
        return
    df = pd.read_csv(trace)
    ends = tuple([f"_{str(e)}" for e in range(TEST_NUM_CTXS)])
    shrunk_csv = os.path.join(os.path.dirname(trace), f"test_{os.path.basename(trace)}")
    filtered = df[df["r.path_ids"].astype(str).str.endswith(ends)]
    filtered.to_csv(shrunk_csv)
    return shrunk_csv


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S")
    logger = logging.getLogger('tdv')
    logger.setLevel('DEBUG')
    args = parse_args()
    silence_loggers()

    if args.shrink_trace:
        trace, _, _ = get_bundle_data(args.bundle)
        shrunk_trace = shrink_trace_data(trace)
        logger.info(f"Shrunk test trace: '{shrunk_trace}'")
        sys.exit(0)
    if not validate(bundle=args.bundle, logger_obj=logger):
        sys.exit(1)
