"""
ELF Symbol Extractor
"""

# pylint: disable=too-many-locals
# pylint: disable=too-many-branches
# pylint: disable=too-many-arguments
# pylint: disable=too-many-statements
# pylint: disable=too-many-instance-attributes

import argparse
import csv
import dataclasses
import logging
import os
import sys
from abc import ABC, abstractmethod
from enum import Enum
from typing import Callable, Iterator

import capstone
import elftools.elf.sections
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection

from . import utility

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROGRAM_NAME = os.path.splitext(os.path.basename(os.path.abspath(__file__)))[0]

logger = logging.getLogger(PROGRAM_NAME)

class SymbolType(Enum):
    NOTYPE = 0
    OBJECT = 1
    FUNC = 2
    SECTION = 3
    FILE = 4
    COMMON = 5
    TLS = 6
    LOOS = 10
    HIOS = 12
    LOPROC = 13
    SPARC_REGISTER = 13
    HIPROC = 15
    UNKNOWN = 20

class SymbolStatus(Enum):
    OK = 0
    NO_SECTION = 1
    BAD_SECTION = 2

@dataclasses.dataclass
class ElfSymbol:
    beg: int
    end: int
    size: int
    name: str

@dataclasses.dataclass
class ElfSection:
    beg: int
    end: int
    size: int
    name: str
    type: str
    exec: bool
    data: bytes

@dataclasses.dataclass
class Symbol:
    addr: int
    size: int
    data: bytes
    type: SymbolType
    bind: str
    name: str
    name_short: str
    name_long: str
    namespace: str
    status: SymbolStatus

def print_line(line: str = '', is_error: bool = False):
    """
        print a line on the starndard output or standard error
        if an exception is thrown shutdown gracefully. this may happen if
        the stream was closed prematurely, e.g., if we pipe the output to
        the head command or another command that does not read the output
        to the end
    """
    try:
        file = sys.stderr if is_error else sys.stdout
        print(line, file=file)
    except (BrokenPipeError, IOError):
        sys.exit(0)

def create_cs(elf: ELFFile, architecture: str = '') -> capstone.Cs:
    arch, mode, skip, error = utility.get_arch_and_mode(elf=elf, architecture=architecture)
    if error:
        raise RuntimeError(error)
    md = capstone.Cs(arch=arch, mode=mode)
    md.detail = False
    md.skipdata = skip
    return md

class SymbolHandler(ABC):
    @abstractmethod
    def handle(self, s: Symbol):
        pass

    @abstractmethod
    def close(self):
        pass

class CSVSymbolHandler(SymbolHandler):
    def __init__(self, elf_path: str, out_path: str):
        self._csv_file = open(CSVSymbolHandler._get_output_file(elf_path=elf_path, out_path=out_path), 'w', encoding='utf8')
        self._csv_writer = csv.writer(self._csv_file)
        self._csv_writer.writerow(['symbol', 'name', 'long_name', 'start_address', 'size', 'namespace'])

    @staticmethod
    def _get_output_file(elf_path: str, out_path: str) -> str:
        if not elf_path:
            raise RuntimeError('empty elf path')
        filename: str = os.path.basename(elf_path)
        if not filename:
            raise RuntimeError(f'empty csv filename. elf: {elf_path}')
        if not out_path:
            out_path = SCRIPT_DIR
        directory: str = os.path.expanduser(out_path)
        if os.path.isfile(directory):
            raise RuntimeError(f'file exists at the output directory: {directory}')
        os.makedirs(directory, exist_ok=True)
        if not os.path.isdir(directory):
            raise RuntimeError(f'failed to create directory: {directory}')
        csv_filepath = os.path.abspath(os.path.normpath(os.path.join(directory, filename + '.csv')))
        logger.info(f'CSV: {csv_filepath}')
        return csv_filepath

    def handle(self, s: Symbol):
        if s.status == SymbolStatus.OK:
            self._csv_writer.writerow([s.name, s.name_short, s.name_long, s.addr, s.size, s.namespace])

    def close(self):
        self._csv_file.close()
        self._csv_file = None
        self._csv_writer = None

class StdSymbolHandler(SymbolHandler):
    def __init__(self, elf: ELFFile, disasm: bool = False):
        self._cs = create_cs(elf) if disasm else None
        self._em: dict[str, int]|None = {} if disasm else None
        print_line('  address   size      type      name')

    def handle(self, s: Symbol):
        prefix = ' '
        if s.status == SymbolStatus.NO_SECTION:
            prefix = 'N'
        if s.status == SymbolStatus.BAD_SECTION:
            prefix = 'B'
        print_line(f'{prefix} {s.addr:08x}  {s.size:08x}  {s.type.name:8}  {s.name:30}')

        if self._cs and s.status == SymbolStatus.OK and s.type == SymbolType.FUNC and s.data is not None:
            self._dump_asm(addr=s.addr, size=s.size, data=s.data)

    def close(self):
        if self._em is not None:
            print_line(f'end_mnemonics: {self._em}')

    def _dump_asm(self, addr: int, size: int, data: bytes):
        if size != len(data):
            raise RuntimeError(f'size: {size}. data: {len(data)}')
        if size == 0:
            print_line('...')
        else:
            total_size: int = 0
            end_mnemonic: str = ''
            for i_addr, i_size, i_mnemonic, i_op_str in self._cs.disasm_lite(data, addr):
                print_line(f'{i_addr:08x}  {i_size:02x}  {i_mnemonic} {i_op_str}')
                end_mnemonic = i_mnemonic
                total_size += i_size
            if total_size != size:
                raise RuntimeError(f'size: {size}. processed: {total_size}')
            if self._em is not None:
                self._em[end_mnemonic] = self._em.get(end_mnemonic, 0) + 1
        print_line()

def _is_flag_set(n: int, flag: int) -> bool:
    return (n & flag) == flag

def get_sections(elf: ELFFile) -> list[ElfSection]:
    sections: list[ElfSection] = []
    for sec in elf.iter_sections():
        sec_beg = int(sec.header['sh_addr'])
        sec_len = int(sec.header['sh_size'])
        sec_end = sec_beg + sec_len - 1
        sec_type = sec.header['sh_type']
        sec_exec = _is_flag_set(sec.header['sh_flags'], elftools.elf.sections.SH_FLAGS.SHF_EXECINSTR)
        sec_name = sec.name
        es = ElfSection(beg=sec_beg, end=sec_end, size=sec_len, name=sec_name, type=sec_type, exec=sec_exec, data=sec.data())
        sections.append(es)
    return sections

def get_symbols(elf: ELFFile) -> Iterator[elftools.elf.sections.Symbol]:
    for section in elf.iter_sections():
        if isinstance(section, SymbolTableSection):
            yield from section.iter_symbols()

def _get_align_section_indices(sections: list[ElfSection]) -> list[tuple[int, int]]:
    align_suffixes = ['_ALIGN', '_SEC']
    rom_sec_suffixes = ['_ROM_SEC']

    alg_sec: list[tuple[int, str]] = []
    rom_sec: list[tuple[int, str]] = []

    for i, s in enumerate(sections):
        if s.exec:
            if s.type == 'SHT_PROGBITS':
                for suffix in rom_sec_suffixes:
                    if s.name.endswith(suffix):
                        rom_sec.append((i, suffix))
        else:
            if s.type == 'SHT_NOBITS':
                for suffix in align_suffixes:
                    if s.name.endswith(suffix):
                        alg_sec.append((i, suffix))

    result: list[tuple[int, int]] = []
    for alg_idx, alg_suffix in alg_sec:
        alg = sections[alg_idx]
        base_name = alg.name[:-len(alg_suffix)]
        for rom_idx, rom_suffix in rom_sec:
            rom = sections[rom_idx]
            if rom.name[:-len(rom_suffix)] == base_name:
                result.append((alg_idx, rom_idx))
                break

    return result

def _remap_symbol(sections: list[ElfSection], align_section_indices: list[tuple[int, int]], symbol_addr: int, symbol_type: SymbolType) -> tuple[int, int, str]:
    index: int = 0
    for section in sections:
        if section.beg <= symbol_addr <= section.end:
            break
        index += 1

    if index == len(sections):
        index = -1

    if index == -1:
        return index, symbol_addr, f'addr. unmatched: {symbol_addr:08x}'

    if symbol_type != SymbolType.FUNC:
        # no need to remap - the symbol is not a function
        return index, symbol_addr, ''

    if sections[index].exec and sections[index].type == 'SHT_PROGBITS':
        # no need to remap - the symbol is in executable section
        return index, symbol_addr, ''

    if align_section_indices:
        for alg_idx, rom_idx in align_section_indices:
            alg_sec, rom_sec = sections[alg_idx], sections[rom_idx]
            if alg_sec.beg <= symbol_addr < alg_sec.beg + rom_sec.size:
                rom_sec_off = symbol_addr - alg_sec.beg - alg_sec.size
                remapped_addr = rom_sec.beg + rom_sec_off
                return rom_idx, remapped_addr, ''
        return index, symbol_addr, f'failed to remap: {symbol_addr:08x}'

    return index, symbol_addr, f'no good section: {symbol_addr:08x}'

def _get_symbol_type(type_str: str) -> SymbolType:
    elf_type_to_sym_type = {
        'STT_NOTYPE': SymbolType.NOTYPE,
        'STT_OBJECT': SymbolType.OBJECT,
        'STT_FUNC': SymbolType.FUNC,
        'STT_SECTION': SymbolType.SECTION,
        'STT_FILE': SymbolType.FILE,
        'STT_COMMON': SymbolType.COMMON,
        'STT_TLS': SymbolType.TLS,
        'STT_LOOS': SymbolType.LOOS,
        'STT_HIOS': SymbolType.HIOS,
        'STT_LOPROC': SymbolType.LOPROC,
        'STT_SPARC_REGISTER': SymbolType.SPARC_REGISTER,
        'STT_HIPROC': SymbolType.HIPROC,
    }
    if type_str in elf_type_to_sym_type:
        return elf_type_to_sym_type[type_str]
    logger.warning(f'unknown symbol type: {type_str}')
    return SymbolType.UNKNOWN

def _process_elf(elf: ELFFile, filename: str, include_functions: bool, include_variables: bool, symbol_handlers: tuple[SymbolHandler], callback: Callable[[int,Symbol],None]):
    logger.info(f'ELF: {filename}')
    num_functions: int = 0
    num_variables: int = 0
    num_func_nidx: int = 0
    num_func_bidx: int = 0
    stt_file = ''
    sections: list[ElfSection] = get_sections(elf)
    align_section_indices: list[tuple[int, int]] = _get_align_section_indices(sections=sections)
    for elf_symbol in get_symbols(elf):
        symbol_name = elf_symbol.name
        symbol_addr = elf_symbol.entry.st_value
        symbol_size = elf_symbol.entry.st_size
        symbol_bind = elf_symbol.entry.st_info.bind
        symbol_type = _get_symbol_type(elf_symbol.entry.st_info.type)
        if symbol_type == SymbolType.FILE:
            stt_file = symbol_name
            continue
        skip_symbol: bool = True
        is_function: bool = symbol_type == SymbolType.FUNC
        is_variable: bool = symbol_type == SymbolType.OBJECT
        if is_function:
            if not include_functions:
                continue
            num_functions += 1
            skip_symbol = False
        if is_variable:
            if not include_variables:
                continue
            num_variables += 1
            skip_symbol = False
        if skip_symbol:
            continue
        if symbol_bind == 'STB_LOCAL':
            symbol_name = f'{stt_file}_{symbol_name}'
        original_symbol_addr = symbol_addr
        sec_index, real_addr, remap_error = _remap_symbol(sections=sections,
            align_section_indices=align_section_indices, symbol_addr=symbol_addr, symbol_type=symbol_type)
        if remap_error:
            logger.warning(f'{remap_error}. type: {symbol_type.name}. name: {symbol_name}')
        if symbol_addr != real_addr:
            symbol_addr = real_addr
        status = SymbolStatus.OK

        section: ElfSection|None = None

        if sec_index == -1:
            status = SymbolStatus.NO_SECTION
            num_func_nidx += 1
        elif remap_error:
            status = SymbolStatus.BAD_SECTION
            num_func_bidx += 1
            section = sections[sec_index]
        else:
            section = sections[sec_index]

        symbol_data: bytes|None = None
        if status == SymbolStatus.OK and section:
            data_beg = symbol_addr - section.beg
            data_end = data_beg + symbol_size
            symbol_data = section.data[data_beg:data_end]

        symbol = Symbol(addr=symbol_addr,
                        size=symbol_size,
                        data=symbol_data,
                        type=symbol_type,
                        bind=symbol_bind,
                        name=symbol_name,
                        name_short=symbol_name,
                        name_long=symbol_name,
                        namespace='',
                        status=status)

        if callback:
            callback(original_symbol_addr, symbol)

        for handler in symbol_handlers:
            handler.handle(symbol)

    if include_variables:
        logger.info(f'variables: {num_variables}')

    if include_functions:
        logger.info(f'functions: {num_functions}')
        if num_func_nidx:
            logger.warning(f'no section index: {num_func_nidx}')
        if num_func_bidx:
            logger.warning(f'bad section index: {num_func_bidx}')

def _create_symbol_handlers(elf: ELFFile, elf_path: str, output_symmap_dir: str, silent: bool, disasm: bool) -> tuple[SymbolHandler]:
    symbol_handlers: list[SymbolHandler] = []
    if not silent:
        symbol_handlers.append(StdSymbolHandler(elf=elf, disasm=disasm))
    if output_symmap_dir:
        symbol_handlers.append(CSVSymbolHandler(elf_path=elf_path, out_path=output_symmap_dir))
    return tuple(symbol_handlers)

def process_file(filepath, include_functions: bool = True, include_variables: bool = True, output_symmap_dir: str = '', silent: bool = False, disasm: bool = False, callback: Callable[[int,Symbol], None] = None):
    if not utility.is_elf_file(filepath):
        raise RuntimeError(f'file is not elf: {filepath}')
    with open(filepath, 'rb') as fh:
        elf = ELFFile(fh)
        symbol_handlers: tuple[SymbolHandler] = _create_symbol_handlers(elf=elf, elf_path=filepath, output_symmap_dir=output_symmap_dir, silent=silent, disasm=disasm)
        _process_elf(elf=elf, filename=filepath, include_functions=include_functions, include_variables=include_variables, symbol_handlers=symbol_handlers, callback=callback)
        for handler in symbol_handlers:
            handler.close()

def process(path, include_functions: bool = True, include_variables: bool = True, output_symmap_dir: str = '', silent: bool = False, disasm: bool = False):
    def _process_file(file_path):
        process_file(filepath=file_path,
                     include_functions=include_functions,
                     include_variables=include_variables,
                     output_symmap_dir=output_symmap_dir,
                     silent=silent,
                     disasm=disasm)

    if os.path.isfile(path):
        _process_file(path)
    elif os.path.isdir(path):
        for filename in os.listdir(path):
            filepath = os.path.normpath(os.path.abspath(os.path.join(path, filename)))
            if utility.is_elf_file(filepath):
                _process_file(filepath)
    else:
        raise RuntimeError(f'path not found: {path}')

def parse_args():
    parser = argparse.ArgumentParser(prog=PROGRAM_NAME, description='ELF Symbol Extractor')
    parser.add_argument('path')
    parser.add_argument('--no-fun', action='store_true', help='exclude functions')
    parser.add_argument('--no-var', action='store_true', help='exclude variables')
    parser.add_argument('--silent', action='store_true', help='no stdout output')
    parser.add_argument('--disasm', action='store_true', help='disassemble code')
    parser.add_argument('--symmap', type=str, help='output symmap csv directory')
    return parser.parse_args()

def main():
    args = parse_args()
    include_functions: bool = not args.no_fun
    include_variables: bool = not args.no_var
    output_symmap_dir: str = args.symmap
    process(path=args.path,
            include_functions=include_functions,
            include_variables=include_variables,
            output_symmap_dir=output_symmap_dir,
            silent=args.silent,
            disasm=args.disasm)

if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S")
    main()
