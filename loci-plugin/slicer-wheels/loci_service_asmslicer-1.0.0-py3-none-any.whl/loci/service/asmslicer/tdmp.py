import argparse
import csv
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import traceback
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass

import smart_open as so

from . import aws_utils as au
from . import tdp_scan, utility

LOG_FORMAT = '%(asctime)s.%(msecs)03d | %(name)-7s | %(process)d | %(levelname).1s | %(funcName)s:%(lineno)d  | %(message)s'
logger = None

@dataclass
class Tools:
    onguard: str
    pprocessor: str
    pprocessor_py: str

    def do_sanity_check(self):
        for tool, path in vars(self).items():
            if (not path or not os.path.isfile(path)) and tool != 'pprocessor' and tool != 'pprocessor_py':
                raise ValueError(f"Tool {tool} is not a file: {path}.")


def parse_args():
    parser = argparse.ArgumentParser(description="Data Provider", formatter_class=argparse.RawTextHelpFormatter)
    subparsers = parser.add_subparsers(required=True, title='subcommands', dest='command')

    # cache
    cache_parser = subparsers.add_parser("cache",
                                         help="Generate project-wide cache.\n\n"
                                         "* Full cache (Updates entire .cache directory, such as the: asm, slicer, cfg subdirectories)\n"
                                         "Trigger conditions:\n"
                                         "  - The angr dependency version has changed.\n"
                                         "  - The control flow graph generation parameters have changed, \n"
                                         "    or the valid regions in the slicer logic have been modified.\n\n"
                                         "* Lite cache (Updates only the slicer and asm subdirectories present in the .cache directory)\n"
                                         "Trigger conditions:\n"
                                         "  - The pickled control flow graphs have been updated.\n"
                                         "  - The slicer version has changed, affecting the generation of \n"
                                         "    *.symmap.csv and/or *.vars.csv.\n",
                                         formatter_class=argparse.RawTextHelpFormatter)

    cache_parser.add_argument("project",
                               help="Path to the project directory containing versions, architectures, and binaries.")

    cache_parser.add_argument("--full",
                              action="store_true",
                              default=False,
                              help="Re/Generate control flow graphs cache. Triggers generating new symbols cache as well. "
                                   "Default: False")

    cache_parser.add_argument("--include-elfs",
                              default='',
                              help="A comma-separated list of absolute ELF paths to be included. If not provided, all ELFs will be cached.")

    cache_parser.add_argument("--status",
                              action='store_true',
                              help="Generates project-wide cache status. If enabled - it does NOT cache project.")


    # process
    process_parser = subparsers.add_parser("process",
                                           help="Process trace data")

    process_parser.add_argument("-t",
                                "--traces",
                                required=True,
                                help="Path to the traces directory which must be located within the project directory."
                                     "If a relative path is given, it is treated as relative to it.")

    process_parser.add_argument("-o",
                                "--output",
                                required=True,
                                help="Base output directory. Directories will be in the form of base_output_$PROJECT_$TRACE")

    process_parser.add_argument("-p",
                                "--pprocessor",
                                help="Path to pprocessor for unique segments."
                                     "Generally used in development - fast retrieval of unique segments of the processed data.")

    process_parser.add_argument("-pp",
                                "--pprocessor-py",
                                help="Path to pprocessor python interpreter. Default: system python interpreter",
                                default="python3")

    process_parser.add_argument("--transfer-target",
                                help="Directory path where processed trace data from args.output is moved."
                                     "Useful for offloading files to a slower disk or secondary storage.")

    process_parser.add_argument("--include-traces",
                                default='',
                                help="Comma separated list of traces that are included from --traces directory. If not provided all traces inside --traces will be included")

    process_parser.add_argument("--status",
                                action='store_true',
                                help="Generates project-wide process status. If enabled - it does NOT process traces.")


    # common
    parser.add_argument("-j",
                        "--jobs",
                        type=int,
                        default=4,
                        help="Number of jobs/processes to be executed in parallel. Default: 4")

    parser.add_argument("-l",
                        "--log",
                        choices=['debug', 'info', 'warning', 'error', 'critical'],
                        default='warning',
                        help='Log level',
                        type=lambda s: s.lower())

    parser.add_argument("-g",
                        "--onguard",
                        help="Path to onguard")

    args = parser.parse_args()
    if args.command == 'parse' and not args.onguard:
        parser.error('tdmp.py: error: the following arguments are required: -g/--onguard')
        sys.exit(1)

    return parser.parse_args()


@dataclass
class ProjectDetails:
    root: str
    project: str
    version: str
    architecture: str


class CacheDataProcessor:
    def __init__(self, project: str, full: bool, jobs: int, include_elfs: list[str]):
        self._bins: au.LocalFile|au.S3File|None = au.to_file(project)
        self._full: bool = full
        self._jobs: int = jobs
        self._include_elfs = include_elfs


    def _get_configs_for_version_n_arch(self, pd: ProjectDetails) -> list[tdp_scan.FlatConfig]:
        if not pd:
            return
        project = tdp_scan.Project(pd.project, f'{os.path.join(pd.root, pd.project)}/', vers=[])
        configs = tdp_scan.scan_project(project=project, show_all=True, include_traces=[])
        result = []
        for config in configs:
            if config.project.name == pd.project and \
                config.version.name == pd.version and \
                config.architecture.name == pd.architecture:
                    result.append(config)
        return result


    def process(self):
        self._do_sanity_check()

        pd: ProjectDetails = self._to_project_details()

        logger.info(f"{'Root':8} : {pd.root}")
        logger.info(f"{'Project':8} : {pd.project}")
        logger.info(f"{'Version':8} : {pd.version}")
        logger.info(f"{'Arch':8} : {pd.architecture}")

        configs = self._get_configs_for_version_n_arch(pd) # len(configs) == len(bundles) * len(traces)
        if not configs:
            logger.error(f"Caching data failed. No relevant configs found for Project: {self._bins}, Version: {pd.version} and Arch: {pd.architecture}")
            return

        config_id = 0
        if self._jobs == 1:
            self._cache(version=pd.version, arch=pd.architecture, configs=configs, config_id=config_id, include_elfs=self._include_elfs)
        else:
            with ProcessPoolExecutor(max_workers=self._jobs) as executor:
                args = []

                included_elfs = self._include_elfs or configs[config_id].architecture.bins
                # parallelize between elfs
                size = 1
                for elfs in [included_elfs[i:i + size] for i in range(0, len(included_elfs), size)]:
                    args.extend([(pd.version, pd.architecture, configs, config_id, elfs)])

                try:
                    executor.map(self._cache, *zip(*args))
                except Exception as ex:
                    logger.error(f"Caching data failed. Error: {ex}. {traceback.format_exc()}")


    def _do_sanity_check(self):
        if not self._bins:
            raise ValueError("Provided project bins value is not a valid Local/S3 URI.")


    def _cache(self, version: str, arch: str, configs: list[tdp_scan.FlatConfig], config_id: int, include_elfs: list[str]):
        try:
            if isinstance(self._bins, au.LocalFile):
                project = os.path.basename(os.path.normpath(self._bins.path))
                logger = logging.getLogger(f"cache_{project}_{version}_{arch}")
                logger.setLevel(logging.INFO)

                logger.info(f"Caching. Project \"{project}\". Version = \"{version}\". Arch = \"{arch}\"")
            elif isinstance(self._bins, au.S3File):
                project = self._bins.key.rstrip("/").split("/")[-1]
                logger = logging.getLogger(f"cache_{project}_{version}_{arch}")
                logger.setLevel(logging.INFO)
                logger.info(f"Caching. Project \"{project}\". Version = \"{version}\". Arch = \"{arch}\"")

            tdp_scan.process_configurations(configs,
                                            [config_id],
                                            output=None,
                                            onguard=None,
                                            keep_temp=False,
                                            temp_dir=None,
                                            filter_functions=False,
                                            analyse=False,
                                            clean=False,
                                            recache=self._full,
                                            recache_lite=True,
                                            raise_exception=True,
                                            include_elfs=include_elfs)
        except BaseException as ex:
            logger.error(f"Caching data failed. Error: {ex}. {traceback.format_exc()}")


    def _to_project_details(self) -> ProjectDetails|None:
        """
            Given a Local/S3 URI

            - /home/user/TDPScans/static_random_asm_0_traces/TX2.01/A57/Bins/
            - s3://trace-data-auroralabs/Backend/TX2-01/A57/Bins/

            this function will parse and return:

            root:          /home/user/TDPScans                   s3://trace-data-auroralabs
            project:       static_random_asm_0_traces            Backend
            version:       TX2.01                                TX2-01
            architecture:  A57                                   A57

            The assumed structure is:
            <root>/<project>/<version>/<architecture>/Bins/
    """
        if not self._bins:
            return None

        path = os.path.normpath(self._bins.path) if isinstance(self._bins, au.LocalFile) else au.to_uri(self._bins)

        # Remove any trailing slash
        sep = au.Path.sep(self._bins)
        path = path.rstrip(sep)
        parts = path.split(sep)

        if parts[-1] != "Bins":
            raise ValueError("Expected last directory to be 'Bins'.")
        parts = parts[:-1]

        if len(parts) < 4:
            raise ValueError("Path structure does not match expected pattern.")

        arch = parts[-1]
        version = parts[-2]
        project = parts[-3]
        root = sep.join(parts[:-3])

        return ProjectDetails(root, project, version, arch)


    def check_status(self):
        def _dump_status(errs: list[tuple] = []):
            status = au.Path.join(self._bins, "status.csv")
            with so.open(status, "w", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(["elf", "cfg", "sym", "var"])
                for err in errs:
                    writer.writerow(err)
        self._do_sanity_check()
        pd: ProjectDetails = self._to_project_details()

        logger.info(f"{'Root':8} : {pd.root}")
        logger.info(f"{'Project':8} : {pd.project}")
        logger.info(f"{'Version':8} : {pd.version}")
        logger.info(f"{'Arch':8} : {pd.architecture}")

        configs = self._get_configs_for_version_n_arch(pd) # len(configs) == len(bundles) * len(traces)
        if not configs:
            logger.error(f"Status check failed. No relevant configs found for Project: {self._bins}, Version: {pd.version} and Arch: {pd.architecture}")
            return

        config = configs[0]
        elfs = config.architecture.bins

        if not elfs:
            logger.error("Status check failed. No Bins folder found.")
            return

        cache = au.Path.join(au.Path.dirname(elfs[0]), '.cache/')
        if not au.Path.exists(cache):
            logger.error(f"Status check failed. No cache found. Expected loc: {cache}")
            return

        cfgs = au.Path.join(cache, 'cfg/')
        if not au.Path.exists(cfgs):
            logger.error(f"Status check failed. No control-flow-graphs cache found. Expected loc: {cfgs}")
            return

        slcs = au.Path.join(cache, 'slicer/')
        if not au.Path.exists(slcs):
            logger.error(f"Status check failed. No slicer cache found. Expected loc: {slcs}")
            return

        errs = []
        # TODO: add support for generated elf files
        with tempfile.TemporaryDirectory() as temp:
            for o_elf in elfs:
                if o_elf.endswith(".debug"):
                    continue
                t_elf = os.path.join(temp, os.path.basename(o_elf))
                au.copy_file(src=o_elf, dst=t_elf, logger=logger)

                is_elf, _ = utility.get_elf_info(t_elf)
                if not is_elf:
                    continue

                found_cfg: bool = True
                found_sym: bool = True
                found_var: bool = True

                cfg_name = utility.gen_cfg_file(t_elf)

                # atm we do not manually specify arch
                # TODO: in a future case that we need to do so, we will read this data from some source
                slicer_name = utility.gen_slicer_file(t_elf, architecture='', filter_functions=False)

                if not au.Path.exists(au.Path.join(cfgs, cfg_name)):
                    found_cfg = False
                if not au.Path.exists(au.Path.join(slcs, f"{slicer_name}.sym")):
                    found_sym = False
                if not au.Path.exists(au.Path.join(slcs, f"{slicer_name}.var")):
                    found_var = False

                if not found_cfg or not found_sym or not found_var:
                    errs.append((o_elf, found_cfg, found_sym, found_var))

        if errs:
            logger.info("Status: x")
        else:
            logger.info("Status: ✓")
        _dump_status(errs)


@dataclass
class TraceBundleDetails:
    root: str
    project: str
    version: str
    architecture: str
    bundle: str
    traces: list[str]


class ParseDataProcessor:
    def __init__(self, tools: Tools, traces: str, include_traces: list[str], output: str, transfer_target: str, jobs: int):
        self._tools: Tools = tools
        self._jobs: str = jobs
        self._traces: au.LocalFile|au.S3File|None = au.to_file(traces)
        self._output: au.LocalFile|au.S3File|None = au.to_file(output)
        self._include_traces: list[str] = include_traces
        self._transfer_target: au.LocalFile|au.S3File|None = au.to_file(transfer_target)


    def _get_configs_for_bundle(self, tbd: TraceBundleDetails) -> list[tdp_scan.FlatConfig]:
        if not tbd:
            return
        project = tdp_scan.Project(tbd.project, f'{os.path.join(tbd.root, tbd.project)}/', vers=[])
        all_configs = tdp_scan.scan_project(project=project, show_all=False, include_traces=[f"{au.Path.join(self._traces, t)}/" for t in tbd.traces])
        result = []
        for config in all_configs:
            if config.project.name == tbd.project and \
                config.version.name == tbd.version and \
                config.architecture.name == tbd.architecture and \
                config.bundle.name == tbd.bundle:
                    result.append(config)
        return result


    def _get_config_id_for_trace(self, configs: list[tdp_scan.FlatConfig], tbd: TraceBundleDetails, trace: str) -> int|None:
        if not tbd or not configs:
            return
        config_id = None
        for idx, config in enumerate(configs):
            if config.project.name == tbd.project and \
                config.bundle.name == tbd.bundle and  \
                config.trace.name == trace and \
                config.version.name == tbd.version and \
                config.architecture.name == tbd.architecture:
                config_id = idx
        return config_id


    def _prepare_common_dirs(self, tbd: TraceBundleDetails, configs: list[tdp_scan.FlatConfig], temp_dir: str, output_dir: str) -> bool:
        if not tbd.traces:
            return False
        first_batch = tbd.traces[0]
        config_id = self._get_config_id_for_trace(configs, tbd, first_batch)
        if config_id is None:
            logger.error(f"No configuration detected for first trace batch with name \"{first_batch}\". Terminating.")
            return False

        tdp_scan.process_configurations(configs=configs,
                                        config_numbers=[config_id],
                                        onguard=self._tools.onguard,
                                        output=output_dir,
                                        filter_functions=False,
                                        analyse=False,
                                        keep_temp=True,
                                        temp_dir=temp_dir,
                                        clean=True,
                                        recache=False,
                                        process_traces=False,
                                        raise_exception=True)
        return True


    def process(self) -> bool:
        self._do_sanity_check()

        tbd: TraceBundleDetails = self._to_trace_details()

        logger.info(f"{'Root':8} : {tbd.root}")
        logger.info(f"{'Project':8} : {tbd.project}")
        logger.info(f"{'Version':8} : {tbd.version}")
        logger.info(f"{'Arch':8} : {tbd.architecture}")
        logger.info(f"{'Bundle':8} : {tbd.bundle}")
        logger.info(f"{'Traces':8} : {tbd.traces}")

        if not len(tbd.traces):
            logger.warning(f"No traces found in path: {self._traces}")
            return True

        configs = self._get_configs_for_bundle(tbd)
        if not configs:
            logger.error(f"Processing data failed. No relevant configs found for Project: {tbd.project}, Version: {tbd.version} and Arch: {tbd.architecture}")
            return

        output = self._output.path if isinstance(self._output, au.LocalFile) else au.to_uri(self._output)
        au.Path.makedirs(output)
        with tempfile.TemporaryDirectory() as temp:
            if not self._prepare_common_dirs(tbd, configs, temp, output):
                return False
            with ProcessPoolExecutor(max_workers=self._jobs) as executor:
                size = len(tbd.traces)
                try:
                    executor.map(self._process_traces, tbd.traces, [tbd] * size, [configs] * size, [temp] * size, [output] * size)
                except Exception as ex:
                    logger.error(f"Processing data failed. Error: {ex}")
        return True


    def _process_traces(self, batch: str, tbd: TraceBundleDetails, configs: list[tdp_scan.FlatConfig], temp_dir: str, output_dir: str):
        try:
            logger = logging.getLogger(f"process_traces_{batch}")
            logger.setLevel(logging.INFO)

            def add_err_file_handler():
                file_handler = logging.FileHandler(filename=os.path.join(temp_dir, f'log_{batch}'), encoding='utf-8')
                file_handler.setLevel(logging.ERROR)
                formatter = logging.Formatter(LOG_FORMAT)
                file_handler.setFormatter(formatter)
                logger.addHandler(file_handler)

            add_err_file_handler()

            config_id = self._get_config_id_for_trace(configs, tbd, batch)
            if config_id is None:
                logger.error(f"No configuration detected for trace batch with name \"{batch}\". Skipping.")
                return

            logger.info(f"Batch: {batch}. Config: {config_id}")

            tdp_scan.process_configurations(configs=configs,
                                            config_numbers=[config_id],
                                            onguard=self._tools.onguard,
                                            output=output_dir,
                                            filter_functions=False,
                                            analyse=False,
                                            keep_temp=True,
                                            temp_dir=temp_dir,
                                            clean=False,
                                            recache=False,
                                            raise_exception=True)

            output_dir = au.Path.join(output_dir, configs[config_id].unique_identifier())
            if not au.Path.is_dir(output_dir):
                logger.error(f"Missing output directory: {output_dir}.")
                return

            if not len(au.Path.list_files(output_dir)):
                logger.error(f"No files in output directory: {output_dir}.")
                return

            logger.info(f"Processed data: \"{output_dir}\"")

            if self._tools.pprocessor:
                output_file = os.path.join(output_dir, f"unique_segments_{batch}.csv")
                pprocess_command = [
                    self._tools.pprocessor_py, self._tools.pprocessor,
                    "--input_folder", output_dir, "--output_file", output_file
                ]
                logger.info(f"post-processing: {' '.join(pprocess_command)}")

                pprocess_result = subprocess.run(pprocess_command, capture_output=True, text=True)
                if pprocess_result.returncode != 0:
                    logger.error(f"Post processing of traces failed for {batch}. {pprocess_result.stderr}")
                    return

            if not self._transfer_target:
                return

            if isinstance(self._transfer_target, au.S3File):
                logger.warning('Unsupported S3 file transfer target')
                return

            transfer_target_path = self._transfer_target.path if isinstance(self._transfer_target, au.LocalFile) else ''
            logger.info(f"Moving processed data to {transfer_target_path}")

            if not os.path.isdir(transfer_target_path):
                logger.error(f"Location to move processed data: {transfer_target_path} is invalid")
                return

            shutil.move(output_dir, os.path.join(transfer_target_path, os.path.basename(output_dir)))
            logger.info(f"Data moved successfully to {transfer_target_path}")

        except BaseException as ex:
            logger.error(f"Processing traces failed. Error: {ex}")


    def _do_sanity_check(self):
        if not self._traces:
            raise ValueError("Provided traces is not a valid Local/S3 URI.")
        self._tools.do_sanity_check()
        if not self._output:
            raise ValueError("Provided output is not a valid Local/S3 URI.")


    def _to_trace_details(self) -> TraceBundleDetails|None:
        """
            Given a Local/S3 URI

            - /home/user/TDPScans/static_random_asm_0_traces/TX2.01/A57/Data/18022025/traces
            - s3://trace-data-auroralabs/Backend/TX2-01/A57/Data/202501/traces

            this function will parse and return:

            root:          /home/user/TDPScans                   s3://trace-data-auroralabs
            project:       static_random_asm_0_traces            Backend
            version:       TX2.01                                TX2-01
            architecture:  A57                                   A57
            bundle:        18022025                              202501

            The assumed structure is:
            <root>/<project>/<version>/<architecture>/Data/<bundle>/traces
    """
        if not self._traces:
            return None

        path = os.path.normpath(self._traces.path) if isinstance(self._traces, au.LocalFile) else au.to_uri(self._traces)

        # Remove any trailing slash
        sep = au.Path.sep(self._traces)
        path = path.rstrip(sep)
        parts = path.split(sep)

        if parts[-1] != "traces":
            raise ValueError("Expected last directory to be 'traces'.")
        parts = parts[:-1]

        if len(parts) < 6:
            raise ValueError("Path structure does not match expected pattern.")

        bundle = parts[-1]
        if parts[-2] != "Data":
            raise ValueError("Expected 'Data' directory not found in the path.")
        arch = parts[-3]
        version = parts[-4]
        project = parts[-5]
        root = sep.join(parts[:-5])

        return TraceBundleDetails(root, project, version, arch, bundle, self._list_project_traces(path))


    def _list_project_traces(self, traces: str):
        traces = f'{traces}/' # ensure trailing separator for s3 files.
        return sorted([filename for filename, filepath, _ in au.Path.list_files(traces, dirs=True, files=False) if not filename.startswith("DISABLED_") and filename != 'output' and (not self._include_traces or filename in self._include_traces)])


    def check_status(self):
        def _dump_status(output_dir: str, errs: list[str] = []):
            status = au.Path.join(output_dir, "status.csv")
            with so.open(status, "w", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(["trace","diff"])
                for err in errs:
                    writer.writerow(err)
                    logger.debug(f"Diff: {err[1]}. Trace: {err[0]}")

        self._do_sanity_check()

        tbd: TraceBundleDetails = self._to_trace_details()

        logger.info(f"{'Root':8} : {tbd.root}")
        logger.info(f"{'Project':8} : {tbd.project}")
        logger.info(f"{'Version':8} : {tbd.version}")
        logger.info(f"{'Arch':8} : {tbd.architecture}")
        logger.info(f"{'Bundle':8} : {tbd.bundle}")
        logger.info(f"{'Traces':8} : {tbd.traces}")

        if not len(tbd.traces):
            logger.warning(f"Status check failed. No traces found in path: {self._traces}")
            return

        configs = self._get_configs_for_bundle(tbd)
        if not configs:
            logger.error(f"Status check failed. No relevant configs found for Project: {tbd.project}, Version: {tbd.version} and Arch: {tbd.architecture}")
            return

        errs = []
        output_dir = au.Path.join(self._output, configs[0].unique_identifier())
        if not au.Path.exists(output_dir):
            logger.error(f"Status check failed. Output dir: {output_dir} does not exist.")
            return

        output_files = [f for f, _, _ in au.Path.list_files(output_dir, dirs=False, files=True) if f.endswith(".csv") and f.startswith("trace32_")]

        all_trace_files = 0
        for trace in tbd.traces:
            if trace.startswith('output'):
                continue
            trace_path = f"{au.Path.join(self._traces, trace)}/"
            if not au.Path.exists(trace_path):
                logger.warning(f"Provided trace: {trace_path} does not exist. Skipping.")
                continue
            cid = self._get_config_id_for_trace(configs, tbd, trace)
            if cid is None:
                logger.error(f"Status check failed. Config for trace: {trace_path} does not exist.")
                return

            config = configs[cid]
            trace_bins_path = os.path.join(trace_path, 'cstrace.bin.merged/') if config.architecture.coresight else trace_path
            if not au.Path.exists(trace_bins_path):
                logger.error(f"Status check failed. Traces directory: {trace_bins_path} does not exist.")
                return
            trace_files = [f for f, _, _ in au.Path.list_files(trace_bins_path, dirs=False, files=True) if (f.endswith(".flag") if config.architecture.coresight else f.endswith(".ad"))]
            processed_files = [f for f in output_files if f"_{trace}_" in f]

            if len(trace_files) != len(processed_files):
                errs.append((trace_path, len(trace_files) - len(processed_files)))
            all_trace_files = all_trace_files + len(trace_files)

         # Note: some data is parsed without trace name in the output, we want to keep the check simple there and check if sizes are equal
        legacy_parsed_data = all_trace_files == len(output_files)
        if errs and not legacy_parsed_data:
            logger.info("Status: x")
        else:
            logger.info("Status: ✓")
        _dump_status(output_dir, errs)


def silence_external_loggers():
    critical_ext_loggers = [
        'cle.loader',
        'cle.backends.externs',
        'cle.backends.elf.elf',
        'angr.analyses.cfg.cfg_fast',
        'angr.analyses.propagator.engine_vex.SimEnginePropagatorVEX',
        'angr.simos.userland',
        'angr.storage.memory_mixins.default_filler_mixin',
    ]
    error_ext_loggers = [
        'smart_open.s3'
    ]
    for ext_logger_name in critical_ext_loggers:
        logging.getLogger(name=ext_logger_name).setLevel(logging.CRITICAL)
    for ext_logger_name in error_ext_loggers:
        logging.getLogger(name=ext_logger_name).setLevel(logging.ERROR)


def main():
    global logger

    args = parse_args()
    logging.basicConfig(format=LOG_FORMAT, datefmt="%H:%M:%S", force=True, level=logging.INFO)
    logger = logging.getLogger('data-provider')
    logger.setLevel(args.log.upper())
    silence_external_loggers()

    if args.command == 'cache':
        elfs_list = args.include_elfs.split(',') if args.include_elfs else []
        cdp = CacheDataProcessor(args.project, args.full, args.jobs, elfs_list)
        if args.status:
            cdp.check_status()
        else:
            cdp.process()
    elif args.command == 'process':
        tools = Tools(os.path.abspath(args.onguard), args.pprocessor, args.pprocessor_py)
        traces_list = args.include_traces.split(',') if args.include_traces else []
        pdp = ParseDataProcessor(tools, args.traces, traces_list, args.output, args.transfer_target, args.jobs)
        if args.status:
            pdp.check_status()
        else:
            pdp.process()


if __name__ == "__main__":
    main()
