"""
ASM Slicer
"""

import argparse
import atexit
import copy
import csv
import dataclasses
import gc
import gzip
import hashlib
import json
import logging
import multiprocessing as mp
import os
import re
import shutil
import string
import subprocess
import sys
import time
import traceback
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from enum import IntEnum, StrEnum
from pathlib import Path
from typing import Iterable, Iterator, TypeAlias

import angr
import archinfo
import capstone
import capstone.arm64_const
import capstone.arm_const
import Levenshtein
import networkx as nx
import pyvex
import smart_open as so
from angr.codenode import BlockNode
from elftools.elf import sections as elftools_sections
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SH_FLAGS, Section, SymbolTableSection
from lxml import etree

from . import aws_utils as au
from . import dwarf_reader, elfplt, utility
from .cuanalyser import CudaAnalyser, CudaFatbinAnalyses
from .dwarf_resolver import DWARFResolver
from .insns import (
    BRANCH_WITH_LINK_INSTRUCTIONS,
    CONDITIONAL_BRANCHING_INSTRUCTIONS,
    CONDITIONS,
    INSTRUCTIONS,
    RETURN_INSTRUCTIONS,
    UNCONDITIONAL_BRANCHING_INSTRUCTIONS,
)

# pylint: disable=broad-exception-caught
# pylint: disable=wrong-import-position
# pylint: disable=trailing-whitespace
# pylint: disable=global-statement
# pylint: disable=too-many-locals
# pylint: disable=too-many-lines
# pylint: disable=too-many-branches
# pylint: disable=too-many-arguments
# pylint: disable=too-many-statements
# pylint: disable=too-many-nested-blocks
# pylint: disable=too-many-positional-arguments

# loop flags
LOOP_NONE   = 0x00
LOOP_INSIDE = 0x01
LOOP_OP_REG = 0x02
LOOP_OP_IMM = 0x04
LOOP_OP_MEM = 0x08
LOOP_OP_FP  = 0x10

# PLT
PLT_SUFFIX = '@plt'
ADD_EXTRA_JUMPS_TO_PLT_IN_BLOCKS: bool = True
BYPASS_PLT_TARGETS: bool = False

class Architecture(StrEnum):
    ARM = 'arm'
    AARCH64 = 'aarch64'
    ARM_CORTEXM = 'cortexm'
    TRICORE = 'tricore'
    X86 = 'x86'

# supported architecture map - EM_MACHINE to ASMS_MACHINE map
# currently only aarch64, tricore and cortex-m are supported.
SUPPORTED_ARCHITECTURE_MAP: dict[str, Architecture] = {'EM_AARCH64': Architecture.AARCH64,
                                                       'EM_TRICORE': Architecture.TRICORE,
                                                       'EM_ARM': Architecture.ARM_CORTEXM}

ASM_LINE_SEPARATOR = '\n'
SYMBOL_KEY_SEPARATOR = '_'
NON_USER_CODE_IDENTIFIER = 'non-user-code'

ARCHITECTURE_ANGR_SUPPORT: dict[Architecture, bool] = {
    Architecture.AARCH64: True,
    Architecture.TRICORE: False,
    Architecture.ARM_CORTEXM: False,
}

# regex for synthetic functions, like: e843419@000c_0000f149_24
SYNTHETIC_FUNC_PATTERN = re.compile(
    r"""
    ^
    [0-9a-f]{6,12}        # leading hex hash
    @                     # separator
    (?:[0-9a-f]{1,8}_)+   # one or more hex chunks followed by _
    [0-9a-f]{1,8}         # final chunk (hex or decimal)
    $
    """,
    re.VERBOSE
)

# error codes
class ASMSlicerError(IntEnum):
    UNDEFINED_ERROR = 1
    INTERNAL_ERROR = 2
    BAD_INPUT_ERROR = 3
    UNSUPPORTED_FEATURE_ERROR = 4
    IO_ERROR_ON_OUTPUT_FILE = 5
    ELF_STRIPPED = 6

# error exception
class ASMSlicerException(Exception):
    def __init__(self, error_code: ASMSlicerError, message: str):
        self.error_code = error_code
        self.message = message
        super().__init__(self.message)

# symbols to be ignored if filter_functions is active
# TODO: should be provided as argument and adapted accordingly
SYMBOL_PREFIXES_TO_SKIP = (
                           'std::',
                           '__gnu_cxx::',
                           '::testing',
                           'testing::',
                           'gtest',
                           '_GLOBAL__',
                           '_IO_stdin_used',
                           '__static_initialization_and_destruction_0',
                           'guard variable for',
                           'vtable for',
                           'non-virtual thunk to',
                           'typeinfo for',
                           'typeinfo name',
                           '_trap', # tricore
                           '_ldm', # tricore
                           '_c_init', # tricore
                           )

# From ARM documentation:
# Symbol   Description                                         Architecture
# -------  --------------------------------------------------  ------------
# $a       Start of a sequence of Arm/A32 instructions          All
# $t       Start of a sequence of Thumb/T32 instructions        All
# $t.x     Start of a sequence of ThumbEE instructions          Armv7-A
# $d       Start of a sequence of data items (e.g., literals)   All
# $x       Start of A64 code                                    Armv8-A
class ArmMarkers(StrEnum):
    ARM_32_CODE = '$a'
    ARM_THUMB_CODE = '$t'
    ARM_THUMB_EE_CODE = '$t.x'
    DATA = '$d'
    ARM_A64_CODE = '$x'

# Jump target classification.
# If an instruction has multiple immediate operands (e.g. in TriCore),
# we determine the most likely jump target by trying to resolve all immediate addresses.
# The classification is ordered by priority, defined by the enum values.
# When multiple targets are possible, we select the one with the highest priority (lowest enum value).
class JumpTarget(IntEnum):
    INTRA = 0                      # jump to the same function
    INTER = 1                      # jump to another function in elf
    INTER_NON_USER = 2             # jump to another function in lib / non user function (ex. templates from libs) / any skipped function
    INTER_UNMAPPED = 3             # jump to another function that is not beginning of a symbol (unmapped region)
    EXTERNAL = 4                   # jump to another function outside of elf
    UNRESOLVED = 5                 # jump to target in register
    UNDEFINED = 6                  # undefined jump/instruction is not jump

# string, by convention consisting of {symbolAddr} + "_" + {mangledName}  (ex. 1245__Z3barv).
# Used to create uniqueness across symbols (static symbols primarily)
UniqueMangled: TypeAlias = str
Mangled: TypeAlias = str
DemangledFull: TypeAlias = str
DemangledNoArgs: TypeAlias = str
InstructionAddrs: TypeAlias = list[int]

def get_sym_addr(address: int, architecture: Architecture) -> int:
    # clear thumb bit for arm/thumb architectures
    # this should be done only for function pointers (not instruction addresses)
    if address > 0 and (address & 1) == 1 and architecture in (Architecture.ARM, Architecture.ARM_CORTEXM):
        return address & ~1
    return address

def get_matching_symbol_names(symbol_name: str):
    name = symbol_name
    while True:
        yield name
        if '@' not in name:
            break
        name = name.rsplit('@', 1)[0]

def check_block_overlaps(intervals: list[tuple[int,int]]):
    if intervals and len(intervals) > 1:
        intervals.sort(key=lambda x: x[0])
        last_beg, last_end = intervals[0]
        for beg, end in intervals[1:]:
            if beg < last_end:
                logger.warning(f'overlap detected. block {last_beg:#x}-{last_end:#x} overlaps {beg:#x}-{end:#x}')
                last_end = max(last_end, end)
            else:
                last_beg, last_end = beg, end

def normalize_rust_symbol(symbol_name: str) -> str:
    sub_rx = [
        r'\.b[0-9a-f]+-cgu\.\d+',
        r'\.[0-9a-f]+-cgu\.\d+',
        r'\$[0-9]+h[0-9a-f]+E$',
        r'[0-9]+h[0-9a-f]+E$',
    ]
    for rx in sub_rx:
        symbol_name = re.sub(rx, '', symbol_name)
    return symbol_name.strip()

@dataclasses.dataclass
class ASMSlicerUtils:

    @staticmethod
    def validate_file_path(file_path: str = '') -> bool:
        return file_path and os.path.exists(file_path) and os.path.isfile(file_path)

    @staticmethod
    def compress_csv_file(input_file_path: str = '', remove_original: bool = False):
        if not os.path.exists(input_file_path):
            logger.error(f'Non existing csv file {input_file_path} could not be compressed.')
        if not os.path.isfile(input_file_path):
            logger.error(f'Not a file {input_file_path} could not be compressed.')
        try:
            with open(input_file_path, 'rb') as fi:
                with gzip.open(f'{input_file_path}.gz', 'wb') as fo:
                    shutil.copyfileobj(fi, fo)
                    if remove_original:
                        os.remove(input_file_path)
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'compressing csv file failed: {e}') from e

    @staticmethod
    def setup_other_loggers(internal_loggers_level: int):
        external_loggers = [
            'cle.loader',
            'cle.backends.externs',
            'cle.backends.elf.elf',
            'angr.analyses.cfg.cfg_fast',
            'angr.analyses.propagator.engine_vex.SimEnginePropagatorVEX',
            'angr.simos.userland',
            'angr.storage.memory_mixins.default_filler_mixin',
        ]
        internal_loggers = [
            'dwarf_reader'
        ]
        for ext_logger_name in external_loggers:
            logging.getLogger(name=ext_logger_name).setLevel(logging.ERROR)
        for int_logger_name in internal_loggers:
            logging.getLogger(name=int_logger_name).setLevel(internal_loggers_level)

    @staticmethod
    def get_elf_prefix(elf_file: str) -> str:
        base = os.path.basename(elf_file)
        prefix = base.replace('.', '_').replace('-', '_')
        return f'gen__{prefix}__'

    @staticmethod
    def is_angr_func_alignment(func: angr.knowledge_plugins.Function) -> bool:
        if func.is_alignment:
            return True
        i = None
        for block in func.blocks:
            for insn in block.capstone.insns:
                if i is None:
                    i = insn
                    continue
                if i.mnemonic == 'nop' and insn.mnemonic == 'nop':
                    continue
                return False
        return i is not None and i.mnemonic in {'hlt', 'nop', 'ret'}

    @staticmethod
    def convert_twos_complement(number: int) -> int:
        if isinstance(number, int):
            # get target address bit length while ignoring the sign
            bit_length = number.bit_length() if number >= 0 else (number.bit_length() + 1)
            # calculate maximum possible value represented with bit_length
            max_value = 2 ** bit_length
            # convert number to the equivalent using two's complement
            converted = (max_value + number) % max_value
            return converted
        return 0

    @staticmethod
    def get_imm(op, as_is = False):
        if op and hasattr(op, 'type') and (op.type == capstone.CS_OP_IMM) and hasattr(op, 'imm'):
            if as_is:
                return op.imm
            return op.imm if op.imm >= 0 else ASMSlicerUtils.convert_twos_complement(op.imm)
        return 0

    @staticmethod
    def load_deps_info(filename: str) -> dict[str, dict[str, str]]:
        if filename:
            with so.open(filename, 'r', encoding='utf-8') as fh:
                data = fh.read()
                return json.loads(data)
        return {}

@dataclasses.dataclass
class ElfFileInfo:
    elf: ELFFile | None = None
    path: str = ''
    machine: str = ''
    architecture: Architecture = ''
    is_stripped: bool = False
    base_address: int = 0
    entry_address: int = 0
    is_pic: bool = False
    is_fatbin: bool = False
    is_relocatable: bool = False
    is_64bit: bool = False
    program_header_count: int = 0
    section_count: int = 0
    function_count: int = 0 # functions STT_FUNC
    variable_count: int = 0 # data objects STT_OBJECT
    cs_arch = None
    cs_mode = None
    dependencies: str = ''

    def __init__(self, elf: ELFFile, elf_path: str, provided_architecture):
        # validate elf
        if not self.is_valid_elf(elf):
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message='invalid elf file')
        # elf
        self.elf = elf
        # elf path
        self.path = elf_path
        # machine
        self.machine = self.elf.header['e_machine']
        # architecture
        self.set_elf_architecture(provided_architecture=provided_architecture)
        # stripped
        _, self.is_stripped = utility.get_elf_info(self.path)
        # base address
        self.base_address = self.get_elf_base_address()
        # load segments
        self.load_segments = self.get_load_segments()
        # executable sections
        self.exec_sections = self.get_exec_sections()
        # entry address
        self.entry_address = self.elf['e_entry']
        # machine
        self.is_64bit = self.elf['e_ident']['EI_CLASS'] == 'ELFCLASS64'
        # pic
        self.is_pic = utility.is_pic(self.elf)
        # fatbin
        self.is_fatbin, _ = CudaAnalyser.is_cuda_fatbin(self.path)
        # relocatable object file
        self.is_relocatable = self.elf.header['e_type'] == 'ET_REL'
        # program headers
        self.program_header_count = len(list(self.elf.iter_segments()))
        # sections
        self.section_count = len(list(self.elf.iter_sections()))
        # symbols and dependencies
        for section in self.elf.iter_sections():
            if section:
                # symbols
                if isinstance(section, SymbolTableSection):
                    for symbol in section.iter_symbols():
                        if symbol.entry.st_info.type == 'STT_FUNC':
                            self.function_count += 1
                        elif symbol.entry.st_info.type == 'STT_OBJECT':
                            self.variable_count += 1
                # dependencies
                if section.header['sh_type'] == 'SHT_DYNAMIC':
                    for tag in section.iter_tags():
                        if tag.entry['d_tag'] == 'DT_NEEDED':
                            try:
                                self.dependencies += f'{tag.needed};'
                            except Exception as ex:
                                logger.warning(f'name of the needed library could not be resolved: {ex}')

    def is_valid_elf(self, elf: ELFFile) -> bool:
        if not elf:
            return False
        if not elf.header['e_machine']:
            return False
        # TODO: to be determined what should be validated from the elf
        return True

    def set_elf_architecture(self, provided_architecture = ''):
        elf_architecture = ''
        if not self.machine:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message='unknown elf architecture')
        if self.machine not in SUPPORTED_ARCHITECTURE_MAP:
            raise ASMSlicerException(error_code=ASMSlicerError.UNSUPPORTED_FEATURE_ERROR, message=f'unsupported elf architecture {self.machine}')
        elf_architecture = SUPPORTED_ARCHITECTURE_MAP[self.machine]
        if provided_architecture:
            provided_architecture = provided_architecture.lower()
            if provided_architecture not in SUPPORTED_ARCHITECTURE_MAP.values():
                raise ASMSlicerException(error_code=ASMSlicerError.UNSUPPORTED_FEATURE_ERROR, message=f'unsupported provided elf architecture {provided_architecture}')
            if provided_architecture != elf_architecture.value:
                # NOTE: for now we treat it as error since aarch64 and tricore should be fully supported
                # logger.warning(f'architecture mismatch. elf arch: {elf_arch}. provided arch: {architecture}.')
                raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message=f'architecture mismatch. elf architecture: {elf_architecture}. provided architecture: {provided_architecture}.')
        if Architecture.AARCH64 == elf_architecture:
            self.architecture = Architecture.AARCH64
            self.cs_arch = capstone.CS_ARCH_ARM64
            self.cs_mode = capstone.CS_MODE_ARM
        elif Architecture.TRICORE == elf_architecture:
            self.architecture = Architecture.TRICORE
            self.cs_arch = capstone.CS_ARCH_TRICORE
            self.cs_mode = ElfFileInfo._get_tricore_mode(self.elf, self.machine)
        elif Architecture.ARM == elf_architecture:
            self.architecture = Architecture.ARM
            self.cs_arch = capstone.CS_ARCH_ARM
            self.cs_mode = capstone.CS_MODE_ARM
        elif Architecture.ARM_CORTEXM == elf_architecture:
            self.architecture = Architecture.ARM_CORTEXM
            self.cs_arch = capstone.CS_ARCH_ARM
            self.cs_mode = capstone.CS_MODE_LITTLE_ENDIAN | capstone.CS_MODE_THUMB | capstone.CS_MODE_MCLASS
        elif Architecture.X86 == elf_architecture:
            self.architecture = Architecture.X86
            self.cs_arch = capstone.CS_ARCH_X86
            self.cs_mode = capstone.CS_MODE_64 if self.is_64bit else capstone.CS_MODE_32
        else:
            raise ASMSlicerException(error_code=ASMSlicerError.UNSUPPORTED_FEATURE_ERROR, message=f'unsupported elf architecture {elf_architecture}')

    def get_elf_base_address(self) -> int:
        base_address = None
        for segment in self.elf.iter_segments(type='PT_LOAD'):
            virtual_address = segment['p_vaddr']
            if base_address is None or virtual_address < base_address:
                base_address = virtual_address
        return base_address if base_address else 0

    def get_load_segments(self) -> list[tuple[int, int]]:
        ranges = []
        for segment in self.elf.iter_segments():
            if segment['p_type'] == 'PT_LOAD':
                start = segment['p_vaddr']
                end = start + segment['p_memsz']
                ranges.append((start, end))
        return ranges

    def get_exec_sections(self) -> list[tuple[int,int,bytes]]:
        shf_execinstr = SH_FLAGS.SHF_EXECINSTR
        sections: list[tuple[int,int,bytes]] = []
        for sec in self.elf.iter_sections():
            sec_beg = int(sec.header['sh_addr'])
            sec_len = int(sec.header['sh_size'])
            sec_end = sec_beg + sec_len - 1
            sec_type = sec.header['sh_type']
            sec_exec = (sec.header['sh_flags'] & shf_execinstr) == shf_execinstr
            if sec_exec and sec_type == 'SHT_PROGBITS':
                sections.append((sec_beg, sec_end, sec.data()))
        return sections

    @staticmethod
    def is_data_section(sec: Section, is_readonly: bool = False) -> bool:
        if not sec:
            return False
        shf_alloc = SH_FLAGS.SHF_ALLOC
        shf_write = SH_FLAGS.SHF_WRITE
        shf_execinstr = SH_FLAGS.SHF_EXECINSTR
        sec_type = sec.header['sh_type']
        sec_flag = sec.header['sh_flags']
        is_writable = (sec_flag & shf_write) == shf_write
        is_allocated  = (sec_flag & shf_alloc) == shf_alloc
        is_executable = (sec_flag & shf_execinstr) == shf_execinstr
        return not is_executable and sec_type == 'SHT_PROGBITS' and is_allocated and (not is_readonly or not is_writable)

    def extract_strings(self, min_length=4):
        results: dict[int, str] = {}
        printable = set(bytes(string.printable, 'ascii')) - {b'\n'[0]}

        for sec in self.elf.iter_sections():
            if not ElfFileInfo.is_data_section(sec):
                continue
            current = bytearray()
            string_start_idx = None
            sec_data = sec.data()
            sec_addr = sec['sh_addr']
            for idx, byte in enumerate(sec_data):
                if byte in printable:
                    if not current:
                        string_start_idx = idx
                    current.append(byte)
                else:
                    if len(current) >= min_length:
                        addr = sec_addr + string_start_idx
                        results[addr] = current.decode('ascii', errors='ignore')
                    current = bytearray()

            if len(current) >= min_length:
                addr = sec_addr + string_start_idx
                results[addr] = current.decode('ascii', errors='ignore')

        return results

    @staticmethod
    def _get_tricore_mode(elf: ELFFile, _machine: str = ''):
        flags = elf.header["e_flags"]
        flag_mode_map: dict[int, int] = {
            0x80000000: capstone.CS_MODE_TRICORE_110, # EF_TRICORE_V1_1
            0x40000000: capstone.CS_MODE_TRICORE_120, # EF_TRICORE_V1_2
            0x20000000: capstone.CS_MODE_TRICORE_130, # EF_TRICORE_V1_3
            0x00800000: capstone.CS_MODE_TRICORE_131, # EF_TRICORE_V1_3_1
            0x00400000: capstone.CS_MODE_TRICORE_160, # EF_TRICORE_V1_6
            0x00200000: capstone.CS_MODE_TRICORE_161, # EF_TRICORE_V1_6_1
            0x00100000: capstone.CS_MODE_TRICORE_162, # EF_TRICORE_V1_6_2
        }
        if flags in flag_mode_map:
            return flag_mode_map[flags]
        if flags == 0x01000000:  # EF_TRICORE_PCP
            raise ASMSlicerException(error_code=ASMSlicerError.UNSUPPORTED_FEATURE_ERROR,
                                     message='unsupported tricore mode: PCP')
        elif flags == 0x02000000:  # EF_TRICORE_PCP2
            raise ASMSlicerException(error_code=ASMSlicerError.UNSUPPORTED_FEATURE_ERROR,
                                     message='unsupported tricore mode: PCP2')
        else:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR,
                                     message=f'unknown tricore flags: {flags}')

class ELFSymbol:
    def __init__(self, name: str, short_name: str, demangled_name_no_args: str, addr: int, size: int, bind: str, sym_type: str, visibility, associated_object: str, namespace: str, generated: bool, is_import: bool, is_rust: bool):
        self.name: str = name
        self.addr: int = addr
        self.key = self._create_symbol_key()
        self.size: int = size
        self.bind: str = bind
        self.type: str = sym_type
        self.visibility = visibility
        self.short_name: str = short_name
        self.associated_object: str = associated_object
        self.namespace: str = namespace
        self.generated: bool = generated
        self.is_import: bool = is_import
        self.name_id = self._uniquify_name(name, is_rust)
        self.demangled_name = demangled_name_no_args
        self.aliases: list[ELFSymbol] = []

    def __eq__(self, other) -> bool:
        if not isinstance(other, ELFSymbol):
            return False
        return (self.name == other.name and
                self.addr == other.addr and
                self.key == other.key and
                self.size == other.size and
                self.bind == other.bind and
                self.type == other.type and
                self.visibility == other.visibility and
                self.short_name == other.short_name and
                self.associated_object == other.associated_object and
                self.namespace == other.namespace and
                self.generated == other.generated and
                self.name_id == other.name_id and
                self.demangled_name == other.demangled_name and
                self.aliases == other.aliases)

    def __hash__(self) -> int:
        return hash(f'{self.name_id} {self.addr} {self.size}')

    def _uniquify_name(self, name: str, is_rust: bool):
        unique_name = f'{self.associated_object}_{name}' if (self.associated_object and self.bind == 'STB_LOCAL') else name
        if is_rust:
            unique_name = normalize_rust_symbol(unique_name)
        return unique_name

    def _create_symbol_key(self) -> str:
        if not self.name:
            return ''
        if not self.addr:
            return self.name
        return f'{self.addr}{SYMBOL_KEY_SEPARATOR}{self.name}'

    def _replace_substr_in_names(self, old_substr: str, new_substr: str):
        if old_substr not in self.name or \
           old_substr not in self.name_id or \
           old_substr not in self.short_name or \
           old_substr not in self.demangled_name:
            logger.warning('Won\'t substitute non-common substr in symbol name variants')
            return
        self.name = self.name.replace(old_substr, new_substr)
        self.name_id = self.name_id.replace(old_substr, new_substr)
        self.short_name = self.short_name.replace(old_substr, new_substr)
        self.demangled_name = self.demangled_name.replace(old_substr, new_substr)

@dataclasses.dataclass
class CustomElfBlock:
    start_addr: int
    end_addr: int
    size: int
    is_natural: bool
    instructions: list[capstone.CsInsn]
    within_symbol: str

    def __init__(self, start_addr, end_addr, size, is_natural, instructions, within_symbol):
        self.start_addr = start_addr
        self.end_addr = end_addr
        self.size = size
        self.is_natural = is_natural
        self.instructions = instructions
        self.within_symbol = within_symbol

    def __hash__(self) -> int:
        return hash(f'{self.start_addr} {self.end_addr} {self.size}')

@dataclasses.dataclass
class Segment:
    __slots__ = ["start_address", "end_address", "blocks", "instructions", "addresses", "instructions_addrs", "loop_flags"]
    def __init__(self, blocks: list[CustomElfBlock], architecture: Architecture):
        self.start_address: str = ''
        self.end_address: str = ''
        self.blocks: list[str] = []
        self.instructions: list[str] = []
        self.addresses: list[int] = []
        self.instructions_addrs: list[str] = []
        self.loop_flags = LOOP_NONE

        for i, block in enumerate(blocks):
            if not block:
                continue
            if not self.start_address:
                self.start_address = hex(block.start_addr)
            self.end_address = hex(block.end_addr - block.instructions[-1].size) if block.instructions else hex(block.start_addr)
            self.blocks.append(hex(block.start_addr))

            if i > 0 and blocks[i-1].start_addr > block.start_addr and blocks[i-1].within_symbol == block.within_symbol:
                # go through the instructions in reverse order to check for the condition and its operands
                self.loop_flags = LOOP_INSIDE

                for bi in range(i-1, -1, -1):
                    if self.loop_flags != LOOP_INSIDE:
                        # some other flags have been set, meaning the comparison instruction has been found
                        break
                    if blocks[bi].within_symbol != block.within_symbol:
                        # we got to another function
                        break
                    for ii in range(len(blocks[bi].instructions)-1, -1, -1):
                        instruction = blocks[bi].instructions[ii]
                        if instruction.mnemonic not in ('cmp', 'test'):
                            continue
                        for operand in instruction.operands:
                            type_attr = getattr(operand, 'type', None)
                            if type_attr==capstone.CS_OP_REG:
                                self.loop_flags |= LOOP_OP_REG
                            elif type_attr==capstone.CS_OP_IMM:
                                self.loop_flags |= LOOP_OP_IMM
                            elif type_attr ==capstone.CS_OP_MEM:
                                self.loop_flags |= LOOP_OP_MEM
                            elif type_attr ==capstone.CS_OP_FP:
                                self.loop_flags |= LOOP_OP_FP
                        break

            insns_of_variable_len = architecture == Architecture.ARM_CORTEXM
            valid_instructions = [insn for insn in block.instructions if not ElfInstruction.is_invalid(insn=insn)]

            self.addresses.extend(insn.address for insn in valid_instructions)
            self.instructions.extend(f'{insn.mnemonic} {insn.op_str}' for insn in valid_instructions)

            if insns_of_variable_len:
                self.instructions_addrs.extend(hex(insn.address) for insn in valid_instructions)
            else:
                number_of_next_instructions = len(valid_instructions) - 1
                end_addr = ';' + str(number_of_next_instructions) if number_of_next_instructions else ''
                self.instructions_addrs.append(f'{hex(block.start_addr)}{end_addr}')

    def __eq__(self, other) -> bool:
        if not isinstance(other, Segment):
            return False
        return (self.start_address == other.start_address and
                self.end_address == other.end_address and
                self.blocks == other.blocks and
                self.instructions == other.instructions)

    def __hash__(self) -> int:
        insns = "".join(self.instructions)
        return hash(f'{self.start_address} {self.end_address} {insns}')

    def is_valid(self) -> bool:
        if not self.blocks or not self.instructions:
            return False
        return True

    def serialize(self) -> dict:
        return {
            "start_address" : self.start_address,
            "end_address" : self.end_address,
            "instructions" : self.instructions,
            "blocks" : self.blocks
        }

@dataclasses.dataclass
class CustomElfSymbolData:
    symbol: ELFSymbol
    blocks: dict[int, CustomElfBlock]
    call_graph: dict[int, set[int]]
    local_transition_graph: nx.DiGraph # nodes are CustomElfBlock -> blocks
    control_flow_graph: nx.DiGraph # nodes are int -> block addresses

    def __init__(self,
                 symbol: ELFSymbol,
                 blocks: dict[int, CustomElfBlock],
                 call_graph: dict[int, set[int]],
                 local_transition_graph: nx.DiGraph,
                 control_flow_graph: nx.DiGraph):
        self.symbol = symbol
        self.blocks = blocks
        self.call_graph = call_graph
        self.local_transition_graph = local_transition_graph
        self.control_flow_graph = control_flow_graph

    def __hash__(self) -> int:
        return hash(self.symbol.name_id)

@dataclasses.dataclass
class FunctionInfo:
    def __init__(self,
                 elf_function: CustomElfSymbolData,
                 call_graph_map: dict[int, CustomElfSymbolData],
                 control_flow_graph_map: dict[int, set[CustomElfBlock]],
                 should_filter_functions: bool,
                 dwarf_line_entries,
                 dwarf_functions,
                 dwarf_function_entry_map,
                 dwarf_resolver):
        self.elf_function = elf_function
        self.call_graph_map = call_graph_map
        self.control_flow_graph_map = control_flow_graph_map
        self.filter_functions = should_filter_functions
        self.dwarf_line_entries = dwarf_line_entries
        self.dwarf_functions = dwarf_functions
        self.dwarf_function_entry_map = dwarf_function_entry_map
        self.dwarf_resolver = dwarf_resolver

@dataclasses.dataclass
class CustomElfDataStatistics:
    total_functions: int = 0
    total_variables: int = 0
    total_symbols: int = 0
    total_relevant_functions: int = 0
    total_relevant_variables: int = 0
    total_relevant_symbols: int = 0
    total_processed_functions: int = 0
    total_processed_variables: int = 0
    total_processed_symbols : int = 0
    relevant_symbols_coverage: float = 100.0
    relevant_symbols_incompleteness: float = 0.0
    relevant_functions_coverage: float = 100.0
    relevant_functions_incompleteness: float = 0.0
    relevant_variables_coverage: float = 100.0
    relevant_variables_incompleteness: float = 0.0

    def __init__(self,
                 total_functions,
                 total_variables,
                 total_relevant_functions,
                 total_relevant_variables,
                 total_processed_functions,
                 total_processed_variables):
        self.total_functions = total_functions
        self.total_variables = total_variables
        self.total_symbols = total_functions + total_variables
        self.total_relevant_functions = total_relevant_functions
        self.total_relevant_variables = total_relevant_variables
        self.total_relevant_symbols = total_relevant_functions + total_relevant_variables
        self.total_processed_functions = total_processed_functions
        self.total_processed_variables = total_processed_variables
        self.total_processed_symbols = total_processed_functions + total_processed_variables
        self.calculate()
        # logger.info(self.report())

    def calculate(self) -> None:
        try:
            if self.total_relevant_symbols:
                self.relevant_symbols_coverage = round(((self.total_processed_symbols / self.total_relevant_symbols) * 100.0), 2)
                self.relevant_symbols_incompleteness = round(abs(((self.total_processed_symbols - self.total_relevant_symbols) / self.total_relevant_symbols) * 100.0), 2)
            if self.total_relevant_functions:
                self.relevant_functions_coverage = round(((self.total_processed_functions / self.total_relevant_functions) * 100.0), 2)
                self.relevant_functions_incompleteness = round(abs(((self.total_processed_functions - self.total_relevant_functions) / self.total_relevant_functions) * 100.0), 2)
            if self.total_relevant_variables:
                self.relevant_variables_coverage = round(((self.total_processed_variables / self.total_relevant_variables) * 100.0), 2)
                self.relevant_variables_incompleteness = round(abs(((self.total_processed_variables - self.total_relevant_variables) / self.total_relevant_variables) * 100.0), 2)
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'generating elf statistics failed: {e}') from e

    def report(self) -> str:
        report = '\n'
        report += '--- ELF FILE ANALYSES REPORT ---\n'
        report += f'# of elf symbols: {self.total_symbols}\n'
        report += f'  of which functions: {self.total_functions}\n'
        report += f'  of which variables: {self.total_variables}\n'
        report += f'# of relevant symbols: {self.total_relevant_symbols}\n'
        report += f'  of which functions: {self.total_relevant_functions}\n'
        report += f'  of which variables: {self.total_relevant_variables}\n'
        report += f'# of processed symbols: {self.total_processed_symbols}\n'
        report += f'  of which functions: {self.total_processed_functions}\n'
        report += f'  of which variables: {self.total_processed_variables}\n'
        report += f'% of relevant coverage: {self.relevant_symbols_coverage}%\n'
        report += f'  of which functions coverage: {self.relevant_functions_coverage}%\n'
        report += f'  of which variables coverage: {self.relevant_variables_coverage}%\n'
        report += f'% of relevant incompleteness: {self.relevant_symbols_incompleteness}%\n'
        report += f'  of which functions incompleteness: {self.relevant_functions_incompleteness}%\n'
        report += f'  of which variables incompleteness: {self.relevant_variables_incompleteness}%\n'
        report += '--------------------------------'
        return report

@dataclasses.dataclass
class CustomElfData:
    functions: list[CustomElfSymbolData]
    variables: list[CustomElfSymbolData]
    call_graph: dict[UniqueMangled, set[UniqueMangled]]
    statistics: CustomElfDataStatistics
    blocks: dict[int, CustomElfBlock]

    def __init__(self,
                 functions: list[CustomElfSymbolData],
                 variables: list[CustomElfSymbolData],
                 call_graph: dict[UniqueMangled, set[UniqueMangled]]):
        self.functions = functions
        self.variables = variables
        self.call_graph = call_graph
        self.blocks = {}

    def get_functions(self) -> Iterator[CustomElfSymbolData]:
        yield from self.functions

    def get_variables(self) -> Iterator[CustomElfSymbolData]:
        yield from self.variables

    def get_symbols(self) -> Iterator[CustomElfSymbolData]:
        yield from self.functions
        yield from self.variables

    def get_blocks(self) -> dict[int, CustomElfBlock]:
        if self.blocks:
            return self.blocks
        for symbol in self.get_symbols():
            for block in symbol.blocks.values():
                self.blocks[block.start_addr] = block
        return self.blocks

    def get_block(self, target_block_address: int) -> CustomElfBlock | None:
        blocks = self.get_blocks()
        if target_block_address in blocks:
            return blocks[target_block_address]
        return None

    def get_callgraph(self) -> dict[UniqueMangled, set[UniqueMangled]]:
        return self.call_graph

    def get_function_from_address(self, address: int) -> CustomElfSymbolData:
        for function in self.get_functions():
            if function.symbol.addr == address:
                return function
        return None

@dataclasses.dataclass
class SymbolManager:
    elf: ELFFile
    elf_debug: ELFFile
    symbol_prefix: str
    elffile_info: ElfFileInfo
    elf_symbols: dict[int, ELFSymbol]
    mangled_to_demangled: dict[Mangled, tuple[DemangledFull, DemangledNoArgs]]

    def __init__(self, elf: ELFFile, elf_debug: ELFFile, symbol_prefix: str, elffile_info: ElfFileInfo):
        logger.info('loading elf symbols')

        if not elf:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message='invalid elf file in symbol manager')

        self.elf = elf
        self.elf_debug = elf_debug
        self.symbol_prefix = symbol_prefix
        self.elffile_info = elffile_info
        self.elf_symbols: dict[int, ELFSymbol] = {}
        self.mangled_to_demangled: dict[Mangled, tuple[DemangledFull, DemangledNoArgs]] = {}

        # create symbols map for mangled/demangled relations
        elf_symbols = list(SymbolManager.get_elf_symbols(elf=self.elf))
        symbols_mangled = [symbol.name for symbol in elf_symbols]
        if symbols_mangled:
            def run_filt_proc(filt_cmd: list[str]) -> subprocess.CompletedProcess[str]:
                symbols_mangled_string = '\n'.join(symbols_mangled) + '\n'
                return subprocess.run(filt_cmd, capture_output=True, text=True, input=symbols_mangled_string, check=False)
            if utility.is_rust_elf(elf):
                logger.info('rust elf')
                rustfilt_result = run_filt_proc(["rustfilt"])
                if rustfilt_result.returncode != 0:
                    logger.error(f'rustfilt failed. Code: {rustfilt_result.returncode}')
                else:
                    symbols_rust_demangled = rustfilt_result.stdout.splitlines()
                    if len(symbols_mangled) == len(symbols_rust_demangled):
                        self.mangled_to_demangled = {m: (d, d) for m, d in zip(symbols_mangled, symbols_rust_demangled)}
                    else:
                        logger.error('Number of demangled symbols mismatch (rust)')
            else:
                cxxfilt_full_result = run_filt_proc(['c++filt', '-r'])
                cxxfilt_noargs_result = run_filt_proc(['c++filt', '-r', '-p'])
                if cxxfilt_full_result.returncode != 0:
                    logger.error(f'c++filt failed. Code: {cxxfilt_full_result.returncode}')
                elif cxxfilt_noargs_result.returncode != 0:
                    logger.error(f'c++filt failed (noargs). Code: {cxxfilt_noargs_result.returncode}')
                else:
                    symbols_full_demangled = cxxfilt_full_result.stdout.splitlines()
                    symbols_noargs_demangled = cxxfilt_noargs_result.stdout.splitlines()
                    if len(symbols_mangled) == len(symbols_full_demangled) == len(symbols_noargs_demangled):
                        self.mangled_to_demangled = dict(zip(symbols_mangled, zip(symbols_full_demangled, symbols_noargs_demangled)))
                    else:
                        logger.error('Number of demangled symbols mismatch')

        # load base elf symbols
        self._process_elf_symbols(symbols=elf_symbols, elf=self.elf)

        # load debug elf symbols, if exists
        if self.elf_debug:
            self._process_elf_symbols(symbols=SymbolManager.get_elf_symbols(elf=self.elf_debug), elf=self.elf)

        self._post_process_elf_symbols()

    # get section alignment
    def get_section_alignment(self, section_index: int) -> int:
        if isinstance(section_index, int) and section_index < self.elf.num_sections():
            section = self.elf.get_section(section_index)
            if section:
                return int(section.header['sh_addralign'])
        return 0

    @staticmethod
    def get_elf_symbols(elf: ELFFile) -> Iterator[elftools_sections.Symbol]:
        dyn_syms = utility.get_dynsym_with_versions(elf=elf)
        def _get_dyn_syms(symbols: list[elftools_sections.Symbol]):
            for symbol in symbols:
                yield symbol
                addr: int = symbol.entry.st_value
                if addr in dyn_syms:
                    for dyn_sym_name in dyn_syms[addr]:
                        if dyn_sym_name != symbol.name:
                            sym_copy = copy.deepcopy(symbol)
                            sym_copy.name = dyn_sym_name
                            yield sym_copy
        sections = [x for x in elf.iter_sections() if x and isinstance(x, SymbolTableSection) and x.name != '.dynsym']
        symbols_by_address = {}
        for section in sections:
            for sym in section.iter_symbols():
                if not sym.name and sym.entry['st_info']['type'] != 'STT_FILE':
                    continue
                sym_addr = sym.entry.st_value
                if sym_addr == 0 or sym.entry['st_info']['type'] == 'STT_NOTYPE':
                    continue
                if sym_addr not in symbols_by_address:
                    symbols_by_address[sym_addr] = ([], [])
                arr_idx = 0 if sym.entry['st_info']['bind'] == 'STB_GLOBAL' else 1
                symbols_by_address[sym_addr][arr_idx].append(sym)

        for section in sections:
            for sym in section.iter_symbols():
                if not sym.name and sym.entry['st_info']['type'] != 'STT_FILE':
                    continue
                sym_addr = sym.entry.st_value
                if sym_addr == 0 or sym.entry['st_info']['type'] == 'STT_NOTYPE':
                    yield sym
                    continue
                syms_global, syms_non_global = symbols_by_address[sym_addr]
                if syms_global:
                    yield from _get_dyn_syms(syms_global)
                    continue
                yield from _get_dyn_syms(syms_non_global)

    def _calculate_size(self, symbols: list[elftools_sections.Symbol], sorted_symbol_indices: list[int], idx: int, elf: ELFFile, calculate_size_cache: dict[int, int]) -> int:
        if not symbols or idx < 0:
            return 0

        if len(symbols) != len(sorted_symbol_indices):
            logger.warning('mismatch of symbols and sorted_symbol_indices lengths.')
            return 0

        symbol = symbols[idx]
        sym_name = symbol.name
        sym_addr = get_sym_addr(symbol.entry.st_value, self.elffile_info.architecture)
        sym_size = symbol.entry.st_size
        sym_type = symbol.entry.st_info.type

        if sym_size > 0 or sym_addr == 0 or sym_type != 'STT_FUNC' or sorted_symbol_indices[idx] == len(symbols) - 1:
            return sym_size

        sorted_symbol_idx = [sort_sym_idx for sort_sym_idx, sym_idx in enumerate(sorted_symbol_indices) if sym_idx == idx]
        if len(sorted_symbol_idx) != 1:
            logger.warning(f'corrupted sorted_symbol_indices list. for symbol idx: {idx}, sorted symbol indices: {sorted_symbol_idx} were found.')
            return 0

        section_idx = symbol.entry.st_shndx
        section_end = calculate_size_cache.get(section_idx, -1)
        if section_end == -1:
            sec = elf.get_section(section_idx)
            section_end = sec['sh_addr'] + sec['sh_size']
            calculate_size_cache[section_idx] = section_end
        max_size = max(0, section_end - sym_addr)

        def _is_boundary(sym: elftools_sections.Symbol) -> bool:
            # only consider functions or global/weak symbols with size != 0
            st_info = sym.entry['st_info']
            return st_info.type == 'STT_FUNC' or st_info.bind in ('STB_GLOBAL', 'STB_WEAK')

        # check if symbol overlaps (instructions will already be processed from another symbol)
        prev_sorted_idx = sorted_symbol_idx[0]
        while prev_sorted_idx != 0:
            prev_sorted_idx -= 1
            prev_sym = symbols[sorted_symbol_indices[prev_sorted_idx]]
            if not _is_boundary(prev_sym):
                continue
            prev_sym_name = prev_sym.name
            prev_sym_addr = get_sym_addr(prev_sym.entry.st_value, self.elffile_info.architecture)
            prev_sym_size = prev_sym.entry.st_size
            prev_sym_type = prev_sym.entry.st_info.type
            if prev_sym_type != 'STT_FUNC':
                continue
            if prev_sym_addr <= sym_addr < prev_sym_addr + prev_sym_size:
                # overlapping function found
                logger.warning(f'zero-sized symbol {sym_name} ({hex(sym_addr)}) overlaps with symbol {prev_sym_name} ({hex(prev_sym_addr)} - {hex(prev_sym_addr + prev_sym_size)})')
                return 0

        # calculate symbol's size
        next_sorted_idx = sorted_symbol_idx[0]
        while next_sorted_idx < len(sorted_symbol_indices) - 1:
            next_sorted_idx += 1
            next_sym = symbols[sorted_symbol_indices[next_sorted_idx]]
            if not _is_boundary(next_sym):
                continue
            next_sym_addr = get_sym_addr(next_sym.entry.st_value, self.elffile_info.architecture)
            if next_sym_addr > sym_addr:
                calc_size = max(0, min(max_size, next_sym_addr - sym_addr))
                logger.info(f'assigning calculated size {calc_size} to symbol {sym_name}')
                return calc_size

        return 0

    # load and organize elf symbols
    def _process_elf_symbols(self, symbols: list[elftools_sections.Symbol], elf: ELFFile):
        dyn_elf_symbols = list(elfplt.get_dyn_elf_symbols(elf=elf, cs_arch=self.elffile_info.cs_arch, cs_mode=self.elffile_info.cs_mode, logger=logger))
        plt_stub_entries = {x.symbol.name: x for x in dyn_elf_symbols}
        is_rust = utility.is_rust_elf(elf)
        source = None

        if self.elffile_info.architecture in (Architecture.ARM, Architecture.AARCH64, Architecture.ARM_CORTEXM):
            # remove marker symbols
            markers = [marker.value for marker in ArmMarkers]
            symbols = [sym for sym in symbols if sym.name not in markers]

        sorted_symbol_indices = [i for i, _ in sorted(enumerate(symbols), key=lambda s: s[1].entry.st_value)]

        def _find_plt_stub(symbol_name: str) -> tuple[str, elfplt.PLTStubEntry] | tuple[None, None]:
            for plt_sym_name in get_matching_symbol_names(symbol_name):
                plt_stub = plt_stub_entries.get(plt_sym_name, None)
                if plt_stub:
                    return (plt_sym_name, plt_stub)
            return (None, None)

        def _add_symbol(sym_addr: int, sym_size: int, sym_name: str, sym_bind: str, sym_type: str, sym_visibility: str, associated_object: str, sym_is_import: bool, sym_is_plt: bool, sym_is_alias: bool):
            if sym_addr == 0 and not self.elffile_info.is_relocatable:
                # logger.warning(f'address: 0. symbol: {sym_name}')
                return
            if sym_size == 0:
                logger.debug(f'skipping zero-sized symbol {sym_name}')
                return
            demangled = self.get_demangled_name(sym_name)
            _, namespace, short_name = utility.extract_symbol_simple_name(demangled)
            if sym_is_plt or (sym_is_import and sym_type == 'STT_FUNC'):
                sym_name += PLT_SUFFIX
                short_name += PLT_SUFFIX
            symbol = ELFSymbol(sym_name,
                                short_name,
                                demangled,
                                sym_addr,
                                sym_size,
                                sym_bind,
                                sym_type,
                                sym_visibility,
                                associated_object,
                                namespace,
                                False,
                                sym_is_import,
                                is_rust)
            if not sym_is_alias:
                if sym_addr in self.elf_symbols:
                    existing_symbol = self.elf_symbols[sym_addr]
                    if sym_name != existing_symbol.name and all(sym_name != alias.name for alias in existing_symbol.aliases):
                        # cover plt alias cases (if there)
                        logger.info(f'Found existing symbol: {existing_symbol.name} at address {hex(sym_addr)}. Add symbol: {sym_name} as alias.')
                        self.elf_symbols[sym_addr].aliases.append(symbol)
                else:
                    self.elf_symbols[sym_addr] = symbol

            return symbol

        defined_non_alias_symbols = {}
        def _funcs_and_objects(symbols: list[elftools_sections.Symbol]):
            for _, symbol in enumerate(symbols):
                sym_size = symbol.entry.st_size
                sym_addr = get_sym_addr(symbol.entry.st_value, self.elffile_info.architecture)
                if (sym_addr == 0 and not self.elffile_info.is_relocatable) or (symbol.entry.st_info.type not in ('STT_FUNC', 'STT_OBJECT')):
                    continue
                yield symbol.name, sym_addr, sym_size

        # find first non-zero sized symbol and mark as defined non-alias symbol
        for sym_name, sym_addr, sym_size in _funcs_and_objects(symbols):
            if sym_addr in defined_non_alias_symbols:
                continue
            if sym_size != 0:
                defined_non_alias_symbols[sym_addr] = sym_name
        
        # mark rest of undefined symbols (first 0 sized) as non-alias symbols
        for sym_name, sym_addr, sym_size in _funcs_and_objects(symbols):
            if sym_addr not in defined_non_alias_symbols:
                defined_non_alias_symbols[sym_addr] = sym_name

        elf_symbol_aliases = {}
        calculate_size_cache = {}
        for idx, symbol in enumerate(symbols):
            sym_name = symbol.name
            sym_addr = get_sym_addr(symbol.entry.st_value, self.elffile_info.architecture)
            sym_size = symbol.entry.st_size
            sym_type = symbol.entry.st_info.type
            sym_bind = symbol.entry.st_info.bind
            sym_is_import = symbol.entry.st_shndx == "SHN_UNDEF" and symbol.entry.st_info.bind in ("STB_GLOBAL", "STB_WEAK")
            sym_visibility = symbol.entry.st_other.visibility
            if sym_type == 'STT_FILE':
                source = sym_name.split('/')[-1].split('\\')[-1]
            elif sym_type in ('STT_FUNC', 'STT_OBJECT'):
                sym_is_plt: bool = False
                if sym_is_import:
                    plt_sym_name, plt_stub = _find_plt_stub(sym_name)
                    if not plt_stub:
                        logger.warning(f'unresolved external symbol: {sym_name}')
                        continue
                    sym_is_plt = True
                    sym_addr = plt_stub.addr
                    sym_size = plt_stub.size
                    del plt_stub_entries[plt_sym_name]
                sym_is_alias = sym_addr in defined_non_alias_symbols and sym_name != defined_non_alias_symbols[sym_addr]
                sym_size = self._calculate_size(symbols, sorted_symbol_indices, idx, elf, calculate_size_cache) if sym_size == 0 and not sym_is_alias else sym_size
                associated_obj = '' if source is None else source
                elf_symbol = _add_symbol(sym_addr, sym_size, sym_name, sym_bind, sym_type, sym_visibility, associated_obj, sym_is_import, sym_is_plt, sym_is_alias)
                if sym_is_alias and elf_symbol:
                    if sym_addr not in elf_symbol_aliases:
                        elf_symbol_aliases[sym_addr] = set()
                    elf_symbol_aliases[sym_addr].add(elf_symbol)

        # add symbol aliases
        for idx, symbol in enumerate(symbols):
            sym_addr = get_sym_addr(symbol.entry.st_value, self.elffile_info.architecture)
            sym_is_alias = sym_addr in defined_non_alias_symbols and symbol.name != defined_non_alias_symbols[sym_addr]
            if sym_addr in elf_symbol_aliases and not sym_is_alias:
                exs_aliases = self.elf_symbols[sym_addr].aliases
                new_aliases = list(elf_symbol_aliases[sym_addr])
                if not exs_aliases or exs_aliases != new_aliases:
                    if exs_aliases:
                        logger.warning(f'Overwriting existing aliases: {[alias.name for alias in new_aliases]} for symbol at address {hex(sym_addr)}, with new aliases: {[alias.name for alias in exs_aliases]}')
                    self.elf_symbols[sym_addr].aliases = [elf_sym for elf_sym in elf_symbol_aliases[sym_addr] if elf_sym.name != symbol.name]

        # if there are entries left in plt_stub_entries, check if there are corresponding symbols and add them
        if plt_stub_entries:
            source = None
            for idx, symbol in enumerate(symbols):
                sym_type = symbol.entry.st_info.type
                if sym_type == 'STT_FILE':
                    source = sym_name.split('/')[-1].split('\\')[-1]
                    continue
                if sym_type != 'STT_FUNC':
                    continue
                sym_is_import = symbol.entry.st_shndx == "SHN_UNDEF" and symbol.entry.st_info.bind in ("STB_GLOBAL", "STB_WEAK")
                if sym_is_import:
                    continue # these are already checked
                sym_name = symbol.name
                plt_sym_name, plt_stub = _find_plt_stub(sym_name)
                if not plt_stub:
                    continue
                sym_addr = plt_stub.addr
                sym_size = self._calculate_size(symbols, sorted_symbol_indices, idx, elf, calculate_size_cache) if plt_stub.size == 0 else plt_stub.size
                sym_bind = symbol.entry.st_info.bind
                sym_visibility = symbol.entry.st_other.visibility
                sym_is_import = True # it's a plt stub, even though not technically an import
                del plt_stub_entries[plt_sym_name]
                associated_obj = '' if source is None else source
                _add_symbol(sym_addr, sym_size, sym_name, sym_bind, sym_type, sym_visibility, associated_obj, sym_is_import, True, False)
        
    def _post_process_elf_symbols(self):
        for addr, sym in list(self.elf_symbols.items()):
            if not sym.aliases:
                continue

            group = [sym, *sym.aliases]

            def _rank_symbols(s: ELFSymbol):
                plt = s.name.endswith(PLT_SUFFIX)
                if "@@" in s.name:
                    rank = 0
                elif "@" in s.name and not plt:
                    rank = 1
                elif not plt:
                    rank = 2
                elif s.bind == 'STB_GLOBAL':
                    rank = 3
                elif s.bind == 'STB_WEAK':
                    rank = 4
                elif s.bind == 'STB_LOCAL':
                    rank = 5
                else:
                    rank = 6
                return (rank, s.name_id)

            group.sort(key=_rank_symbols)

            new_parent = group[0]
            new_aliases = group[1:]

            if '@@' in new_parent.name:
                version = new_parent.name.split('@@')[1]
                alias_exists = bool([alias for alias in new_aliases if f'@{version}' in alias.name])
                if not alias_exists:
                    new_alias = copy.deepcopy(new_parent)
                    new_alias._replace_substr_in_names('@@', '@')
                    new_parent.aliases = [new_alias]

            new_parent.aliases.extend(new_aliases)

            for alias in new_aliases:
                alias.aliases.clear()

            self.elf_symbols[addr] = new_parent

            if not new_parent.aliases:
                logger.error("New parent has no aliases")
            for a in new_parent.aliases:
                if a.aliases:
                    logger.error("Alias with aliases")

    def get_demangled_name(self, mangled_name: str, no_args: bool = True) -> DemangledNoArgs|DemangledFull:
        filter_static_init_prefix = '_GLOBAL__sub_I_'
        has_static_init_prefix = mangled_name.startswith(filter_static_init_prefix)
        search_symbol = mangled_name
        if has_static_init_prefix:
            search_symbol = mangled_name[len(filter_static_init_prefix):]
        if search_symbol in self.mangled_to_demangled:
            demangled = self.mangled_to_demangled[search_symbol]
            if has_static_init_prefix:
                # demangling of symbol with the filtered prefix will not work, hence we use this "hack" to retrieve the correct data as needed
                return f'{filter_static_init_prefix}{demangled[1]}' if no_args else f'{filter_static_init_prefix}{demangled[0]}'
            return demangled[1] if no_args else demangled[0]
        logger.debug(f'No demangled name found for: {mangled_name}. Skipping demangling.')
        return mangled_name

    def get_prefixed_symbol_name(self, symbol: str):
        return f'{self.symbol_prefix}{symbol}' if re.match(r'^sub_[0-9a-fA-F]+', symbol) else symbol

@dataclasses.dataclass
class VarAccess:
    def __init__(self, name):
        self.name= name
        self.read_accesses: dict[int, InstructionAddrs] = {}
        self.write_accesses: dict[int, InstructionAddrs] = {}

    def add_read_access(self, sym: int, instruction_addr: int):
        if sym not in self.read_accesses:
            self.read_accesses[sym] = [instruction_addr]
        else:
            self.read_accesses[sym].append(instruction_addr)

    def add_write_access(self, sym: int, instruction_addr: int):
        if sym not in self.write_accesses:
            self.write_accesses[sym] = [instruction_addr]
        else:
            self.write_accesses[sym].append(instruction_addr)

@dataclasses.dataclass
class VarManager:
    prefix: str
    section_ranges: list[tuple[int, int]]
    vars: dict[int ,str]
    var_accesses: dict[int, VarAccess]

    def __init__(self, elf: ELFFile, prefix: str, use_gen_symbols: bool, filter_functions: bool):
        if not elf:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message='invalid elf file in var manager')
        self.prefix: str = prefix
        self.section_ranges: list[tuple[int, int]] = []
        self.vars: dict[int ,str] = {}
        self.var_accesses: dict[UniqueMangled, VarAccess] = {}
        if use_gen_symbols:
            self.add_data_section_ranges(elf=elf, filter_functions=filter_functions)

    def gen_name(self, addr: int) -> str|None:
        if addr in self.vars:
            return self.vars[addr]
        for section_range in self.section_ranges:
            if ((section_range[0] <= addr) and (addr <= section_range[1])):
                name = f'{self.prefix}_var_{hex(addr)[2:]}'
                self.vars[addr] = name
                return name
        return None

    def add_data_section_ranges(self, elf: ELFFile, filter_functions: bool):
        for section in elf.iter_sections():
            sec_type = section['sh_type']
            sec_flag = section['sh_flags']
            if section and (sec_type == 'SHT_NOBITS' or sec_type == 'SHT_PROGBITS') and sec_flag & SH_FLAGS.SHF_WRITE and sec_flag & SH_FLAGS.SHF_ALLOC:
                if filter_functions and ('.got' in section.name):
                    logger.warning(f'Skipping data section {section.name}')
                    continue
                sec_addr = section['sh_addr']
                sec_size = section['sh_size']
                self.section_ranges.append((sec_addr, sec_addr + sec_size))

class InsnType(IntEnum):
    NONE = -1
    CALL = 1
    LOAD = 2
    STORE = 3

@dataclasses.dataclass
class InsnInfo:
    type = InsnType.NONE
    reg: str = ''
    base: str = ''
    index: str = ''
    disp: int = -1

@dataclasses.dataclass
class ElfInstruction:
    @staticmethod
    def is_invalid(insn: capstone.CsInsn) -> bool:
        return insn is None or insn.id == 0 or insn.mnemonic == '.byte' or insn.group(capstone.CS_GRP_INVALID)

    @staticmethod
    def is_data_sequence(insn: capstone.CsInsn) -> bool:
        return insn.mnemonic == '.byte'

    @staticmethod
    def src_regs(insn: capstone.CsInsn) -> list[str]:
        if not insn:
            return []
        return [insn.reg_name(op.reg) for op in insn.operands if (op.type == capstone.CS_OP_REG) and ((op.access & capstone.CS_AC_READ) == capstone.CS_AC_READ)]
    
    @staticmethod
    def dst_regs(insn: capstone.CsInsn) -> list[str]:
        if not insn:
            return []
        return [insn.reg_name(op.reg) for op in insn.operands if (op.type == capstone.CS_OP_REG) and ((op.access & capstone.CS_AC_WRITE) == capstone.CS_AC_WRITE)]
    
    @staticmethod
    def is_nop(insn: capstone.CsInsn, architecture: Architecture) -> bool:
        def _is_pre_ual_nop(insn: capstone.CsInsn, architecture: Architecture) -> bool:
            # From documentation, Pre-UAL pseudo-instruction NOP:
            # MOV R0, R0 in the ARM instruction set
            # MOV R8, R8 in the Thumb instruction set.
            if architecture != Architecture.ARM_CORTEXM and architecture != Architecture.ARM and architecture != Architecture.AARCH64:
                return False
            if insn.mnemonic == "nop.w":
                return True
            if insn.mnemonic != 'mov':
                return False
            regs = [insn.reg_name(op.reg) for op in insn.operands if op.type == capstone.CS_OP_REG and hasattr(op, 'reg')]
            # TODO: Verify if in aarch64 instruction sequences marked by ARM marker symbols, for cortexM apps, nop will be r0/r0 or r8/r8  
            if architecture == Architecture.AARCH64:
                return regs == ['r0', 'r0']
            return regs == ['r8', 'r8']
        return insn.mnemonic == 'nop' or _is_pre_ual_nop(insn=insn, architecture=architecture)

    @staticmethod
    def is_jump(insn: capstone.CsInsn, architecture: Architecture) -> bool:
        if ElfInstruction.is_invalid(insn):
            return False
        is_jump_fallback = ElfInstruction.is_unconditional_jump(insn, architecture) or ElfInstruction.is_conditional_jump(insn, architecture)
        return (insn.group(capstone.CS_GRP_JUMP) or is_jump_fallback) and not ElfInstruction.is_return(insn, architecture)

    @staticmethod
    def is_conditional_jump(insn: capstone.CsInsn, architecture: Architecture) -> bool:
        if ElfInstruction.is_invalid(insn):
            return False
        if architecture == Architecture.TRICORE:
            # Previously: return not ElfInstruction.is_unconditional_jump(insn=insn, architecture=architecture)
            # (Kept here as a fallback reference in case of unexpected issues)
            return insn.mnemonic in set(INSTRUCTIONS[CONDITIONAL_BRANCHING_INSTRUCTIONS][architecture.value])
        # Special handling for Thumb-mode conditional branches that don't use condition codes
        if insn.mnemonic in ('cbz', 'cbnz', 'tbz', 'tbnz'):
            return True
        if not hasattr(insn, 'cc'):
            return False
        # Docs: https://docs.rs/capstone-sys/latest/capstone_sys/enum.arm64_cc.html#variant.ARM64_CC_AL
        is_jump = insn.group(capstone.CS_GRP_JUMP)
        if architecture == Architecture.ARM_CORTEXM:
            if insn.mnemonic in ('tbb', 'tbh'):
                return True
            return is_jump and insn.cc not in (capstone.arm_const.ARM_CC_INVALID, capstone.arm_const.ARM_CC_AL)
        return is_jump and insn.cc not in (capstone.arm64_const.ARM64_CC_INVALID, capstone.arm64_const.ARM64_CC_AL, capstone.arm64_const.ARM64_CC_NV)

    @staticmethod
    def is_unconditional_jump(insn: capstone.CsInsn, architecture: Architecture) -> bool:
        if ElfInstruction.is_invalid(insn):
            return False
        if architecture == Architecture.ARM_CORTEXM: # just in manual mode (for now only working mode for CortexM)
            if insn.mnemonic in INSTRUCTIONS[UNCONDITIONAL_BRANCHING_INSTRUCTIONS][architecture.value]:
                return 'pc' in ElfInstruction.dst_regs(insn=insn)
        if architecture == Architecture.TRICORE: # just in manual mode (for now only working mode for TriCore)
            return insn.mnemonic in set(INSTRUCTIONS[UNCONDITIONAL_BRANCHING_INSTRUCTIONS][architecture.value])
        if insn.mnemonic in set(INSTRUCTIONS[UNCONDITIONAL_BRANCHING_INSTRUCTIONS][architecture.value]).difference(set(INSTRUCTIONS[BRANCH_WITH_LINK_INSTRUCTIONS][architecture.value])):
            return True
        if architecture in (Architecture.AARCH64, Architecture.ARM, Architecture.ARM_CORTEXM):
            if insn.mnemonic == 'b':
                return True
            if hasattr(insn, 'cc'):
                is_jump = insn.group(capstone.CS_GRP_JUMP)
                if architecture == Architecture.AARCH64:
                    return is_jump and insn.mnemonic.startswith('b.') and insn.cc == capstone.arm64_const.ARM64_CC_AL
                return is_jump and insn.mnemonic.startswith('b') and insn.cc == capstone.arm_const.ARM_CC_AL
        return False
    
    @staticmethod
    def is_return(insn: capstone.CsInsn, architecture: Architecture) -> bool:
        if ElfInstruction.is_invalid(insn):
            return False
        if insn.group(capstone.CS_GRP_RET):
            return True
        mnemonic = ElfInstruction.get_mnemonic_stem(insn=insn)
        is_mnemonic_return = mnemonic in INSTRUCTIONS[RETURN_INSTRUCTIONS][architecture.value]
        if not is_mnemonic_return or architecture != Architecture.ARM_CORTEXM:
            return is_mnemonic_return
        if mnemonic == 'bx':
            return 'lr' in ElfInstruction.src_regs(insn=insn)
        if mnemonic in set(INSTRUCTIONS[RETURN_INSTRUCTIONS][architecture.value]).difference({'bx'}):
            dst_regs = ElfInstruction.dst_regs(insn=insn)
            if mnemonic == 'mov':
                return 'pc' in dst_regs and 'lr' in ElfInstruction.src_regs(insn=insn)
            return 'pc' in dst_regs
        return False

    @staticmethod
    def get_mnemonic_stem(insn: capstone.CsInsn):
        if not insn:
            return
        mnemonic = insn.mnemonic
        condition = next((c for c in INSTRUCTIONS[CONDITIONS] if mnemonic.endswith(c)), None)
        mnemonic = f"{mnemonic[:-len(condition)]}.{condition}" if condition else mnemonic
        return mnemonic.split('.')[0]

    @staticmethod
    def parse_memory_access(insn: capstone.CsInsn, for_access: InsnType = None, match_ldr_str: bool = True) -> None|InsnInfo:
        mnemonic = insn.mnemonic.lower()
        data: InsnInfo = InsnInfo()
        if mnemonic == 'ldr' if match_ldr_str else mnemonic.startswith('ldr'):
            data.type = InsnType.LOAD
        elif mnemonic == 'str' if match_ldr_str else mnemonic.startswith('str'):
            data.type = InsnType.STORE
        if data.type == InsnType.NONE or (for_access and for_access != data.type):
            return None
        for op in insn.operands:
            if op.type == capstone.CS_OP_REG:
                data.reg = insn.reg_name(op.reg)
            elif op.type == capstone.CS_OP_MEM:
                mem = op.mem
                data.disp = mem.disp
                data.base = insn.reg_name(mem.base) if hasattr(mem, 'base')  else None
                data.index = insn.reg_name(mem.index) if hasattr(mem, 'index') else None
        return data
@dataclasses.dataclass
class ElfDisassembler:
    @dataclasses.dataclass
    class DataSequences:
        beg: int
        end: int
        symbol: bool

    @dataclasses.dataclass
    class Asm:
        instructions: list[capstone.CsInsn]
        jump_tables: dict[int, list[int]]

    @staticmethod
    def detect_data_sequences(elffile_info: ElfFileInfo, css: capstone.Cs, relevant_symbols: dict[int, ELFSymbol]) -> list[DataSequences]:
        if elffile_info.architecture != Architecture.ARM_CORTEXM:
            return []

        logger.info("attempting to detect data sequences (literal pools) through disassembly analysis")
        insn_len: int = 4
        pc_data_refs = {}

        symbols = {sym_addr: sym.size for sym_addr, sym in relevant_symbols.items()} if relevant_symbols else \
            {sym.entry.st_value: sym.entry.st_size for sym in SymbolManager.get_elf_symbols(elf=elffile_info.elf)}

        for sym_addr, sym_size in symbols.items():
            for sec_start, sec_end, sec_data in elffile_info.exec_sections:
                if sec_start <= sym_addr <= sec_end:
                    beg = sym_addr - sec_start
                    end = beg + sym_size
                    code = sec_data[beg:end]
                    for insn in css.disasm(code, sym_addr):
                        if ElfInstruction.is_invalid(insn):
                            continue
                        # Detect only literal pools that appear as contiguous data items inside the function instructions; embedded jump tables and other types of data must be marked with $d/$t symbols.
                        ii = ElfInstruction.parse_memory_access(insn=insn, for_access=InsnType.LOAD, match_ldr_str=False)
                        if not ii or ii.base != 'pc':
                            continue
                        # From ARM documentation:
                        # In ARM code, the value of the PC is the address of the current instruction plus 8 bytes.
                        # In Thumb code:
                        #    - For B, BL, CBNZ, and CBZ instructions, the value of the PC is the address of the current
                        #      instruction plus 4 bytes.
                        #    - For all other instructions that use labels, the value of the PC is the address of the current
                        #      instruction plus 4 bytes, with bit[1] of the result cleared to 0 to make it word-aligned.
                        #
                        pc = (insn.address & ~0x3) + insn_len
                        data_addr = pc + ii.disp
                        if data_addr not in symbols and insn.address not in pc_data_refs:
                            pc_data_refs[insn.address] = data_addr
                    break

        # remove invalid refs (calculated refs of instructions that are actually part of literal pools)
        invalid_addrs = {addr for _, addr in pc_data_refs.items() if addr in pc_data_refs}
        for addr in invalid_addrs:
            del pc_data_refs[addr]

        # merge literal pools
        data_addrs = sorted(pc_data_refs.values())
        data_seqs: list[ElfDisassembler.DataSequences] = []

        if not data_addrs:
            return data_seqs

        curr_beg = data_addrs[0]
        curr_end = curr_beg + insn_len
        for addr in data_addrs[1:]:
            if addr <= curr_end:
                curr_end = max(curr_end, addr + insn_len)
            else:
                data_seqs.append(ElfDisassembler.DataSequences(beg=curr_beg, end=curr_end, symbol=False))
                curr_beg = addr
                curr_end = addr + insn_len

        # append last one
        data_seqs.append(ElfDisassembler.DataSequences(beg=curr_beg, end=curr_end, symbol=False))
        return data_seqs

    @staticmethod
    def marked_data_sequences(elffile_info: ElfFileInfo, relevant_symbols: dict[int, ELFSymbol]) -> list[DataSequences]:
        if elffile_info.architecture != Architecture.ARM_CORTEXM:
            return []

        logger.info("searching for data sequence markers (e.g. $d/$t symbols)")
        data_seq_ranges: dict[int, bool] = {}
        for sym in SymbolManager.get_elf_symbols(elf=elffile_info.elf):
            sym_name = sym.name
            sym_addr = sym.entry.st_value
            sym_type = sym.entry.st_info.type
            if sym_type == 'STT_NOTYPE':
                is_data_marker = sym_name.startswith(ArmMarkers.DATA.value)
                is_insn_marker = sym_name.startswith(ArmMarkers.ARM_THUMB_CODE.value)
                if is_data_marker or is_insn_marker:
                    data_seq_ranges[sym_addr] = is_data_marker

        data_seqs: list[ElfDisassembler.DataSequences] = []
        beg = None
        for lp_addr, is_begin in sorted(data_seq_ranges.items()):
            if relevant_symbols:
                skip = True
                for sym_addr, sym in relevant_symbols.items():
                    if sym_addr <= lp_addr <= (sym_addr + sym.size):
                        skip = False
                        break
                if skip:
                    continue
            if is_begin:
                if beg:
                    # begin already set. merging with the previous literal pool. This is rare and acceptable for our use case.
                    continue
                beg = lp_addr
            else:
                if beg:
                    data_seqs.append(ElfDisassembler.DataSequences(beg=beg, end=lp_addr, symbol=True))
                    beg = None
        if beg:
            # find appropriate end of literal pool - case where last symbol of section is ending with literal pool
            for sym_addr, sym in relevant_symbols.items():
                if sym_addr <= beg <= (sym_addr + sym.size):
                    data_seqs.append(ElfDisassembler.DataSequences(beg=beg, end=(beg + sym.size), symbol=True))
        return data_seqs

    @staticmethod
    def compare_data_sequences(marked: list[DataSequences], detected: list[DataSequences]):
        def to_str(ds: ElfDisassembler.DataSequences) -> str:
            return f"[{hex(ds.beg)} - {hex(ds.end)}]"

        def ranges_overlap(ds_1: ElfDisassembler.DataSequences, ds_2: ElfDisassembler.DataSequences) -> bool:
            return not (ds_1.end <= ds_2.beg or ds_2.end <= ds_1.beg)

        def ranges_match(ds_1: ElfDisassembler.DataSequences, ds_2: ElfDisassembler.DataSequences) -> bool:
            return ds_1.beg == ds_2.beg and ds_1.end == ds_2.end

        matching = []
        overlapping = []
        only_in_marked = []
        only_in_detected = []

        for m in marked:
            if not any(ranges_overlap(m, d) for d in detected):
                only_in_marked.append(m)
            elif any(ranges_match(m, d) for d in detected):
                matching.append(m)
            else:
                overlapping.append(m)

        for d in detected:
            if not any(ranges_overlap(d, m) for m in marked):
                only_in_detected.append(d)

        if matching:
            logger.debug("Matching data sequences:")
            for ds in matching:
                logger.debug(f"- {to_str(ds)}")

        if overlapping:
            logger.debug("Overlapping data sequences:")
            for ds in overlapping:
                logger.debug(f"- {to_str(ds)}")

        if only_in_marked:
            logger.debug("Only in marked data sequences:")
            for ds in only_in_marked:
                logger.debug(f"- {to_str(ds)}")

        if only_in_detected:
            logger.debug("Only in detected data sequences:")
            for ds in only_in_detected:
                logger.debug(f"- {to_str(ds)}")

    @staticmethod
    def disassemble_chunk(dis_beg: int, dis_end: int, sec_beg: int, sec_data, css: capstone.Cs,  architecture: Architecture, strings = {}, data_seqs: list[DataSequences] = [], asm_file = None):
        if dis_beg > dis_end or dis_beg == dis_end or not sec_data or dis_beg < sec_beg or not css:
            logger.warning("Incorrect arguments provided; disassembly interrupted.")
            return None

        symbol_data_seqs = [lp for lp in data_seqs if dis_beg <= lp.beg < dis_end]
        jump_tables = {}
        last_addr = dis_beg
        instructions = []

        def disasm(beg: int, end: int):
            jump_table_callee = None
            code = sec_data[beg - sec_beg:end - sec_beg]
            check_if_alignment_follows = False
            for insn in css.disasm(code, beg):
                if asm_file:
                    asm_file.write(f'{insn.address:8x}:  {insn.mnemonic} {insn.op_str}\n')
                if check_if_alignment_follows and not ElfInstruction.is_nop(insn, architecture):
                    logger.warning(f'No alignment instruction found after jump table callee at address: {hex(jump_table_callee)}. Found instruction: {hex(insn.address)}: {insn.mnemonic} {insn.op_str}')
                if not ElfInstruction.is_invalid(insn):
                    if architecture == Architecture.ARM_CORTEXM and insn.mnemonic == 'mov' and 'pc' in ElfInstruction.dst_regs(insn=insn):
                        if jump_table_callee:
                            logger.warning(f'Address has already been associated as jump table callee: {hex(jump_table_callee)}. Overwriting.')
                        jump_table_callee = insn.address
                        check_if_alignment_follows = True
                    instructions.append(insn)
            return jump_table_callee

        if not symbol_data_seqs:
            # symbol has no data sequences - disassemble everything
            logger.debug(f'asm: {hex(dis_beg)} - {hex(dis_end)}')
            disasm(beg=dis_beg, end=dis_end)
            return ElfDisassembler.Asm(instructions=instructions, jump_tables={})

        # symbol has data sequences - disassemble only instruction chunks
        size = 4 # TODO: As of now, data sequences are only used for ARM Cortex-M, this size however should be adapted for other architectures if needed
        for ds in symbol_data_seqs:
            jump_table_callee = None
            if last_addr < ds.beg:
                logger.debug(f'asm: {hex(last_addr)} - {hex(ds.beg)}')
                jump_table_callee = disasm(beg=last_addr, end=ds.beg)
            logger.debug(f'dsq: {hex(ds.beg)} - {hex(ds.end)}')
            # append data sequence chunk
            for ds_addr in range(ds.beg, ds.end, size):
                beg = ds_addr - sec_beg
                end = beg + size
                ds_data = sec_data[beg:end]
                if jump_table_callee:
                    if jump_table_callee not in jump_tables:
                        jump_tables[jump_table_callee] = []
                    jump_table_addr = int.from_bytes(ds_data, byteorder='little')
                    jump_tables[jump_table_callee].append(get_sym_addr(jump_table_addr, architecture))
                ops = ', '.join(f'0x{byte:02x}' for byte in ds_data if byte)
                insn = capstone.CsInsn(
                    cs=css,
                    all_info=capstone._cs_insn(
                        id=0,
                        address=ds_addr,
                        size=size,
                        op_str=ops.encode("utf-8"),
                        mnemonic=".byte".encode("utf-8"),
                    ),
                )
                if asm_file:
                    ds_value = int.from_bytes(ds_data, byteorder='little')
                    asm_file.write(f'{insn.address:8x}:  {insn.mnemonic} {insn.op_str} # {strings[ds_value] if (ds_value in strings) else ""} \n')
                instructions.append(insn)
            last_addr = ds.end
        # disassemble remaining instructions
        if last_addr != dis_end:
            logger.debug(f'asm: {hex(last_addr)} - {hex(dis_end)}')
            disasm(beg=last_addr, end=dis_end)
        return ElfDisassembler.Asm(instructions=instructions, jump_tables=jump_tables)


    @staticmethod
    def disassemble(elf_file: ELFFile, elffile_info: ElfFileInfo, relevant_symbols: dict[int, ELFSymbol], out_asm_file: str = '') -> dict[ELFSymbol, Asm]:
        asm_per_symbol: dict[ELFSymbol, ElfDisassembler.Asm] = {}
        css = capstone.Cs(elffile_info.cs_arch, elffile_info.cs_mode)
        css.skipdata = elffile_info.architecture == Architecture.ARM_CORTEXM
        css.detail = True
        asm_file = so.open(out_asm_file, 'w', encoding='utf-8') if out_asm_file else None

        strings = elffile_info.extract_strings()
        data_seqs = ElfDisassembler.marked_data_sequences(elffile_info=elffile_info, relevant_symbols=relevant_symbols)
        if not data_seqs:
            data_seqs = ElfDisassembler.detect_data_sequences(elffile_info=elffile_info, relevant_symbols=relevant_symbols, css=css)

        for symbol_addr, elf_symbol in relevant_symbols.items():
            if asm_file:
                asm_file.write(f'\n{symbol_addr:08x} <{elf_symbol.name_id}>:\n')
            section = next((s for s in elffile_info.exec_sections if s[0] <= symbol_addr <= s[1]), None)
            if section is None:
                continue

            sec_beg, _, sec_data = section
            symbol_end = symbol_addr + elf_symbol.size
            asm = ElfDisassembler.disassemble_chunk(
                dis_beg=symbol_addr,
                dis_end=symbol_end,
                sec_beg=sec_beg,
                sec_data=sec_data,
                css=css,
                architecture=elffile_info.architecture,
                strings=strings,
                data_seqs=data_seqs,
                asm_file=asm_file,
            )
            asm_per_symbol[elf_symbol] = asm

        if asm_file:
            asm_file.close()
        return asm_per_symbol

@dataclasses.dataclass
class DWARFAddressSourceInfo:
    address: int
    entry_address: int
    line: int
    column: int
    source: str

@dataclasses.dataclass
class ElfAnalyser:
    def __init__(self,
                 elf_file_path: str = '',
                 elf_debug_file_path: str = '',
                 filter_functions: bool = False,
                 symbol_prefix: str = '',
                 provided_architecture = '',
                 compress_out_csv: bool = False,
                 use_angr: bool | None = None,
                 show_progress: bool = False,
                 dump_cfg: bool = False,
                 cfg_dir: str = '',
                 deps_info: dict[str, dict[str, str]] | None = None,
                 out_asm_file: str = '') -> None:

        logger.info(f'initializing new elf analyser for elf: {elf_file_path}')

        # initialize elf data

        # cleanup after exit
        atexit.register(self.cleanup)

        # general elf analyzer config
        self.filter_functions: bool = filter_functions
        self.symbol_prefix: str = symbol_prefix
        self.show_progress: bool = show_progress
        self.compress_out_csv: bool = compress_out_csv
        self.out_asm_file: str = out_asm_file
        self.architecture: str | None = None

        # elf file info
        self.elf_hash: str = ''
        self.elf_file_path: str = ''
        self.elf_debug_file_path: str = ''
        self.elf_base_name: str = ''
        self.elffile_info: ElfFileInfo | None = None
        self.elf: ELFFile | None = None
        self.elf_debug: ELFFile | None = None

        # elf file buffers
        self.elf_file_buffer = None
        self.elf_debug_file_buffer = None

        # data managers
        self.symbol_manager: SymbolManager | None = None
        self.var_manager: VarManager | None = None
        self.elf_data: CustomElfData | None = None

        # angr config
        self.elf_angr_project: angr.Project | None = None
        self.elf_control_flow_graph: angr.analyses.CFG | None = None

        # DWARF
        self.use_dwarf_resolver: bool = True
        self.use_dwarf_line_ent: bool = False
        self.dwarf_line_entries: list[dwarf_reader.LineEntry] | None = None
        self.dwarf_functions: list[dwarf_reader.FunctionInfo] | None = None
        self.dwarf_function_entry_map: dict[int, list[int]] | None = None
        self.dwarf_resolver: DWARFResolver | None = None

        # validate and initialize elf file info data
        if not ASMSlicerUtils.validate_file_path(file_path=elf_file_path):
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message='invalid elf file')

        # set elf file info
        self.elf_file_path = os.path.abspath(elf_file_path)
        self.elf_debug_file_path = os.path.abspath(elf_debug_file_path) if ASMSlicerUtils.validate_file_path(file_path=elf_debug_file_path) else ''
        self.elf_base_name = os.path.basename(self.elf_file_path)
        self.elf_hash = utility.hash_file_xxh128(self.elf_file_path)

        # load elf files
        try:
            self.elf_file_buffer = open(self.elf_file_path, 'rb')
            if self.elf_file_buffer:
                self.elf = ELFFile(self.elf_file_buffer)
            if self.elf_debug_file_path:
                self.elf_debug_file_buffer = open(self.elf_debug_file_path, 'rb')
                if self.elf_debug_file_buffer:
                    self.elf_debug = ELFFile(self.elf_debug_file_buffer)
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'loading elf file failed: {e}') from e

        # set file info
        self.elffile_info = ElfFileInfo(elf=self.elf, elf_path=self.elf_file_path, provided_architecture=provided_architecture)

        if self.elffile_info.is_stripped:
            raise ASMSlicerException(error_code=ASMSlicerError.ELF_STRIPPED, message='stripped elf')

        if use_angr is None:
            use_angr = ARCHITECTURE_ANGR_SUPPORT[self.elffile_info.architecture]

        if self.elffile_info.is_relocatable:
            use_angr = False

        if use_angr and self.elffile_info.architecture in ('tricore', 'cortexm'):
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'{self.elffile_info.architecture} architecture not supported in angr mode')

        if not use_angr and self.elffile_info.is_stripped:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message='stripped ELF not supported without angr mode')

        if use_angr:
            self.elf_angr_project = ElfAnalyser.set_up_angr_project(elf_file_path=self.elf_file_path,
                                                                    elf_debug_file_path=self.elf_debug_file_path,
                                                                    architecture=self.elffile_info.architecture,
                                                                    is_pic=self.elffile_info.is_pic)
            if not self.elf_angr_project:
                raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message='error creating angr project')
            self.elffile_info.set_elf_architecture(self.elf_angr_project.arch.name)
            logger.info(f'new angr project created for architecture: {self.elf_angr_project.arch.name}')

        # check if generated symbols should be used
        self.use_gen_symbols = utility.use_gen_symbols(self.elffile_info.is_stripped, self.elf_angr_project)

        # cfg pickle file
        self.dump_cfg = dump_cfg
        if self.dump_cfg and cfg_dir:
            au.Path.makedirs(cfg_dir)
        if cfg_dir:
            cfg_dir = au.Path.abspath(cfg_dir)
        self.cfg_file = os.path.join(cfg_dir or au.Path.dirname(self.elf_file_path), utility.gen_cfg_file_slim(self.elf_hash, self.use_gen_symbols, self.filter_functions))

        # deps info
        self.deps_info = deps_info or {}

        # initialize elf symbol manager
        self.symbol_manager: SymbolManager = SymbolManager(elf=self.elf, elf_debug=self.elf_debug, symbol_prefix=self.symbol_prefix, elffile_info=self.elffile_info)

        # initialize elf var manager
        self.var_manager: VarManager = VarManager(elf=self.elf, prefix=self.symbol_prefix, use_gen_symbols=self.use_gen_symbols, filter_functions=self.filter_functions)

    def cleanup(self):
        if self.elf_file_buffer:
            self.elf_file_buffer.close()
            self.elf_file_buffer = None

        if self.elf_debug_file_buffer:
            self.elf_debug_file_buffer.close()
            self.elf_debug_file_buffer = None

        self.filter_functions = None
        self.symbol_prefix = None
        self.show_progress = None
        self.architecture = None
        self.compress_out_csv = None

        self.elf_hash = None
        self.elf_file_path = None
        self.elf_debug_file_path = None
        self.elf_base_name = None

        self.elffile_info = None
        self.elf = None
        self.elf_debug = None

        self.symbol_manager = None
        self.var_manager = None
        self.elf_data = None

        self.elf_angr_project = None
        self.elf_control_flow_graph = None

        self.dwarf_line_entries = None
        self.dwarf_functions = None
        self.dwarf_resolver = None
        self.dwarf_function_entry_map = None


    def get_elf_data(self) -> CustomElfData:
        if not self.elf_data:
            self.elf_data = self.build_elf_data_angr(elf_angr_project=self.elf_angr_project) if self.elf_angr_project else self.build_elf_data_capstone()
            logger.info(f'relevant functions coverage: {self.elf_data.statistics.relevant_functions_coverage}%')
            if self.elf_data.statistics.relevant_functions_coverage != 100:
                processed_functions = set(symbol.symbol.name_id for symbol in self.elf_data.functions)
                for relevant_sym in self.get_all_elf_symbols(symbol_type='STT_FUNC'):
                    if relevant_sym.name_id not in processed_functions:
                        reason = ''
                        sym_in_segments = [s for s in self.elffile_info.load_segments if s[0] <= relevant_sym.addr < s[1]]
                        sym_in_sections = [s for s in self.elffile_info.exec_sections if s[0] <= relevant_sym.addr < s[1]]
                        if not sym_in_segments and not sym_in_sections:
                            reason = f'address {hex(relevant_sym.addr)} outside of elf\'s loaded segments and executable sections'
                        logger.debug(f'missing function: {relevant_sym.name_id}. reason: {reason}')
            # debug elf data
            # gr = nx.DiGraph()
            # for func in self.elf_data.functions:
            #     # if func.symbol.name == 'main':
            #         for node in func.control_flow_graph.nodes:
            #             gr.add_node(hex(node))
            #             # print(f'node: {hex(node)}')
            #             for succ in func.control_flow_graph.successors(node):
            #                 gr.add_node(hex(succ))
            #                 gr.add_edge(hex(node), hex(succ))
            #                 # print(f'calls: {hex(succ)}')
            # nx.nx_pydot.write_dot(gr, 'graph.dot')
        return self.elf_data

    def generate_symmap_file(self, out_sym_map_file: str) -> dict[UniqueMangled, ELFSymbol]:
        logger.info("generating symmap file")
        if not out_sym_map_file:
            return
        with so.open(out_sym_map_file, 'w', encoding='utf8') as file:
            csv_writer = csv.writer(file, quoting=csv.QUOTE_MINIMAL)
            csv_writer.writerow(['name', 'long_name', 'start_address', 'size', 'namespace', 'container'])
            symbol_to_container = self.generate_dwarf_source_info()
            written_symbols: set[str] = set()

            def _get_all_symbols(sym: ELFSymbol):
                yield sym
                if sym.addr in self.symbol_manager.elf_symbols:
                    func_sym = self.symbol_manager.elf_symbols[sym.addr]
                    if func_sym.name != sym.name:
                        yield func_sym
                    for alias in func_sym.aliases:
                        if alias.name != sym.name:
                            yield alias

            for function in self.elf_data.get_functions():
                if ElfAnalyser.is_stub_symbol(function.symbol.name):
                    continue
                container = self.get_target_container(function)

                # TODO: This is quickfix for AAD-4154, should be handled properly
                if 'yacht' in self.elf_base_name:
                    if function.symbol.name_id in symbol_to_container:
                        container = '3rdparty'
                        symbol_dwarf_info = symbol_to_container[function.symbol.name_id]
                        fns = symbol_dwarf_info.split(';')
                        for fn in fns:
                            if fn.startswith('/home/nunziopaolo/projectQT/ky_ivi'):
                                container = 'yacht'
                                break

                for sym in _get_all_symbols(function.symbol):
                    key: str = f'{sym.addr}:{sym.name_id}'
                    if key in written_symbols:
                        continue
                    written_symbols.add(key)
                    if sym.short_name.endswith(PLT_SUFFIX):
                        if container and container != self.elf_base_name:
                            csv_writer.writerow([sym.short_name.removesuffix(PLT_SUFFIX), sym.name_id.removesuffix(PLT_SUFFIX), 0, 0, sym.namespace, container])
                        csv_writer.writerow([sym.short_name, sym.name_id, sym.addr, sym.size, sym.namespace, self.elf_base_name])
                    else:
                        csv_writer.writerow([sym.short_name, sym.name_id, sym.addr, sym.size, sym.namespace, container])

        if self.compress_out_csv:
            if out_sym_map_file:
                ASMSlicerUtils.compress_csv_file(input_file_path=out_sym_map_file, remove_original=True)

    def generate_fatbin_file(self, out_fatbin_file: str, out_sym_map_file: str, out_plot_file: str):
        # fatbin file should only be generated if current elf is fatbin and there is symmap and callgraph generated
        logger.info('generating fatbin file')
        if not au.Path.exists(out_sym_map_file):
            logger.error('failed to generate fatbin file because of missing symmap file')
            return
        if not au.Path.exists(out_plot_file):
            logger.error('failed to generate fatbin file because of missing callgraph file')
            return
        logger.info('creating cuda analyser')
        cuda_analyser: CudaAnalyser = CudaAnalyser(elf_file_path=self.elf_file_path, sym_map_file_path=out_sym_map_file)
        logger.info('analysing fatbin')
        cuda_fatbin_analyses: CudaFatbinAnalyses = cuda_analyser.analyse()
        if cuda_fatbin_analyses.is_fatbin:
            # write fatbin report
            with so.open(out_fatbin_file, 'w') as f:
                logger.info('generating fatbin report')
                json.dump(CudaAnalyser.generate_fatbin_report(cuda_fatbin_analyses.fatbin), f, indent=4)
                symmaps_parent_dir = out_sym_map_file.rsplit('/', 1)[0] + '/'
                # create data for each cubin
                relevant_cubins = [cubin for cubin in cuda_fatbin_analyses.fatbin.cubins
                                   if cubin.symbols and any(symbol.type == 'STT_FUNC' and symbol.host_symbol
                                                            for symbol in cubin.symbols)]
                gpu_runtime_lib: string = ''
                gpu_entry_function: string = ''
                def _find_gpu_symbol():
                    for _lib, deps in self.deps_info.items():
                        for sym, dep in deps.items():
                            if dep.startswith('libcudart.so') and sym.split('@')[0] == '__cudaLaunchKernel':
                                for elf_symbol in self.symbol_manager.elf_symbols.values():
                                    if elf_symbol.name.split('@')[0] == '__cudaLaunchKernel':
                                        return dep, elf_symbol.name.removesuffix(PLT_SUFFIX)
                    return '', ''
                gpu_runtime_lib, gpu_entry_function = _find_gpu_symbol()
                if gpu_runtime_lib and gpu_entry_function:
                    logger.info(f'gpu_runtime_lib: {gpu_runtime_lib}')
                    logger.info(f'gpu_entry_function: {gpu_entry_function}')

                with ProcessPoolExecutor(max_workers = mp.cpu_count() - 1) as executor:
                    logger.info('generating cubin data')
                    future_to_item = {executor.submit(CudaAnalyser.generate_cubin_data,
                                                      cubin,
                                                      symmaps_parent_dir,
                                                      symmaps_parent_dir,
                                                      os.path.join(symmaps_parent_dir,
                                                      f'{cubin.name}.blocks.csv'),
                                                      gpu_runtime_lib,
                                                      gpu_entry_function): cubin.name for cubin in relevant_cubins}
                    for future in as_completed(future_to_item):
                        try:
                            _item = future_to_item[future]
                            _result = future.result()
                            # logger.info(f'cubin data generated for {item}')
                        except Exception as e:
                            logger.info(f'{e}')

    def get_target_container(self, elf_function: CustomElfSymbolData) -> str:
        if elf_function.symbol.is_import:
            if self.elf_base_name in self.deps_info:
                info = self.deps_info[self.elf_base_name]
                for name in get_matching_symbol_names(elf_function.symbol.name_id):
                    dep_name = info.get(name, None)
                    if dep_name:
                        return dep_name
            return ''
        return self.elf_base_name

    def generate_vars_file(self, out_file: str):
        logger.info("generating vars file")
        def _discover_accessed_var(block, ef_key):
            if not block.size:
                return
            def _get_var_addr_and_access(stmt):
                if isinstance(stmt, pyvex.stmt.Store):
                    addr = stmt.addr
                    if not isinstance(addr, pyvex.expr.Const):
                        return (None, None)
                    _updated_var_value = stmt.data
                    return (addr.con.value, False)
                expr: pyvex.expr.IRExpr = stmt.data
                if not isinstance(expr, pyvex.expr.Load):
                    return (None, None)
                addr = expr.addr
                if not isinstance(addr, pyvex.expr.Const):
                    return (None, None)
                return (addr.con.value, True)
            def _get_sym_key(addr: int):
                if self.use_gen_symbols:
                    return addr
                syms = [func.symbol.addr for func in self.elf_data.get_variables() if func.symbol.addr == addr]
                if not syms:
                    return None
                sym = syms[0]
                if len(syms) > 1:
                    logger.debug(f'Found multiple symbols (with size > 0) on same address: {addr}. Using first symbol for building variable access data.')
                if not insn_addr:
                    logger.warning(f'Instruction address is unavailable. Skipping variable access: {sym}.')
                    return None
                return sym

            block_bytes: bytearray = bytearray()
            for insn in block.instructions:
                block_bytes.extend(insn.bytes)
            if not block_bytes:
                return
            irsb: pyvex.block.IRSB = pyvex.block.IRSB(block_bytes, block.start_addr, archinfo.arch_from_id(self.elffile_info.architecture))
            insn_addr = None
            stmts: list[pyvex.stmt.IRStmt] = irsb.statements

            for stmt in stmts:
                if isinstance(stmt, pyvex.stmt.IMark):
                    # IMark is an instruction mark. It marks the start of the statements
                    # that represent a single machine instruction (the end of those statements is marked by the next IMark or the end of the IRSB).
                    # Contains the address and length of the instruction.
                    insn_mark: pyvex.stmt.IMark = stmt
                    insn_addr = insn_mark.addr
                if not stmt or not hasattr(stmt, 'data') or not stmt.data:
                    continue
                addr, is_load = _get_var_addr_and_access(stmt)
                if not addr:
                    continue
                sym = _get_sym_key(addr)
                if not sym:
                    continue
                if sym not in self.var_manager.var_accesses:
                    self.var_manager.var_accesses[sym] = VarAccess(sym)
                if is_load:
                    self.var_manager.var_accesses[sym].add_read_access(ef_key, insn_addr)
                else:
                    self.var_manager.var_accesses[sym].add_write_access(ef_key, insn_addr)

        relevant_symbols = {sym.symbol.addr: sym for sym in self.elf_data.get_functions()}

        for addr, sym in relevant_symbols.items():
            for block in sym.blocks.values():
                _discover_accessed_var(block, addr)

        with so.open(out_file, 'w', encoding='utf-8') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow(['long_name', 'addr', 'bind', 'read_count', 'read_by_long_name', 'read_addrs', 'write_count', 'write_by_long_name', 'write_addrs'])
            def write_var(csv_writer, name_id: str, addr: int, bind: str, read_accesses, write_accesses):
                read_accesses = [(key, insn_addrs) for [key, insn_addrs] in read_accesses.items()]
                write_accesses = [(key, insn_addrs) for [key, insn_addrs] in write_accesses.items()]
                csv_writer.writerow([
                    name_id,
                    addr,
                    bind,
                    sum(len(r_access[1]) for r_access in read_accesses),
                    '\n'.join([relevant_symbols[r_access[0]].symbol.name for r_access in read_accesses if r_access[0] in relevant_symbols]),
                    '\n'.join(';'.join([str(ra) for ra in r_access[1]]) for r_access in read_accesses),
                    sum(len(w_access[1]) for w_access in write_accesses),
                    '\n'.join([relevant_symbols[w_access[0]].symbol.name for w_access in write_accesses if w_access[0] in relevant_symbols]),
                    '\n'.join(';'.join([str(wa) for wa in w_access[1]]) for w_access in write_accesses)])
            for rs in self.elf_data.get_variables():
                write_var(csv_writer,
                            rs.symbol.name_id,
                            rs.symbol.addr,
                            rs.symbol.bind,
                            self.var_manager.var_accesses[rs.symbol.addr].read_accesses if rs.symbol.addr in self.var_manager.var_accesses else {},
                            self.var_manager.var_accesses[rs.symbol.addr].write_accesses if rs.symbol.addr in self.var_manager.var_accesses else {})
            if self.use_gen_symbols:
                for key, value in self.var_manager.var_accesses.items():
                    var_name = self.var_manager.gen_name(key)
                    if var_name:
                        write_var(csv_writer,
                                var_name,
                                key,
                                '',
                                value.read_accesses,
                                value.write_accesses)
        if self.compress_out_csv:
            if out_file:
                ASMSlicerUtils.compress_csv_file(input_file_path=out_file, remove_original=True)

    def generate_elf_info_file(self, out_elfinfo_file: str):
        logger.info("generating elfinfo report")
        if not out_elfinfo_file:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message='generating elf info report failed: missing elf file info path')
        with so.open(out_elfinfo_file, 'w', encoding='utf8') as file:
            csv_writer = csv.writer(file, quoting=csv.QUOTE_NONE)
            csv_writer.writerow(['attribute', 'value'])
            if self.elffile_info:
                csv_writer.writerows([['architecture', f'{self.elffile_info.architecture}'],
                                      ['base_address', f'{hex(self.elffile_info.base_address)}'],
                                      ['entry_address', f'{hex(self.elffile_info.entry_address)}'],
                                      ['pic', f'{"true" if self.elffile_info.is_pic else "false"}'],
                                      ['fatbin', f'{"true" if self.elffile_info.is_fatbin else "false"}'],
                                      ['dependencies', f'{self.elffile_info.dependencies}'],
                                      ['program_headers_count', f'{self.elffile_info.program_header_count}'],
                                      ['section_count', f'{self.elffile_info.section_count}'],
                                      ['symbol_count', f'{self.elffile_info.function_count + self.elffile_info.variable_count}'],
                                      ['function_count', f'{self.elffile_info.function_count}'],
                                      ['variable_count', f'{self.elffile_info.variable_count}']])
        if self.compress_out_csv:
            if out_elfinfo_file:
                ASMSlicerUtils.compress_csv_file(input_file_path=out_elfinfo_file, remove_original=True)

    @staticmethod
    def find_all_elf_function_paths(call_graph_map: dict[int, CustomElfSymbolData], function_cfg: nx.DiGraph, architecture: Architecture) -> Iterator[tuple[Segment, CustomElfSymbolData]]:
        cutoff: int = 16
        leaf_nodes: set[CustomElfBlock] = set(n for n, d in function_cfg.out_degree() if d == 0)

        def find_paths(start_node) -> Iterator[tuple[list[CustomElfBlock], CustomElfSymbolData]]:
            stack: list[tuple[CustomElfBlock, list[CustomElfBlock]]] = [(start_node, [start_node])]
            while stack:
                current_node, path = stack.pop()
                if not path:
                    raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message='Function execution path is empty')
                call_target = call_graph_map[current_node.start_addr] if current_node.start_addr in call_graph_map else None
                if call_target or current_node in leaf_nodes:
                    yield path, call_target
                    continue
                if len(path) <= cutoff:
                    for succ in function_cfg.successors(current_node):
                        if succ not in path:
                            stack.append((succ, path + [succ]))

        visited: set[CustomElfBlock] = set()
        for start_node in function_cfg.nodes:
            if start_node not in visited:
                for path, call_target in find_paths(start_node):
                    visited = visited.union(set(path))
                    segment = Segment(blocks=path, architecture=architecture)
                    if segment.is_valid():
                        yield segment, call_target

    def get_all_callees(self, entry: str, mappings: dict[UniqueMangled, set[UniqueMangled]], callees: set[str] = None) -> set[str]:
        if callees is None:
            callees: set[str] = set()
        if entry in callees:
            return callees
        callees.add(entry)
        if entry in mappings:
            for mapping in mappings[entry]:
                self.get_all_callees(mapping, mappings, callees)
        return callees

    def build_call_graph_angr(self, cfg: angr.analyses.CFG, relevant_functions: dict[int, ELFSymbol]):
        logger.info('building call graph')
        elf_call_graph: dict[UniqueMangled, set[UniqueMangled]] = {}
        if cfg:
            angr_functions: list[angr.knowledge_plugins.Function] = list(cfg.kb.functions.values())
            for elf_function in angr_functions:
                if elf_function.addr not in relevant_functions:
                    continue
                ef_call_sites = elf_function.get_call_sites()
                ef_name_id = relevant_functions[elf_function.addr].name_id
                elf_call_graph[ef_name_id] = set()
                for call_site in ef_call_sites:
                    callee_function = ElfAnalyser._get_callee_function_angr(elf_function, call_site, cfg, angr_functions)
                    callee_name_id = NON_USER_CODE_IDENTIFIER
                    if callee_function and (callee_function.addr in relevant_functions):
                        callee_name_id = relevant_functions[callee_function.addr].name_id
                    elf_call_graph[ef_name_id].add(callee_name_id)
                if ADD_EXTRA_JUMPS_TO_PLT_IN_BLOCKS:
                    # extra scan for unconditional/conditional jumps to PLT stubs in blocks
                    for block in getattr(elf_function, 'blocks', []):
                        for insn in getattr(block, 'capstone', None).insns if hasattr(block, 'capstone') and hasattr(block.capstone, 'insns') else []:
                            # only consider unconditional/conditional jumps (not calls)
                            if hasattr(insn, 'mnemonic') and insn.mnemonic in ('b', 'bl', 'b.eq', 'b.ne', 'b.lt', 'b.gt', 'b.le', 'b.ge', 'cbz', 'cbnz'):
                                if hasattr(insn, 'operands') and len(insn.operands) > 0:
                                    op = insn.operands[0]
                                    target_addr = None
                                    if hasattr(op, 'imm'):
                                        target_addr = op.imm
                                    elif hasattr(op, 'value') and hasattr(op.value, 'imm'):
                                        target_addr = op.value.imm
                                    if target_addr and target_addr in relevant_functions:
                                        plt_sym = relevant_functions[target_addr]
                                        if plt_sym.name.endswith(PLT_SUFFIX):
                                            callee_name_id = plt_sym.name_id
                                            if callee_name_id not in elf_call_graph[ef_name_id]:
                                                elf_call_graph[ef_name_id].add(callee_name_id)
                                                logger.debug(f'adding callgraph edge (JUMP->PLT): {ef_name_id} -> {callee_name_id}')
        return elf_call_graph

    def generate_callgraph_file(self, output_dotfile_path: str):
        logger.info("generating control flow graph")

        _, ext = os.path.splitext(output_dotfile_path)

        # Transport buffering parameters
        min_part_size = 16 * 1024 * 1024 # For multi-part upload
        buffer_size = 16 * 1024 * 1024 # For in-memory buffering

        if ext == '.dot':
            dotfile = None

            # For S3 transport we need to set the transport_params parameter which for local transport is not needed
            # But for local transport we need to set the buffering parameter (in-memory buffering by default)
            # smart_open also offers on-disk buffering for S3 transport - but not for local files
            # Therefore, in-memory is the common buffering mechanism

            if output_dotfile_path.startswith('s3://'):
                dotfile = so.open(output_dotfile_path, 'w', encoding='utf8', transport_params={'min_part_size': min_part_size, 'buffer_size': buffer_size})
            else:
                dotfile = so.open(output_dotfile_path, 'w', encoding='utf8', buffering=min_part_size)

            if not dotfile:
                logger.error(f'failed to open: {output_dotfile_path} for writing')
                raise ASMSlicerException(error_code=ASMSlicerError.IO_ERROR_ON_OUTPUT_FILE , message=f'failed to open: {output_dotfile_path} for writing')

            dotfile.write('digraph {\n')

            if self.elf_data.get_callgraph():
                parsed_nodes = set()
                f1_parsed_nodes = set()

                def write_to_buffer(node):
                    nonlocal parsed_nodes
                    if node not in parsed_nodes:
                        parsed_nodes.add(node)
                        dotfile.write(node + ';\n')

                def write_extra_plt(node):
                    if node.endswith(PLT_SUFFIX) and self.elf_base_name in self.deps_info:
                        name_no_plt = node.removesuffix(PLT_SUFFIX)
                        for raw_name in get_matching_symbol_names(name_no_plt):
                            container = self.deps_info[self.elf_base_name].get(raw_name, '')
                            if raw_name and container:
                                write_to_buffer(f'"{name_no_plt}"')
                                write_to_buffer(f'"{node}" -> "{name_no_plt}"')
                                break

                for f1, f2s in self.elf_data.get_callgraph().items():
                    if f1 not in f1_parsed_nodes and not ElfAnalyser.is_stub_symbol(f1):
                        f1_parsed_nodes.add(f1)
                        write_to_buffer(f'"{f1}"')
                        write_extra_plt(f1)

                        for f2 in f2s:
                            if ElfAnalyser.is_stub_symbol(f2):
                                continue
                            write_to_buffer(f'"{f2}"')
                            write_extra_plt(f2)
                            write_to_buffer(f'"{f1}" -> "{f2}"')

            dotfile.write('}')
            dotfile.close()

    @staticmethod
    def _get_callee_function_angr(ef: angr.knowledge_plugins.Function,
                             call_site_addr: int,
                             cfg: angr.analyses.CFGFast|angr.analyses.CFGEmulated,
                             functions: list[angr.knowledge_plugins.Function]) -> angr.knowledge_plugins.Function|None:
        """Get callee function if it exists in filtered functions
        :param
            ef (angr.knowledge_plugins.Function): elf caller function
            call_site_addr (int): address of call site
            cfg (angr.analyses.CFGFast | angr.analyses.CFGEmulated): control-flow graph
            functions (list[angr.knowledge_plugins.Function]): list of filtered functions that potentially returned callee function must be part of,
                                                            if None, callee function will be returned if it passes successfully the previous conditions
        :return
            angr.knowledge_plugins.Function: callee function
        """
        if not call_site_addr:
            return None
        ct = ef.get_call_target(call_site_addr)
        if not ct:
            return None
        cf = cfg.functions.get(ct)

        # if the called function is a PLT stub, try to get the actual target function
        if cf and cf.is_plt:
            plt_target = None
            for f in functions:
                if cf.name.endswith(PLT_SUFFIX) and f.name == cf.name[:-len(PLT_SUFFIX)]:
                    plt_target = f
                    break
            if plt_target:
                cf = plt_target

        if functions and cf not in functions:
            return None

        return cf

    def _should_skip_symbol(self, elf_symbol: ELFSymbol) -> bool:
        # filtering only if self.filter_functions
        if self.filter_functions:
            if not elf_symbol.addr:
                return True
            if not elf_symbol.name:
                return True
            if elf_symbol.name in ('UnresolvableJumpTarget', 'UnresolvableCallTarget'):
                return True
            if elf_symbol.demangled_name == 'main':
                return False
            if elf_symbol.visibility == 'STV_HIDDEN':
                return True
            if elf_symbol.addr <= 0:
                return True
            # if elf_symbol.addr <= self.elffile_info.entry:
            #     return True
            if elf_symbol.generated and not self.elffile_info.is_stripped:
                return True
            if elf_symbol.demangled_name.startswith(SYMBOL_PREFIXES_TO_SKIP):
                return True
            if self.elf_angr_project:
                function = self.elf_angr_project.kb.functions.get(elf_symbol.addr)
                if function:
                    if function.binary_name != self.elf_base_name:
                        return True
                    if function.is_plt:
                        return True
                    if ASMSlicerUtils.is_angr_func_alignment(function):
                        return True
        return False

    def build_function_info(self) -> Iterator[tuple[FunctionInfo, Architecture]]:
        relevant_functions = {sym.symbol.addr: sym for sym in self.elf_data.get_functions()}
        dwarf_line_entries: list[dwarf_reader.LineEntry] = self._get_dwarf_line_entries()
        dwarf_functions: list[dwarf_reader.FunctionInfo] = self._get_dwarf_functions()
        dwarf_function_entry_map: dict[int, list[int]] = self._get_dwarf_function_entry_map()
        dwarf_resolver: DWARFResolver = self._get_dwarf_resolver()
        for elf_function in relevant_functions.values():
            # build call graph map
            call_graph_map: dict[int, CustomElfSymbolData] = {}
            for call_site, callees in elf_function.call_graph.items():
                for callee in callees:
                    call_graph_map[call_site] = self.elf_data.get_function_from_address(callee)
            # build control flow map
            control_flow_graph_map: dict[int, set[CustomElfBlock]] = {}
            for caller in elf_function.control_flow_graph.nodes:
                if caller not in control_flow_graph_map:
                    control_flow_graph_map[caller] = set()
                for callee in elf_function.control_flow_graph.successors(caller):
                    target = self.elf_data.get_block(callee)
                    if target:
                        control_flow_graph_map[caller].add(target)
            yield FunctionInfo(elf_function=elf_function,
                               call_graph_map = call_graph_map,
                               control_flow_graph_map = control_flow_graph_map,
                               should_filter_functions = self.filter_functions,
                               dwarf_line_entries = dwarf_line_entries,
                               dwarf_functions = dwarf_functions,
                               dwarf_function_entry_map = dwarf_function_entry_map,
                               dwarf_resolver = dwarf_resolver), self.elffile_info.architecture

    @staticmethod
    def calc_min_max_coordinates_from_source_info(dwarf_source_info: list[DWARFAddressSourceInfo]) -> str:
        source_locations = ''
        min_max_coordinates_per_file = {}
        for dsi in dwarf_source_info:
            if dsi.source not in min_max_coordinates_per_file:
                min_max_coordinates_per_file[dsi.source] = {'min_line_from': dsi.line, 'max_line_to': dsi.line, 'num_addresses': 1}
            else:
                min_max_coordinates_per_file[dsi.source]['min_line_from'] = min(min_max_coordinates_per_file[dsi.source]['min_line_from'], dsi.line)
                min_max_coordinates_per_file[dsi.source]['max_line_to'] = max(min_max_coordinates_per_file[dsi.source]['max_line_to'], dsi.line)
                min_max_coordinates_per_file[dsi.source]['num_addresses'] += 1
        # print(f'minmax coordinates | {min_max_coordinates_per_file}')
        for filename, coordinates in min_max_coordinates_per_file.items():
            source_locations += f'{filename}:{coordinates["min_line_from"]}:{coordinates["max_line_to"]};'
        # print(f'source locations | {source_locations}')
        return source_locations

    @staticmethod
    def get_dwarf_source_info_for_addresses(addresses, line_entries, functions, function_entry_map, resolver: DWARFResolver):
        print_mismatch: bool = False
        dwarf_address_source_info: list[DWARFAddressSourceInfo] = []
        if addresses and (line_entries or resolver):
            for address in addresses:
                resolver_result = resolver.resolve(address) if resolver else None
                line_entry = dwarf_reader.find_line_entry(address=address, entries=line_entries, functions=functions, function_entry_map=function_entry_map) if line_entries else None
                if print_mismatch and resolver_result and line_entry:
                    res_file, res_addr, res_line, res_column = resolver_result
                    if res_addr != line_entry.address or res_line != line_entry.line_number or res_column != line_entry.column_number or res_file != line_entry.filename:
                        print(f'{address:08x}')
                        print(f'{res_addr:08x} {res_file}:{res_line}:{res_column}')
                        print(f'{line_entry.address:08x} {line_entry.filename}:{line_entry.line_number}:{line_entry.column_number}')
                        print()
                if resolver_result:
                    res_file, res_addr, res_line, res_column = resolver_result
                    dwarf_address_source_info.append(DWARFAddressSourceInfo(address=address, entry_address=res_addr, line=res_line, column=res_column, source=res_file))
                elif line_entry:
                    dwarf_address_source_info.append(DWARFAddressSourceInfo(address=address, entry_address=line_entry.address, line=line_entry.line_number, column=line_entry.column_number, source=line_entry.filename))
        return dwarf_address_source_info

    @staticmethod
    def build_elf_segments_per_function(function_info: FunctionInfo, architecture: Architecture) -> Iterator[str]:
        try:
            for segment, call_target in ElfAnalyser.find_all_elf_function_paths(call_graph_map=function_info.call_graph_map,
                                                                                function_cfg=function_info.elf_function.local_transition_graph,
                                                                                architecture=architecture):
                segment_asm = ASM_LINE_SEPARATOR.join(segment.instructions)
                segment_asm_addrs = ASM_LINE_SEPARATOR.join(segment.instructions_addrs)
                asm_counter = sum(1 if ';' not in addr else (int(addr.split(';')[1].strip()) + 1) for addr in segment.instructions_addrs)

                if asm_counter != len(segment.instructions):
                    raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'Segment instructions length ({len(segment.instructions)}) differentiates from calculated instructions addresses in asm block ({asm_counter}). ASM addresses: "{segment_asm_addrs}"')

                ts_short_name, ts_name_id = '', ''
                last_block_addr = int(segment.blocks[-1], 16)

                if call_target:
                    ts_name_id = call_target.symbol.name_id
                    ts_short_name = call_target.symbol.short_name
                elif last_block_addr in function_info.call_graph_map:
                    ts_short_name = NON_USER_CODE_IDENTIFIER
                    ts_name_id = NON_USER_CODE_IDENTIFIER
                function_dwarf_source_info: list[DWARFAddressSourceInfo] = ElfAnalyser.get_dwarf_source_info_for_addresses(addresses=segment.addresses, line_entries=function_info.dwarf_line_entries, functions=function_info.dwarf_functions, function_entry_map=function_info.dwarf_function_entry_map, resolver=function_info.dwarf_resolver)
                function_src_locations = ElfAnalyser.calc_min_max_coordinates_from_source_info(dwarf_source_info=function_dwarf_source_info)
                yield [segment.start_address, segment.end_address, function_info.elf_function.symbol.short_name, ts_short_name, segment_asm, segment_asm_addrs, function_info.elf_function.symbol.name_id, ts_name_id, function_src_locations, segment.loop_flags]
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'building segments per function failed: {e}') from e

    @staticmethod
    def build_elf_blocks_per_function(function_info: FunctionInfo) -> Iterator[str]:
        intervals: list[tuple[int,int]] = []
        try:
            for caller_block in function_info.elf_function.blocks.values():
                if caller_block.start_addr not in function_info.control_flow_graph_map:
                    raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'in symbol {function_info.elf_function.symbol.name} block with address {hex(caller_block.start_addr)} not in control flow graph')
                callee_blocks: set[CustomElfBlock] = function_info.control_flow_graph_map[caller_block.start_addr]
                callee_blocks_ids: str = '\n'.join(sorted(f'{callee_block.within_symbol}\t{hex(callee_block.start_addr)}' for callee_block in callee_blocks if callee_blocks))
                caller_block_asm = ''
                block_addresses: list[int] = []

                # When CFG normalization is enabled in angr, it creates separate blocks for potential jump targets.
                # A 'nop' instruction may be in its own block because angr recognizes it as a possible jump destination.
                # Therefore, we should not skip blocks containing only 'nop' instructions, even if they seem unimportant.

                for insn in caller_block.instructions:
                    if ElfInstruction.is_invalid(insn=insn):
                        continue
                    block_addresses.append(insn.address)
                    caller_block_asm += f'{insn.mnemonic} {insn.op_str}{ASM_LINE_SEPARATOR}'
                if caller_block_asm:
                    block_dwarf_source_info: list[tuple[str,int,int,int]] = ElfAnalyser.get_dwarf_source_info_for_addresses(addresses=block_addresses, line_entries=function_info.dwarf_line_entries, functions=function_info.dwarf_functions,function_entry_map=function_info.dwarf_function_entry_map, resolver=function_info.dwarf_resolver)
                    block_src_locations = ElfAnalyser.calc_min_max_coordinates_from_source_info(dwarf_source_info=block_dwarf_source_info)
                    intervals.append((caller_block.start_addr, caller_block.end_addr))
                    yield [function_info.elf_function.symbol.name_id, function_info.elf_function.symbol.demangled_name, hex(caller_block.start_addr), hex(caller_block.end_addr), caller_block_asm, callee_blocks_ids, block_src_locations]
                else:
                    logger.debug(f'skipping block from address {hex(caller_block.start_addr)} to address {hex(caller_block.end_addr)} because it does not have instructions')
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'building blocks for symbol failed: {e}') from e
        check_block_overlaps(intervals)

    def generate_segments_file(self, output_file_path: str = ''):
        logger.info('generating segments file')
        self._get_dwarf_line_entries() # just to initialize

        # Transport buffering parameters
        min_part_size = 16 * 1024 * 1024 # For multi-part upload
        buffer_size = 16 * 1024 * 1024 # For in-memory buffering

        file = None

        # For S3 transport we need to set the transport_params parameter which for local transport is not needed
        # But for local transport we need to set the buffering parameter (in-memory buffering by default)
        # smart_open also offers on-disk buffering for S3 transport - but not for local files
        # Therefore, in-memory is the common buffering mechanism

        if output_file_path.startswith('s3://'):
            file = so.open(output_file_path, 'w', encoding='utf8', transport_params={'min_part_size': min_part_size, 'buffer_size': buffer_size})
        else:
            file = so.open(output_file_path, 'w', encoding='utf8', buffering=min_part_size)

        if not file:
            logger.error(f'failed to open: {output_file_path} for writing')
            raise ASMSlicerException(error_code=ASMSlicerError.IO_ERROR_ON_OUTPUT_FILE , message=f'failed to open: {output_file_path} for writing')

        try:
            csv_writer = csv.writer(file)
            csv_writer.writerow(['r.from_addr', 'r.to_addr', 's1.name', 's2.name', 'r.asm', 'r.addrs', 's1.long_name', 's2.long_name', 'r.src_location', 'r.loop_flags'])

            with ThreadPoolExecutor(max_workers = mp.cpu_count() - 1) as executor:
                futures = [executor.submit(ElfAnalyser.build_elf_segments_per_function, fi, arch) for fi, arch in self.build_function_info()]

                for future in as_completed(futures):
                    try:
                        for row in future.result():
                            csv_writer.writerow(row)
                    except Exception as e:
                        raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'generating segments file failed: {e}') from e

            if self.compress_out_csv:
                if output_file_path:
                    file.close()
                    file = None
                    ASMSlicerUtils.compress_csv_file(input_file_path=output_file_path, remove_original=True)

        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'generating segments file failed: {e}') from e
        finally:
            if file:
                file.close()

    def generate_blocks_file(self, blocks_file_path: str = '') -> None:
        logger.info('generating blocks file')
        self._get_dwarf_line_entries() # just to initialize

        # Transport buffering parameters
        min_part_size = 16 * 1024 * 1024 # For multi-part upload
        buffer_size = 16 * 1024 * 1024 # For in-memory buffering

        file = None

        # For S3 transport we need to set the transport_params parameter which for local transport is not needed
        # But for local transport we need to set the buffering parameter (in-memory buffering by default)
        # smart_open also offers on-disk buffering for S3 transport - but not for local files
        # Therefore, in-memory is the common buffering mechanism

        if blocks_file_path.startswith('s3://'):
            file = so.open(blocks_file_path, 'w', encoding='utf8', transport_params={'min_part_size': min_part_size, 'buffer_size': buffer_size})
        else:
            file = so.open(blocks_file_path, 'w', encoding='utf8', buffering=min_part_size)

        if not file:
            logger.error(f'failed to open: {blocks_file_path} for writing')
            raise ASMSlicerException(error_code=ASMSlicerError.IO_ERROR_ON_OUTPUT_FILE , message=f'failed to open: {blocks_file_path} for writing')

        try:
            csv_writer = csv.writer(file)
            csv_writer.writerow(['s1.name', 's1.long_name', 'r.from_addr', 'r.to_addr', 'r.asm', 'db.block_ids', 'r.src_location'])

            with ThreadPoolExecutor(max_workers = mp.cpu_count() - 1) as executor:
                futures = [executor.submit(ElfAnalyser.build_elf_blocks_per_function, fi) for fi, _ in self.build_function_info()]
                for future in as_completed(futures):
                    try:
                        for row in future.result():
                            csv_writer.writerow(row)
                    except Exception as e:
                        raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'generating blocks file failed: {e}') from e

            if self.compress_out_csv:
                if blocks_file_path:
                    file.close()
                    file = None
                    ASMSlicerUtils.compress_csv_file(input_file_path=blocks_file_path, remove_original=True)

        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'generating blocks file failed: {e}') from e
        finally:
            if file:
                file.close()

    def _load_dwarf_data(self):
        if self.dwarf_line_entries is None and self.dwarf_functions is None:
            self.dwarf_line_entries = []
            self.dwarf_functions = []
            self.dwarf_function_entry_map = {}
            if dwarf_reader.DWARFReader.has_dwarf_info(self.elf_file_path):
                reader = dwarf_reader.DWARFReader(self.elf_file_path)
                self.dwarf_line_entries = reader.get_line_entries()
                self.dwarf_functions = reader.get_functions()
            for e_idx, entry in enumerate(self.dwarf_line_entries):
                for f_idx, func in enumerate(self.dwarf_functions):
                    if func.beg <= entry.address < func.end:
                        if f_idx not in self.dwarf_function_entry_map:
                            self.dwarf_function_entry_map[f_idx] = [e_idx]
                        else:
                            self.dwarf_function_entry_map[f_idx].append(e_idx)
                        break  # assuming non-overlapping functions
            logger.info('dwarf line entries: %d', len(self.dwarf_line_entries))
            logger.info('dwarf functions: %d', len(self.dwarf_functions))

    def _get_dwarf_line_entries(self):
        if not self.use_dwarf_line_ent:
            return None
        self._load_dwarf_data()
        return self.dwarf_line_entries

    def _get_dwarf_functions(self):
        if not self.use_dwarf_line_ent:
            return None
        self._load_dwarf_data()
        return self.dwarf_functions

    def _get_dwarf_function_entry_map(self):
        if not self.use_dwarf_line_ent:
            return None
        self._load_dwarf_data()
        return self.dwarf_function_entry_map

    def _get_dwarf_resolver(self):
        if not self.use_dwarf_resolver:
            return None
        if self.dwarf_resolver is None:
            self.dwarf_resolver = DWARFResolver(elffile=self.elf_file_path, arch=self.elffile_info.architecture.value, prefix_local=False, skip_optimization_variants=False)
        return self.dwarf_resolver

    def generate_dwarf_source_info(self) -> dict[str, str]:
        logger.info("generating symbol to source dwarf info")
        dwarf_line_entries: list[dwarf_reader.LineEntry] = self._get_dwarf_line_entries()
        dwarf_functions: list[dwarf_reader.FunctionInfo] = self._get_dwarf_functions()
        dwarf_function_entry_map: dict[int, list[int]] = self._get_dwarf_function_entry_map()
        dwarf_resolver: DWARFResolver = self._get_dwarf_resolver()
        symbol_to_container: dict[str, dict] = {}
        for function in self.elf_data.get_functions():
            function_addresses: set[int] = set()
            for block in function.blocks.values():
                for insn in block.instructions:
                    function_addresses.add(insn.address)
            symbol_addresses_sorted: list[int] = sorted(function_addresses)
            function_dwarf_source_info: list[tuple[str,int,int,int]] = ElfAnalyser.get_dwarf_source_info_for_addresses(addresses=symbol_addresses_sorted, line_entries=dwarf_line_entries, functions=dwarf_functions, function_entry_map=dwarf_function_entry_map, resolver=dwarf_resolver)
            function_src_locations = ElfAnalyser.calc_min_max_coordinates_from_source_info(dwarf_source_info=function_dwarf_source_info)
            symbol_to_container[function.symbol.name_id] = function_src_locations
        return symbol_to_container

    @staticmethod
    def set_up_angr_project(elf_file_path: str, elf_debug_file_path: str, architecture, is_pic: bool) -> angr.Project:
        logger.info('initializing new angr project')
        main_options = {}
        load_options = {'auto_load_libs': False}
        if is_pic:
            main_options['base_addr'] = 0
        if elf_debug_file_path:
            main_options['debug_symbols'] = elf_debug_file_path
        return angr.Project(elf_file_path, load_options=load_options, main_opts=main_options, arch=architecture if architecture else None)

    def get_all_elf_symbols(self, symbol_type: str = '', skip_symbols: bool = True) -> Iterator[ELFSymbol]:
        for sym in self.symbol_manager.elf_symbols.values():
            if not skip_symbols or not self._should_skip_symbol(elf_symbol=sym):
                if not symbol_type or sym.type == symbol_type:
                    yield sym

    def get_symbols(self, name: str, symbol_type: str = '', skip_symbols: bool = True) -> Iterator[ELFSymbol]:
        if not name:
            return
        for sym in self.get_all_elf_symbols(symbol_type=symbol_type, skip_symbols=skip_symbols):
            if sym.name == name:
                yield sym
            for alias in sym.aliases:
                if alias.name == name:
                    yield alias

    def get_jump_targets(self, insn: capstone.CsInsn, symbol: ELFSymbol, relevant_functions: dict[int, ELFSymbol], all_functions: list[int], jump_tables: dict[int, list[int]] = {}) -> list[tuple[JumpTarget, int]]:
        if ElfInstruction.is_invalid(insn=insn) or not ElfInstruction.is_jump(insn=insn, architecture=self.elffile_info.architecture):
            return [(JumpTarget.UNDEFINED, -1)]

        def _get_jump_target(addr):
            if addr and addr >= self.elffile_info.base_address:
                if symbol.addr < addr < symbol.addr + symbol.size:
                    return JumpTarget.INTRA, addr
                if addr in relevant_functions:
                    if ElfInstruction.is_conditional_jump(insn=insn, architecture=self.elffile_info.architecture) and relevant_functions[addr].name_id == symbol.name_id:
                        return JumpTarget.INTRA, addr
                    return JumpTarget.INTER, addr
                if addr in all_functions:
                    # NOTE: when filter_function is disabled, all jumps will end up being INTER (between INTER and INTER_NON_USER), since we don't skip functions
                    #       check if needed to distinguish them for train data
                    return JumpTarget.INTER_NON_USER, addr
                if [mr for mr in self.elffile_info.load_segments if mr[0] >= addr < mr[1]]:
                    return JumpTarget.INTER_UNMAPPED, addr
                return JumpTarget.EXTERNAL, addr
            if addr:
                return JumpTarget.EXTERNAL, addr
            return JumpTarget.UNRESOLVED, -1

        targets = []
        if self.elffile_info.architecture == Architecture.ARM_CORTEXM:
            if insn.mnemonic == 'mov' and 'pc' in ElfInstruction.dst_regs(insn):
                # handle jump tables
                if insn.address in jump_tables:
                    for jump_table_addr in jump_tables[insn.address]:
                        target, addr = _get_jump_target(addr=jump_table_addr)
                        targets.append((target, addr))
                    if targets:
                        return targets

        for op in insn.operands:
            if getattr(op, 'type', None) == capstone.CS_OP_IMM:
                if hasattr(op, 'imm'):
                    target = 0
                    if self.elffile_info.architecture == Architecture.TRICORE and insn.mnemonic == 'loop':
                        # capstone may resolve the immediate to an absolute address or leave it as a PC-relative offset
                        disp_us = ASMSlicerUtils.get_imm(op, as_is=False)
                        in_segment = any(s[0] <= disp_us < s[1] for s in self.elffile_info.load_segments)
                        if in_segment:
                            target = disp_us
                        else:
                            disp = ASMSlicerUtils.get_imm(op, as_is=True)
                            target = insn.address + disp
                    else:
                        target = ASMSlicerUtils.get_imm(op)
                    target, addr = _get_jump_target(addr=target)
                    targets.append((target, addr))

        if not targets:
            return [(JumpTarget.UNRESOLVED, -1)]
        
        resolved_target = min(targets, key=lambda item: (item[0].value, -item[1])) # min target, max address
        return [resolved_target]

    def gen_stub_target_symbol(self, address: int, jump_target: JumpTarget, is_rust: bool) -> CustomElfSymbolData:
        name = NON_USER_CODE_IDENTIFIER
        # TODO: Change stub symbol names depending of jump target type
        return CustomElfSymbolData(symbol=ELFSymbol(name,
                                                    name,
                                                    name,
                                                    addr=address,
                                                    size=0,
                                                    bind='',
                                                    sym_type='',
                                                    visibility=False,
                                                    associated_object='',
                                                    namespace='',
                                                    generated=False,
                                                    is_import=False,
                                                    is_rust=is_rust),
                                   blocks={},
                                   call_graph={},
                                   local_transition_graph=nx.DiGraph(),
                                   control_flow_graph=nx.DiGraph())

    @staticmethod
    def is_stub_symbol(name: str):
        return name == NON_USER_CODE_IDENTIFIER

    def fix_excluded_block_instruction(self, cfg: angr.analyses.CFGFast, elf_project: angr.Project):
        excluded_mnemonics = {"hlt", "brk"}

        css = capstone.Cs(self.elffile_info.cs_arch, self.elffile_info.cs_mode)
        css.skipdata = self.elffile_info.architecture == Architecture.ARM_CORTEXM
        css.detail = True

        text_sections = [s for s in elf_project.loader.main_object.sections if s.is_executable]
        section_bounds = [(s.vaddr, s.vaddr + s.memsize) for s in text_sections]

        def in_executable_section(addr):
            return any(start <= addr < end for start, end in section_bounds)

        addresses: set[int] = set()
        for func in cfg.kb.functions.values():
            for block in list(func.blocks):
                next_addr = block.addr + block.size
                if not in_executable_section(next_addr):
                    continue
                if any(b.addr == next_addr for b in func.blocks):
                    continue
                try:
                    # read max instruction size bytes - AArch64: 4 bytes
                    bytes_ = elf_project.loader.memory.load(next_addr, 4)
                except Exception:
                    continue
                insns = list(css.disasm(bytes_, next_addr))
                if not insns:
                    continue
                insn = insns[0]
                if insn.mnemonic in excluded_mnemonics:
                    new_size = block.size + insn.size
                    try:
                        new_block = elf_project.factory.block(block.addr, size=new_size)
                    except Exception:
                        continue
                    # pylint: disable=protected-access
                    if hasattr(func, '_local_blocks') and block.addr in func._local_blocks:
                        func._local_blocks[block.addr] = new_block
                    if hasattr(func, '_block_cache'):
                        func._block_cache[block.addr] = new_block
                    addresses.add(block.addr)
                    logger.debug(f"patched block {block.addr:#x} to include {insn.mnemonic} at {insn.address:#x}")
        logger.info(f"patched blocks with excluded block instruction: {len(addresses)}")

    @staticmethod
    def merge_veneer_functions(cfg: angr.analyses.CFGFast, architecture: Architecture):
        """
        Merge veneer functions (e.g., stack protector loaders) back into their parent functions.
        
        A veneer function is identified by:
        - Has exactly one basic block
        - Has exactly one incoming edge (from a single call site)
        - The block ends with an unconditional branch to an address within the calling function
        - The target address is right after the call instruction in the calling function
        
        When found, the veneer function block is appended to the calling function and the helper
        function is deleted from the CFG.
        """
        
        def _is_veneer(func: angr.knowledge_plugins.Function) -> bool:
            blocks = list(func.blocks)
            if len(blocks) != 1:
                return False
            block = blocks[0]
            if not block.capstone or not block.capstone.insns:
                return False
            insns = list(block.capstone.insns)
            if not insns:
                return False
            last_insn = insns[-1]
            if ElfInstruction.is_return(last_insn, architecture):
                return False
            if ElfInstruction.is_conditional_jump(last_insn, architecture):
                return False
            return ElfInstruction.is_unconditional_jump(last_insn, architecture)
        
        def _get_branch_target(block: angr.block.Block) -> int | None:
            if not block.capstone or not block.capstone.insns:
                return None
            insns = list(block.capstone.insns)
            if not insns:
                return None
            last_insn = insns[-1]
            if hasattr(last_insn, 'operands') and last_insn.operands:
                for op in last_insn.operands:
                    if hasattr(op, 'type') and op.type == capstone.CS_OP_IMM:
                        if hasattr(op, 'imm'):
                            target = op.imm
                            if target < 0:
                                target = ASMSlicerUtils.convert_twos_complement(target)
                            return target
            return None
        
        def _is_valid_merge_target(calling_func: angr.knowledge_plugins.Function, branch_target: int) -> bool:
            calling_func_blocks = list(calling_func.blocks)
            calling_func_end = max((b.addr + b.size) for b in calling_func_blocks) if calling_func_blocks else 0
            return calling_func.addr <= branch_target < calling_func_end

        func_index = {}
        succ_cache = {}

        for func_addr, func in cfg.kb.functions.items():
            func_blocks = list(func.blocks)
            func_index[func_addr] = (func, func_blocks)
            for block in func_blocks:
                cfg_node = cfg.model.get_any_node(block.addr)
                if cfg_node:
                    succ_cache[block.addr] = list(cfg_node.successors)

        callers_map = defaultdict(list)

        for caller_func_addr, (caller_func, caller_blocks) in func_index.items():
            for block in caller_blocks:
                block_addr = block.addr
                if block_addr in succ_cache:
                    for succ_node in succ_cache[block_addr]:
                        callers_map[succ_node.addr].append((block_addr, caller_func_addr, caller_func))

        helpers_to_merge = []
        
        for func_addr, (func, func_blocks) in func_index.items():
            if func.is_plt or func.is_alignment:
                continue
            if not _is_veneer(func):
                continue

            helper_first_block_addr = func_blocks[0].addr if func_blocks else 0
            callers = callers_map.get(func_addr, []) + callers_map.get(helper_first_block_addr, [])

            calling_func_addr = 0
            if len(set(c[1] for c in callers)) == 1:
                calling_func_addr = callers[0][1]

            if calling_func_addr <= 0:
                continue

            calling_func = cfg.kb.functions.get(calling_func_addr)
            if not calling_func:
                continue

            helper_block = func_blocks[0]
            branch_target = _get_branch_target(helper_block)
            if branch_target is None:
                continue
            if not _is_valid_merge_target(calling_func, branch_target):
                continue
            helpers_to_merge.append((func.addr, calling_func_addr, helper_block, branch_target))

        if not helpers_to_merge:
            return
        
        merged_count = 0
        logger.debug(f"Veneer function candidates: {len(helpers_to_merge)}")
        
        for helper_func_addr, calling_func_addr, helper_block, branch_target in helpers_to_merge:
            if helper_func_addr not in cfg.kb.functions or calling_func_addr not in cfg.kb.functions:
                logger.warning(f"Helper {helper_func_addr:#x} or calling func {calling_func_addr:#x} no longer in CFG")
                continue

            helper_func = cfg.kb.functions[helper_func_addr]
            calling_func = cfg.kb.functions[calling_func_addr]
            
            try:
                if helper_block.addr not in calling_func.block_addrs_set:
                    block_node = BlockNode(helper_block.addr, helper_block.size)
                    calling_func._register_node(True, block_node)  # pylint: disable=protected-access
                
                cfg_helper_node = cfg.model.get_any_node(helper_block.addr)
                if cfg_helper_node:
                    for func in cfg.kb.functions.values():
                        for block in list(func.blocks):
                            cfg_block_node = cfg.model.get_any_node(block.addr)
                            if not cfg_block_node:
                                continue
                            for succ in cfg_block_node.successors:
                                if succ.addr == helper_func_addr:
                                    if func.addr == calling_func_addr and calling_func.transition_graph.has_edge(block.addr, helper_func_addr):
                                        calling_func.transition_graph.remove_edge(block.addr, helper_func_addr)
                                        calling_func.transition_graph.add_edge(block.addr, helper_block.addr)
                    
                    for succ in cfg_helper_node.successors:
                        target_addr = succ.addr
                        if target_addr in calling_func.block_addrs_set:
                            if calling_func.transition_graph.has_node(helper_block.addr) and not calling_func.transition_graph.has_edge(helper_block.addr, target_addr):
                                calling_func.transition_graph.add_edge(helper_block.addr, target_addr)
                else:
                    logger.warning(f"CFG node not found for helper block {helper_block.addr:#x}")
                
                if helper_func_addr in cfg.kb.functions:
                    del cfg.kb.functions[helper_func_addr]
                    merged_count += 1
                    logger.debug(f"Merged veneer {helper_func_addr:#x} ({helper_func.name}) into {calling_func_addr:#x} ({calling_func.name})")

            except Exception as e:
                logger.warning(f"Failed to merge veneer {helper_func_addr:#x} into {calling_func_addr:#x}: {e}", exc_info=True)
        
        if merged_count == len(helpers_to_merge):
            logger.info(f"Merged {merged_count} veneer functions")
        else:
            logger.info(f"Merged {merged_count} of {len(helpers_to_merge)} veneer functions")

    @staticmethod
    def rewire_cfg(cfg: angr.analyses.CFGFast):
        """
        Rewires an angr CFG by merging incorrectly identified functions (e.g., 'sub_...')
        into their correct parent functions based on ELF symbol information.

        This uses a robust, block-centric approach to handle cases where a single
        angr-identified function contains blocks from multiple real functions.

        Args:
            cfg: The CFGFast analysis result to be modified in-place.
        """

        # Find blocks that do not belong to their parent function based on ELF symbols address ranges
        orphaned_blocks = set()
        for func in cfg.kb.functions.values():
            if func.is_plt:
                continue
            symbol = func.symbol
            if not symbol:
                orphaned_blocks.update({(block, func.addr) for block in func.blocks})
                continue
            if symbol.is_import:
                continue

            # determine symbol start and a robust size to avoid treating valid blocks
            # as orphan when the symbol size reported by angr/cle is zero
            sym_start = getattr(symbol, 'linked_addr', getattr(symbol, 'addr', func.addr))
            sym_size = getattr(symbol, 'size', 0)

            if sym_size == 0:
                sym_size = getattr(func, 'size', 0)

            if sym_size == 0:
                max_end = max((b.addr + b.size) for b in func.blocks) if func.blocks else 0
                sym_size = max(0, max_end - sym_start)

            if sym_size > 0:
                for block in func.blocks:
                    if sym_start <= block.addr < sym_start + sym_size:
                        continue
                    orphaned_blocks.add((block, func.addr))

        # Find new parent function for the orphaned blocks based on ELF symbols address ranges
        adopted_blocks = set()
        currently_adopted_blocks = set()
        for func in cfg.kb.functions.values():
            symbol = func.symbol
            if not symbol:
                continue
            for block, old_parent_addr in orphaned_blocks:
                if symbol.linked_addr <= block.addr < symbol.linked_addr + symbol.size:
                    adopted_blocks.add((block, old_parent_addr, func.addr))
                    currently_adopted_blocks.add((block, old_parent_addr))
            orphaned_blocks -= currently_adopted_blocks
            currently_adopted_blocks.clear()

        # Remove remaining orphaned blocks from their old parent functions
        for block, old_parent_addr in orphaned_blocks:
            del cfg.kb.functions[old_parent_addr]._local_blocks[block.addr]  # pylint: disable=protected-access

        reparented_blocks = set()
        modified_functions = set()

        for block, old_func_addr, new_func_addr in adopted_blocks:
            if old_func_addr not in cfg.kb.functions:
                logger.warning(f"Rewire: Old function {old_func_addr:#x} for block {block.addr:#x} not in CFG. Skipping move.")
                continue
            if new_func_addr not in cfg.kb.functions:
                logger.warning(f"Rewire: New function {new_func_addr:#x} for block {block.addr:#x} not in CFG. Skipping move.")
                continue

            old_func = cfg.kb.functions[old_func_addr]
            new_func = cfg.kb.functions[new_func_addr]

            if block.addr in old_func.block_addrs_set:
                old_func.block_addrs_set.remove(block.addr)
                if old_func.transition_graph.has_node(block.addr):
                    old_func.transition_graph.remove_node(block.addr)
                if block.addr in old_func._local_blocks: # pylint: disable=protected-access
                    del old_func._local_blocks[block.addr] # pylint: disable=protected-access
                modified_functions.add(old_func_addr)

            if block.addr not in new_func.block_addrs_set:
                block_node = BlockNode(block.addr, block.size)
                new_func._register_node(True, block_node) # pylint: disable=protected-access
                reparented_blocks.add(block.addr)
                modified_functions.add(new_func_addr)

                cfg_node = cfg.model.get_any_node(block.addr)
                if cfg_node:
                    cfg_node.function_address = new_func_addr
                    for succ in cfg_node.successors:
                        if succ.addr in new_func.block_addrs_set:
                            new_func.transition_graph.add_edge(block.addr, succ.addr)
                    for pred in cfg_node.predecessors:
                        if pred.addr in new_func.block_addrs_set:
                            new_func.transition_graph.add_edge(pred.addr, block.addr)

        for func_addr in modified_functions:
            if func_addr in cfg.kb.functions:
                func = cfg.kb.functions[func_addr]
                try:
                    func.normalize()
                except Exception as e:
                    logger.warning(f"Failed to normalize function at {func_addr:#x}: {e}")

        intervals: list[tuple[int,int]] = []
        for func in cfg.kb.functions.values():
            for block in func.blocks:
                intervals.append((block.addr, block.addr + block.size))
        check_block_overlaps(intervals)

        logger.info(f"CFG rewiring: reparented blocks: {len(reparented_blocks)} into {len(modified_functions)} functions")
        logger.info(f"CFG rewiring: removed orphaned blocks: {len(orphaned_blocks)}")

    def build_elf_data_angr(self, elf_angr_project: angr.Project | None) -> CustomElfData:
        logger.info(f'building angr elf data for {self.elf_file_path}')

        # Note: When changing parameters that affect creation of ControlFlowGraph, always remember to
        #       update utility.generate_cfg_filename function, so that the pickled CFGs are keeping
        #       their correctness where used.
        cfg = None
        custom_elf_data: CustomElfData = CustomElfData(functions=[], variables=[], call_graph={})

        def init_cfg_project(cfg: angr.analyses.CFGFast):
            if not cfg:
                return
            for function in cfg.kb.functions.values():
                ###########################
                # Dirty BugFix.
                ###########################
                # From angr's Function::__init__ function.
                # "self._project: Project | None = None  # will be initialized upon the first access to self.project"
                # We need to call project for each function so that the _project gets correctly initialized.
                function.project # pylint: disable=pointless-statement

        if elf_angr_project:
            # get all relevant functions and variables from elf
            all_functions = list(sym.addr for sym in self.get_all_elf_symbols(symbol_type='STT_FUNC', skip_symbols=False))
            relevant_functions: dict[int, ELFSymbol] = {sym.addr: sym for sym in self.get_all_elf_symbols(symbol_type='STT_FUNC')}
            relevant_variables = list(self.get_all_elf_symbols(symbol_type='STT_OBJECT'))
            jump_target_to_addrs: dict[JumpTarget, set[int]] = {}

            pregenerated_cfg_failed = False
            if au.Path.is_file(self.cfg_file) and not self.dump_cfg:
                logger.info(f'using pregenerated cfg "{self.cfg_file}" for elf {self.elf_base_name}.')
                cfg = utility.load_from_pickle(self.cfg_file, logger=logger)
                if not cfg:
                    logger.warning("failed loading pregenerated control-flow graph")
                    pregenerated_cfg_failed = True
                init_cfg_project(cfg)

            if not cfg:
                cfg = elf_angr_project.analyses.CFGFast(
                    force_complete_scan=True,  # we want to analyze all executable code
                    force_smart_scan=False,  # do not use heuristics to stop scaning - we want to analyze all executable code
                    exclude_sparse_regions=False,  # do not exclude any regions - we want to analyze all executable code
                    data_references=False,  # avoid stopping the processing of CFG for a function when unmapped memory is accessed
                    normalize=True,  # use block normalization to avoid overlapping blocks i.e. jump formed blocks
                    detect_tail_calls=True,  # use more agressive tail call detection algorithm
                    jumptable_resolver_resolves_calls=True,  # for consistency, this is the default for binaries <50KB
                    indirect_calls_always_return=True,  # for consistency, this is the default for binaries >=50KB
                    skip_unmapped_addrs=True,  # for clarity, this is the default - avoid stopping the processing of CFG for a function when flow jumps to unmapped memory
                    function_prologues=True,  # for clarity, this is the default for everything other than .NET
                    show_progressbar=True,
                )
                if self.dump_cfg or pregenerated_cfg_failed:
                    utility.pickle_and_dump(self.cfg_file, cfg)
                    logger.info(f'dumped cfg "{self.cfg_file}"')

            if cfg:
                self.fix_excluded_block_instruction(cfg, elf_angr_project)
                ElfAnalyser.rewire_cfg(cfg)
                ElfAnalyser.merge_veneer_functions(cfg, architecture=self.elffile_info.architecture)

                # whether to keep functions with no blocks
                keep_empty_functions: bool = True

                # get functions detected by angr
                angr_functions: list[angr.knowledge_plugins.Function] = sorted(cfg.kb.functions.values(), key=lambda f: f.addr)
                
                if self.out_asm_file:
                    with so.open(self.out_asm_file, 'w', encoding='utf-8') as asm_file:
                        duplicates = set()
                        seen_insns = set()
                        for function in angr_functions:
                            if function.addr in relevant_functions:
                                function_name = relevant_functions[function.addr].name
                            else:
                                function_name = function.name
                            asm_file.write(f'\n{function.addr:08x} <{function_name}>:\n')
                            sorted_blocks = sorted(function.blocks, key=lambda b: b.addr)
                            for block in sorted_blocks:
                                for insn in block.capstone.insns:
                                    if insn.address in seen_insns:
                                        duplicates.add(insn.address)
                                    seen_insns.add(insn.address)
                                    asm_file.write(f'{insn.address:8x}:  {insn.mnemonic} {insn.op_str}\n')
                        for duplicate in sorted(duplicates):
                            logger.warning(f'duplicate: {duplicate:x}')
                        if duplicates:
                            logger.warning(f'asm duplicate addresses: {len(duplicates)}')

                # consider generated symbols
                if self.use_gen_symbols:
                    original_function_ranges = [(sym.addr, sym.addr + sym.size) for _, sym in relevant_functions.items()]
                    generated_function_ranges = []
                    generated_functions = []
                    generated_function_symbols = set()

                    def _overlaps(range1, range2):
                        beg1, end1 = range1
                        beg2, end2 = range2
                        return beg1 < end2 and beg2 < end1

                    is_rust = utility.is_rust_elf(self.elf)
                    for function in angr_functions:
                        # Check if the generated symbol overlaps with any original symbol
                        gen_sym_range = (function.addr, function.addr + function.size)
                        if any(_overlaps(gen_sym_range, original) for original in original_function_ranges):
                            continue

                        demangled = self.symbol_manager.get_demangled_name(function.name)
                        _, _, short_name = utility.extract_symbol_simple_name(demangled)
                        gen_sym = ELFSymbol(function.name,
                                            short_name,
                                            demangled,
                                            function.addr,
                                            function.size,
                                            '',
                                            '',
                                            '',
                                            '',
                                            '',
                                            True,
                                            False,
                                            is_rust)

                        if not self._should_skip_symbol(elf_symbol=gen_sym):
                            name = self.symbol_manager.get_prefixed_symbol_name(function.name)
                            gen_sym.name = name
                            gen_sym.short_name = name
                            gen_sym.demangled_name = name
                            gen_sym.name_id = name

                            # Check if the generated symbol overlaps with any generated symbol
                            # if it does merge their ranges and keep the one that starts first
                            merged = False
                            for i, existing_range in enumerate(generated_function_ranges):
                                if _overlaps(gen_sym_range, existing_range):
                                    beg1, end1 = existing_range
                                    beg2, end2 = gen_sym_range
                                    new_beg = min(beg1, beg2)
                                    new_end = max(end1, end2)
                                    generated_function_ranges[i] = (new_beg, new_end)
                                    new_gen_sym = generated_functions[i] if beg1 <= beg2 else gen_sym
                                    new_gen_sym.addr = new_beg
                                    new_gen_sym.size = new_end - new_beg
                                    generated_functions[i] = new_gen_sym
                                    merged = True
                                    break
                            if merged:
                                continue

                            generated_functions.append(gen_sym)
                            generated_function_ranges.append(gen_sym_range)
                    generated_functions_by_addr = {x.addr: x for x in generated_functions}
                    relevant_functions.update(generated_functions_by_addr)
                    generated_function_symbols = set(generated_functions_by_addr.keys())

                # process relevant symbols
                for _, relevant_symbol in relevant_functions.items():
                    if relevant_symbol.type == 'STT_FUNC' or self.use_gen_symbols:
                        if self.use_gen_symbols and relevant_symbol.addr in generated_function_symbols and not cfg.kb.functions.contains_addr(relevant_symbol.addr):
                            angr_function_key = relevant_symbol.name
                        else:
                            angr_function_key = relevant_symbol.addr
                        angr_function: angr.knowledge_plugins.Function = cfg.kb.functions.get(angr_function_key)
                        if not angr_function:
                            # forceful generation and import of relevant function
                            func = angr.knowledge_plugins.functions.Function(
                                cfg.kb.functions,
                                addr=relevant_symbol.addr,
                                name=relevant_symbol.name,
                                binary_name=elf_angr_project.filename,
                                is_plt=False)
                            cfg.kb.functions._function_map[relevant_symbol.addr] = func # pylint: disable=protected-access
                            angr_function = cfg.kb.functions.get(angr_function_key)

                        if angr_function:

                            if angr_function.size != relevant_symbol.size:
                                logger.debug(f'size mismatch. function: {relevant_symbol.name_id}. elf_size: {relevant_symbol.size}. angr_size: {angr_function.size}')

                            custom_elf_symbol_data: CustomElfSymbolData = CustomElfSymbolData(symbol=relevant_symbol,
                                                                                              blocks={},
                                                                                              call_graph={},
                                                                                              local_transition_graph=nx.DiGraph(),
                                                                                              control_flow_graph=nx.DiGraph())

                            for bl in angr_function.blocks:
                                current_block = CustomElfBlock(start_addr=bl.addr,
                                                               end_addr=bl.addr + bl.size,
                                                               size=bl.size,
                                                               is_natural=True,
                                                               instructions=bl.capstone.insns,
                                                               within_symbol=relevant_symbol.name_id)
                                custom_elf_symbol_data.blocks[current_block.start_addr] = current_block

                            # create call sites and create control flow graph entries for jumps outside the symbol
                            for call_site in angr_function.get_call_sites():
                                callee_function = ElfAnalyser._get_callee_function_angr(angr_function, call_site, cfg, angr_functions)
                                if callee_function:
                                    if call_site not in custom_elf_symbol_data.call_graph:
                                        custom_elf_symbol_data.call_graph[call_site] = set()
                                    custom_elf_symbol_data.call_graph[call_site].add(callee_function.addr)
                                    custom_elf_symbol_data.control_flow_graph.add_edge(call_site, callee_function.addr)

                            # build local transition graph and control flow graph - angr block to custom block mapping
                            for nd in angr_function.graph.nodes:
                                if nd.addr in custom_elf_symbol_data.blocks:
                                    cb_from = custom_elf_symbol_data.blocks[nd.addr]
                                    custom_elf_symbol_data.local_transition_graph.add_node(cb_from)
                                    custom_elf_symbol_data.control_flow_graph.add_node(cb_from.start_addr)
                                    for succ in angr_function.graph.successors(nd):
                                        if succ.addr in custom_elf_symbol_data.blocks:
                                            cb_to = custom_elf_symbol_data.blocks[succ.addr]
                                            custom_elf_symbol_data.local_transition_graph.add_edge(cb_from, cb_to)
                                            custom_elf_symbol_data.control_flow_graph.add_edge(cb_from.start_addr, cb_to.start_addr)

                                    # add missing unconditional branch edges
                                    # check last instruction for unconditional branch (eg, 'b' on ARM)
                                    last_insn = cb_from.instructions[-1] if cb_from.instructions else None

                                    if ElfInstruction.is_invalid(insn=last_insn):
                                        continue

                                    if last_insn and ElfInstruction.is_jump(insn=last_insn, architecture=self.elffile_info.architecture):
                                        if cb_from.start_addr not in custom_elf_symbol_data.call_graph:
                                            custom_elf_symbol_data.call_graph[cb_from.start_addr] = set()
                                        if not ElfInstruction.is_return(insn=last_insn, architecture=self.elffile_info.architecture):
                                            for target, target_addr in self.get_jump_targets(insn=last_insn, symbol=relevant_symbol, relevant_functions=relevant_functions, all_functions=all_functions):
                                                if BYPASS_PLT_TARGETS and target_addr in relevant_functions and relevant_functions[target_addr].name.endswith(PLT_SUFFIX):
                                                    plt_target_name = relevant_functions[target_addr].name.removesuffix(PLT_SUFFIX)
                                                    for addr, func in relevant_functions.items():
                                                        if func.name == plt_target_name:
                                                            target = JumpTarget.INTER
                                                            target_addr = addr
                                                            break

                                                if target == JumpTarget.UNDEFINED:
                                                    raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'jump instruction: {last_insn.mnemonic} {last_insn.op_str} has undefined target')
                                                elif target == JumpTarget.INTRA:
                                                    if target_addr not in custom_elf_symbol_data.blocks:
                                                        # disassembly of the symbol likely stopped due to undefined instructions, attempt to forcibly create a block at the target address
                                                        try:
                                                            block = self.elf_angr_project.factory.block(target_addr, opt_level=0)
                                                        except Exception as e:
                                                            logger.warning(f"Failed to lift block at {target_addr:#x}: {e}")
                                                            continue

                                                        if block.size == 0:
                                                            logger.warning(f"Zero-sized block at {target_addr:#x} — likely garbage or undefined.")
                                                            continue

                                                        if block.addr != target_addr:
                                                            logger.warning(f"Generated block address {block.addr:#x} different from target address {target_addr:#x}.")
                                                            continue

                                                        blocks_to_remove = []
                                                        new_beg = block.addr
                                                        new_end = block.addr + block.size
                                                        adj_end = new_end
                                                        for b in custom_elf_symbol_data.blocks.values():
                                                            b_beg = b.start_addr
                                                            b_end = b.end_addr
                                                            if b_beg > new_beg and b_end < new_end:
                                                                blocks_to_remove.append(b.start_addr)
                                                            if new_beg < b_beg < new_end:
                                                                adj_end = min(adj_end, b_end)

                                                        if adj_end != new_end:
                                                            try:
                                                                block = self.elf_angr_project.factory.block(target_addr, opt_level=0, size=adj_end - target_addr)
                                                            except Exception as e:
                                                                logger.warning(f"Failed to lift adjusted block at {target_addr:#x}-{adj_end:#x}: {e}")
                                                                continue

                                                        for block_beg in blocks_to_remove:
                                                            del custom_elf_symbol_data.blocks[block_beg]

                                                        custom_block = CustomElfBlock(start_addr=block.addr,
                                                                                    end_addr=block.addr + block.size,
                                                                                    size=block.size,
                                                                                    is_natural=True,
                                                                                    instructions=block.capstone.insns,
                                                                                    within_symbol=relevant_symbol.name_id)

                                                        custom_elf_symbol_data.blocks[block.addr] = custom_block

                                                    cb_to = custom_elf_symbol_data.blocks[target_addr]
                                                    custom_elf_symbol_data.local_transition_graph.add_edge(cb_from, cb_to)
                                                    custom_elf_symbol_data.control_flow_graph.add_edge(cb_from.start_addr, cb_to.start_addr)
                                                elif target in [JumpTarget.INTER, JumpTarget.INTER_NON_USER, JumpTarget.INTER_UNMAPPED, JumpTarget.EXTERNAL]:
                                                    if target == JumpTarget.INTER and (target_addr not in relevant_functions):
                                                        raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'External target address {hex(target_addr)} missing from function dataset')
                                                    target_name = relevant_functions[target_addr].name_id if target == JumpTarget.INTER else NON_USER_CODE_IDENTIFIER
                                                    custom_elf_symbol_data.control_flow_graph.add_edge(cb_from.start_addr, target_addr)
                                                    # record as a call site
                                                    custom_elf_symbol_data.call_graph[cb_from.start_addr].add(target_addr)
                                                    if relevant_symbol.name_id not in custom_elf_data.call_graph:
                                                        custom_elf_data.call_graph[relevant_symbol.name_id] = set()
                                                    custom_elf_data.call_graph[relevant_symbol.name_id].add(target_name)
                                                    if target != JumpTarget.INTER:
                                                        if target not in jump_target_to_addrs:
                                                            jump_target_to_addrs[target] = set()
                                                        jump_target_to_addrs[target].add(target_addr)
                                                elif target == JumpTarget.UNRESOLVED:
                                                    custom_elf_symbol_data.call_graph[cb_from.start_addr].add(target_addr)
                                                    if relevant_symbol.name_id not in custom_elf_data.call_graph:
                                                        custom_elf_data.call_graph[relevant_symbol.name_id] = set()
                                                    custom_elf_data.call_graph[relevant_symbol.name_id].add(NON_USER_CODE_IDENTIFIER)
                                                    custom_elf_symbol_data.control_flow_graph.add_edge(cb_from.start_addr, target_addr)
                                                    if target not in jump_target_to_addrs:
                                                        jump_target_to_addrs[target] = set()
                                                    jump_target_to_addrs[target].add(target_addr)

                            # add fallthrough blocks for blocks that do not end with a jump or return
                            sorted_blocks = sorted(custom_elf_symbol_data.blocks.values(), key=lambda b: b.start_addr)
                            for i, cb_from in enumerate(sorted_blocks[:-1]):
                                last_insn = cb_from.instructions[-1] if cb_from.instructions else None
                                if last_insn \
                                    and not ElfInstruction.is_unconditional_jump(last_insn, architecture=self.elffile_info.architecture) \
                                    and not ElfInstruction.is_return(last_insn, architecture=self.elffile_info.architecture):
                                    cb_to = sorted_blocks[i + 1]
                                    # only add the block if it doesn't already exist
                                    if not custom_elf_symbol_data.local_transition_graph.has_edge(cb_from, cb_to):
                                        custom_elf_symbol_data.local_transition_graph.add_edge(cb_from, cb_to)
                                    if not custom_elf_symbol_data.control_flow_graph.has_edge(cb_from.start_addr, cb_to.start_addr):
                                        custom_elf_symbol_data.control_flow_graph.add_edge(cb_from.start_addr, cb_to.start_addr)

                            if keep_empty_functions or custom_elf_symbol_data.blocks:
                                # add function
                                custom_elf_data.functions.append(custom_elf_symbol_data)

                # add stub objects
                is_rust = utility.is_rust_elf(self.elf)
                for target, addrs in jump_target_to_addrs.items():
                    for addr in addrs:
                        custom_elf_data.functions.append(self.gen_stub_target_symbol(address=addr, jump_target=target, is_rust=is_rust))

                # process relevant variables
                for relevant_variable in relevant_variables:
                    custom_elf_symbol_data: CustomElfSymbolData = CustomElfSymbolData(symbol=relevant_variable,
                                                                                      blocks={},
                                                                                      call_graph={},
                                                                                      local_transition_graph=nx.DiGraph(),
                                                                                      control_flow_graph=nx.DiGraph())
                    custom_elf_data.variables.append(custom_elf_symbol_data)

                # generate elf data statistics
                len_relevant_functions = sum(1 for _, f in relevant_functions.items() if not self.is_stub_symbol(f.name))
                custom_elf_data_statistics: CustomElfDataStatistics = CustomElfDataStatistics(total_functions = self.elffile_info.function_count if not self.use_gen_symbols else len_relevant_functions,
                                                                                             total_variables = self.elffile_info.variable_count if not self.use_gen_symbols else len(relevant_variables),
                                                                                             total_relevant_functions = len_relevant_functions,
                                                                                             total_relevant_variables = len(relevant_variables),
                                                                                             total_processed_functions = sum(1 for f in custom_elf_data.functions if not self.is_stub_symbol(f.symbol.name)),
                                                                                             total_processed_variables = len(custom_elf_data.variables))
                custom_elf_data.statistics = custom_elf_data_statistics

                # create elf call graph
                custom_elf_data.call_graph = self.build_call_graph_angr(cfg=cfg, relevant_functions=relevant_functions)

        cfg = None
        return custom_elf_data

    @staticmethod
    def is_block_alignment(instructions: list[capstone.CsInsn], architecture: Architecture) -> bool:
        for insn in instructions:
            if ElfInstruction.is_invalid(insn):
                continue
            if not ElfInstruction.is_nop(insn, architecture):
                return False
        return True

    @staticmethod
    def get_block_size(block_instructions: list[capstone.CsInsn]) -> int:
        if block_instructions:
            start_addr = block_instructions[0].address
            end_addr = block_instructions[-1].address + block_instructions[-1].size
            return end_addr - start_addr
        return 0

    def build_elf_data_capstone(self) -> CustomElfData:
        logger.info(f'building custom elf data for {self.elf_file_path}')

        use_block_splitting: bool = True

        all_functions: list[int] = [sym.addr for sym in sorted(list(self.get_all_elf_symbols(symbol_type='STT_FUNC', skip_symbols=False)), key=lambda x: x.addr)]
        relevant_functions: dict[int, ELFSymbol] = {sym.addr: sym for sym in sorted(list(self.get_all_elf_symbols(symbol_type='STT_FUNC')), key=lambda x: x.addr)}
        relevant_variables: dict[int, ELFSymbol] = {sym.addr: sym for sym in sorted(list(self.get_all_elf_symbols(symbol_type='STT_OBJECT')), key=lambda x: x.addr)}
        asm_per_symbol: dict[ELFSymbol, ElfDisassembler.Asm] = ElfDisassembler.disassemble(elf_file=self.elf, elffile_info=self.elffile_info, relevant_symbols=relevant_functions, out_asm_file=self.out_asm_file)
        custom_elf_data: CustomElfData = CustomElfData(functions=[], variables=[], call_graph={})
        symbol_to_branching: dict[ELFSymbol, set[int]] = {}
        symbol_to_blocks: dict[ELFSymbol, list[CustomElfBlock]] = {}
        jump_formed_blocks: dict[ELFSymbol, set[int]] = {}
        jump_target_to_addrs: dict[JumpTarget, set[int]] = {}
        
        if use_block_splitting:
            # get symbol branching addresses
            natural_blocks: set[int] = set()
            removed_alignment_blocks = 0
            for symbol, asm in asm_per_symbol.items():
                symbol_to_branching[symbol] = set()
                block_instructions: list[capstone.CsInsn] = []
                last_block_info = (None, None, None, None)
                insns = asm.instructions
                for last_insn in insns:
                    if ElfInstruction.is_data_sequence(insn=last_insn):
                        if block_instructions:
                            is_alignment = ElfAnalyser.is_block_alignment(block_instructions, self.elffile_info.architecture)
                            last_block_info = (is_alignment, block_instructions[0].address, None, None)
                            natural_blocks.add(block_instructions[0].address)
                            block_instructions = []
                        continue
                    if ElfInstruction.is_invalid(insn=last_insn):
                        continue
                    block_instructions.append(last_insn)
                    if (ElfInstruction.is_jump(insn=last_insn, architecture=self.elffile_info.architecture) or ElfInstruction.is_return(insn=last_insn, architecture=self.elffile_info.architecture)):
                        symbol_to_branching[symbol].add(last_insn.address)
                        for target, target_addr in self.get_jump_targets(insn=last_insn, symbol=symbol, relevant_functions=relevant_functions, all_functions=all_functions, jump_tables=asm.jump_tables):
                            if target == JumpTarget.INTRA:
                                for i, insn in enumerate(insns):
                                    if insn.address == target_addr:
                                        if (i - 1) >= 0:
                                            symbol_to_branching[symbol].add(insns[i - 1].address)
                        is_alignment = ElfAnalyser.is_block_alignment(block_instructions, self.elffile_info.architecture)
                        last_block_info = (is_alignment, block_instructions[0].address, None, None)
                        natural_blocks.add(block_instructions[0].address)
                        block_instructions = []
                if block_instructions and block_instructions[-1].address not in symbol_to_branching[symbol]:
                    is_alignment = ElfAnalyser.is_block_alignment(block_instructions, self.elffile_info.architecture)
                    last_block_info = (is_alignment, block_instructions[0].address, symbol, block_instructions[-1].address)
                    symbol_to_branching[symbol].add(block_instructions[-1].address)
                    natural_blocks.add(block_instructions[0].address)
                    block_instructions = []
                # if the last block in a function is alignement or all nop's, remove it
                if last_block_info[0]:
                    removed_alignment_blocks += 1
                    natural_blocks.remove(last_block_info[1])
                    if last_block_info[2]:
                        symbol_to_branching[last_block_info[2]].remove(last_block_info[3])
            if removed_alignment_blocks:
                logger.info(f'removed alignment blocks: {removed_alignment_blocks}')

            # build all blocks
            for symbol, asm in asm_per_symbol.items():
                symbol_to_blocks[symbol] = []
                block_instructions: list[capstone.CsInsn] = []
                for last_insn in asm.instructions:
                    invalid_insn = ElfInstruction.is_invalid(insn=last_insn)
                    if not invalid_insn:
                        block_instructions.append(last_insn)
                    if (last_insn.address in symbol_to_branching[symbol]) or invalid_insn:
                        if block_instructions:
                            block_size = ElfAnalyser.get_block_size(block_instructions)
                            current_block = CustomElfBlock(start_addr=block_instructions[0].address,
                                                        end_addr=block_instructions[0].address + block_size,
                                                        size=block_size,
                                                        is_natural=block_instructions[0].address in natural_blocks,
                                                        instructions=block_instructions,
                                                        within_symbol=symbol.name_id)
                            symbol_to_blocks[symbol].append(current_block)
                            block_instructions = []
        else:
            # build natural blocks
            for symbol, asm in asm_per_symbol.items():
                symbol_to_blocks[symbol] = []
                block_instructions: list[capstone.CsInsn] = []
                jump_formed_blocks[symbol] = set()
                for last_insn in asm.instructions:
                    if not last_insn:
                        continue
                    block_instructions.append(last_insn)
                    if ElfInstruction.is_invalid(insn=last_insn):
                        continue
                    if ElfInstruction.is_jump(insn=last_insn, architecture=self.elffile_info.architecture) or ElfInstruction.is_return(insn=last_insn, architecture=self.elffile_info.architecture):
                        block_size = ElfAnalyser.get_block_size(block_instructions)
                        block = CustomElfBlock(start_addr=block_instructions[0].address,
                                               end_addr=block_instructions[0].address + block_size,
                                               size=block_size,
                                               is_natural=True,
                                               instructions=block_instructions,
                                               within_symbol=symbol.name_id)
                        symbol_to_blocks[symbol].append(block)
                        for target, target_addr in self.get_jump_targets(insn=last_insn, symbol=symbol, relevant_functions=relevant_functions, all_functions=all_functions, jump_tables=asm.jump_tables):
                            if target == JumpTarget.INTRA:
                                jump_formed_blocks[symbol].add(target_addr)
                        block_instructions = []
                if block_instructions:
                    block_size = ElfAnalyser.get_block_size(block_instructions)
                    block = CustomElfBlock(start_addr=block_instructions[0].address,
                                           end_addr=block_instructions[0].address + block_size,
                                           size=block_size,
                                           is_natural=True,
                                           instructions=block_instructions,
                                           within_symbol=symbol.name_id)
                    symbol_to_blocks[symbol].append(block)
                    block_instructions = []

            # build jump-formed blocks
            def build_jump_formed_block(symbol_to_blocks: dict[ELFSymbol, list[CustomElfBlock]], jump_formed_blocks: dict[ELFSymbol, set[int]]):
                for symbol, targets in jump_formed_blocks.items():
                    if symbol in symbol_to_blocks:
                        symbol_blocks = {sb.start_addr: sb for sb in symbol_to_blocks[symbol]}
                        if symbol_blocks:
                            for target in targets:
                                if target not in symbol_blocks:
                                    for symbol_block in symbol_blocks.values():
                                        if symbol_block.start_addr < target < symbol_block.end_addr:
                                            block_instructions: list[capstone.CsInsn] = []
                                            for insn in symbol_block.instructions:
                                                # TODO: natural blocks will keep data sequences within their blocks
                                                # (not the actual .byte instructions - those will be skipped; but the block itself will hold a gap where the pool is)
                                                if insn.address >= target:
                                                    block_instructions.append(insn)
                                            if block_instructions:
                                                block_size = ElfAnalyser.get_block_size(block_instructions)
                                                block = CustomElfBlock(start_addr=block_instructions[0].address,
                                                                       end_addr=block_instructions[0].address + block_size,
                                                                       size=block_size,
                                                                       is_natural=False,
                                                                       instructions=block_instructions,
                                                                       within_symbol=symbol.name_id)
                                                symbol_to_blocks[symbol].append(block)
                                            block_instructions = []
                return symbol_to_blocks
            symbol_to_blocks = build_jump_formed_block(symbol_to_blocks, jump_formed_blocks)

        # build cfg
        for symbol, blocks in symbol_to_blocks.items():
            blocks = sorted(blocks, key=lambda x: x.start_addr)
            elf_symbol_data: CustomElfSymbolData = CustomElfSymbolData(symbol=symbol,
                                                                       blocks={},
                                                                       call_graph={},
                                                                       local_transition_graph=nx.DiGraph(),
                                                                       control_flow_graph=nx.DiGraph())
            blocks_mappings = {block.start_addr: block for block in blocks}
            number_of_blocks = len(blocks)
            # add symbol to call graph
            if symbol.name_id not in custom_elf_data.call_graph:
                custom_elf_data.call_graph[symbol.name_id] = set()
            # add all blocks
            for current_block in blocks:
                elf_symbol_data.blocks[current_block.start_addr] = current_block
                elf_symbol_data.local_transition_graph.add_node(current_block)
                elf_symbol_data.control_flow_graph.add_node(current_block.start_addr)
            # link blocks
            for i, current_block in enumerate(blocks):
                # get current block last instruction
                last_insn = current_block.instructions[-1]
                # check if block should link to next
                if i + 1 < number_of_blocks:
                    next_block = blocks[i + 1]
                    if not use_block_splitting:
                        if not next_block.is_natural:
                            next_block_index = i + 1
                            while next_block_index < number_of_blocks:
                                if blocks[next_block_index].is_natural:
                                    next_block = blocks[next_block_index]
                                    break
                                next_block_index += 1
                    # add fallthrough block if last instruction is not an unconditional jump or return
                    if not ElfInstruction.is_jump(last_insn, architecture=self.elffile_info.architecture) and \
                       not ElfInstruction.is_return(last_insn, architecture=self.elffile_info.architecture):
                        elf_symbol_data.local_transition_graph.add_edge(current_block, next_block)
                        elf_symbol_data.control_flow_graph.add_edge(current_block.start_addr, next_block.start_addr)
                    # for conditional jumps add the fallback block
                    elif ElfInstruction.is_conditional_jump(insn=last_insn, architecture=self.elffile_info.architecture):
                        # add fallback block
                        elf_symbol_data.local_transition_graph.add_edge(current_block, next_block)
                        elf_symbol_data.control_flow_graph.add_edge(current_block.start_addr, next_block.start_addr)
                # check if block should link to target
                if ElfInstruction.is_invalid(insn=last_insn):
                    continue
                if ElfInstruction.is_jump(insn=last_insn, architecture=self.elffile_info.architecture):
                    if current_block.start_addr not in elf_symbol_data.call_graph:
                        elf_symbol_data.call_graph[current_block.start_addr] = set()

                    asm = asm_per_symbol[symbol] if symbol in asm_per_symbol else None
                    for target, target_addr in self.get_jump_targets(insn=last_insn, symbol=symbol, relevant_functions=relevant_functions, all_functions=all_functions, jump_tables=asm.jump_tables if asm else {}):
                        if target == JumpTarget.UNDEFINED:
                            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'jump instruction: {last_insn.mnemonic} {last_insn.op_str} has undefined target')
                        elif target == JumpTarget.INTRA:
                            if target_addr not in blocks_mappings:
                                logger.warning('symbol %s jumping from block %s to undefined block %s', symbol.name, hex(current_block.start_addr), hex(target_addr))
                            else:
                                target_in_block = blocks_mappings[target_addr]
                                elf_symbol_data.control_flow_graph.add_edge(current_block.start_addr, target_in_block.start_addr)
                                elf_symbol_data.local_transition_graph.add_edge(current_block, target_in_block)
                        elif target in [JumpTarget.INTER, JumpTarget.INTER_NON_USER, JumpTarget.INTER_UNMAPPED, JumpTarget.EXTERNAL]:
                            if target == JumpTarget.INTER and (target_addr not in relevant_functions):
                                raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'External target address {hex(target_addr)} missing from function dataset')
                            target_func = relevant_functions[target_addr] if target == JumpTarget.INTER else None
                            if BYPASS_PLT_TARGETS and target_func and target_func.name.endswith(PLT_SUFFIX):
                                base_name = target_func.name.removesuffix(PLT_SUFFIX)
                                for addr, func in relevant_functions.items():
                                    if func.name == base_name:
                                        target_func = func
                                        target_addr = addr
                                        break
                            target_name = target_func.name_id if target_func else NON_USER_CODE_IDENTIFIER
                            elf_symbol_data.call_graph[current_block.start_addr].add(target_addr)
                            custom_elf_data.call_graph[symbol.name_id].add(target_name)
                            elf_symbol_data.control_flow_graph.add_edge(current_block.start_addr, target_addr)
                            if target != JumpTarget.INTER:
                                if target not in jump_target_to_addrs:
                                    jump_target_to_addrs[target] = set()
                                jump_target_to_addrs[target].add(target_addr)
                        elif target == JumpTarget.UNRESOLVED:
                            elf_symbol_data.call_graph[current_block.start_addr].add(target_addr)
                            custom_elf_data.call_graph[symbol.name_id].add(NON_USER_CODE_IDENTIFIER)
                            elf_symbol_data.control_flow_graph.add_edge(current_block.start_addr, target_addr)
                            if target not in jump_target_to_addrs:
                                jump_target_to_addrs[target] = set()
                            jump_target_to_addrs[target].add(target_addr)

            if elf_symbol_data.blocks:
                custom_elf_data.functions.append(elf_symbol_data)

        # add stub objects
        is_rust = utility.is_rust_elf(self.elf)
        for target, addrs in jump_target_to_addrs.items():
            for addr in addrs:
                custom_elf_data.functions.append(self.gen_stub_target_symbol(address=addr, jump_target=target, is_rust=is_rust))

        # add relevant variables
        for relevant_variable in relevant_variables.values():
            elf_symbol_data: CustomElfSymbolData = CustomElfSymbolData(symbol=relevant_variable,
                                                                       blocks={},
                                                                       call_graph={},
                                                                       local_transition_graph=nx.DiGraph(),
                                                                       control_flow_graph=nx.DiGraph())
            custom_elf_data.variables.append(elf_symbol_data)

        # generate elf data statistics
        custom_elf_data_statistics: CustomElfDataStatistics = CustomElfDataStatistics(total_functions = self.elffile_info.function_count,
                                                                                     total_variables = self.elffile_info.variable_count,
                                                                                     total_relevant_functions = sum(1 for _, f in relevant_functions.items() if not self.is_stub_symbol(f.name)),
                                                                                     total_relevant_variables = len(relevant_variables),
                                                                                     total_processed_functions = sum(1 for f in custom_elf_data.functions if not self.is_stub_symbol(f.symbol.name)),
                                                                                     total_processed_variables = len(custom_elf_data.variables))
        custom_elf_data.statistics = custom_elf_data_statistics

        # return custom elf data object
        return custom_elf_data

    # for now, slice_to_callgraph is used to create callgraph from tricore slice data
    def slice_to_callgraph(self, slice_data_path: str = '', sym_map_path: str = ''):
        # get_symbols_from_map follows current symbol map layout generated by asmslicer:
        # "symbol","symbol_short","symbol_demangled","start_address","size","namespace"
        def get_symbols_from_map():
            symbols_map = {}
            with open(sym_map_path, 'r', encoding='utf-8') as map_file:
                symbol_csv_reader = csv.reader(map_file)
                next(symbol_csv_reader)
                for row in symbol_csv_reader:
                    # map symbol by mangled name, since in the assembly it will be mangled
                    symbol = row[0]
                    if symbol:
                        symbols_map[symbol] = {}
                        if row[3] and row[4]:
                            symbols_map[symbol]['addr'] = row[3]
                            symbols_map[symbol]['size'] = row[4]
                            symbols_map[symbol]['demangled'] = row[2]
            return symbols_map

        # this is patch for missing s2.name from slice data
        # should be fixed in elf_slicer
        # follows tricore slicer layout:
        # s2.container,r.cyc,r.from_addr,r.to_addr,r.asm,s1.name,s2.name
        def post_process_slice_data(sym_map):
            with open(slice_data_path, 'r', encoding='utf-8') as slice_csv_file, open(f'{slice_data_path}.updated', 'w', encoding='utf-8') as slice_csv_file_updated:
                slice_csv_reader = csv.reader(slice_csv_file)
                slice_csv_writer = csv.writer(slice_csv_file_updated)
                slice_csv_writer.writerow(next(slice_csv_reader))
                missing_counter = 0
                for row in slice_csv_reader:
                    # if s2.name is missing (callee symbol)
                    if not row[6]:
                        # get jump from last instruction in the assembly
                        asm_ins = row[4].split("\n")[-1].split(" ")[-1]
                        if asm_ins.endswith(">"):
                            # if jump to symbol without offset
                            if "+" not in asm_ins:
                                to_symbol = asm_ins.split("<")[-1].split(">")[0]
                                if to_symbol in sym_map:
                                    logger.debug(f"stcfg: include missing jump to {to_symbol}")
                                    row[6] = to_symbol
                                    missing_counter += 1
                                else:
                                    logger.error(f'stcfg: jum to symbol {to_symbol} without offset missing from map')
                            # if jump to symbol with offset
                            else:
                                # get symbol and offset
                                loc = asm_ins.split("+")
                                to_symbol = loc[0].split("<")[-1].split(">")[0]
                                offset = int(loc[1].split("<")[-1].split(">")[0], 16)
                                if to_symbol in sym_map:
                                    # get callee symbol address and check for existing symbol on symbol+offset
                                    addr = int(sym_map[to_symbol]['addr'], 10)
                                    dest = addr + offset
                                    dests = [sym.key() for sym in sym_map.values() if int(sym['addr'], 10) == dest]
                                    if dests:
                                        if len(dests) == 1:
                                            logger.debug(f"stcfg: include missing jump with offset {offset} to {to_symbol}")
                                            row[6] = dests[0]
                                            missing_counter += 1
                                        elif len(dests) > 1:
                                            logger.error(f'stcfg: multiple symbols with same address {dest}')
                                        else:
                                            logger.error('stcfg: what happened?')
                                    else:
                                        size = int(sym_map[to_symbol]['size'], 10)
                                        if offset <= size:
                                            if row[5] in sym_map[to_symbol]['demangled']: # bad workaround, should match fully
                                                logger.debug(f"stcfg: jumping within same {to_symbol}")
                                            else:
                                                logger.debug(f"stcfg: jumping outside symbol {row[5]} to {to_symbol}")
                                        else:
                                            # we ignore this atm, with the assumption that it's normal
                                            logger.debug(f'stcfg: strange jump with offset {offset} from {row[5]} to {to_symbol} with size {size}')
                                else:
                                    logger.error(f'stcfg: jum to symbol {to_symbol} with offset {offset} missing from map')
                    slice_csv_writer.writerow(row)
                logger.info(f'stcfg: added missing {missing_counter} target symbols from slice data')
        # create mappings of caller and callees
        def create_call_mappings():
            call_mappings_dict = {}
            with open(f'{slice_data_path}.updated', 'r', encoding='utf-8') as slice_csv_file:
                slice_csv_reader = csv.reader(slice_csv_file)
                next(slice_csv_reader)
                for row in slice_csv_reader:
                    if row[5]:
                        if row[5] not in call_mappings_dict:
                            call_mappings_dict[row[5]] = set()
                        if row[6]:
                            call_mappings_dict[row[5]].add(row[6])
            return call_mappings_dict
        # create dot file from mappings of caller and callees
        def map_to_dot(call_mappings_dict):
            with open(f'{basepath}.dot', 'w', encoding='utf8') as dotfile:
                buffer_size = 1024*1024
                current_size = 0
                buffer = []
                dotfile.write('digraph {\n')
                if call_mappings_dict:
                    parsed_nodes = set()
                    def write_to_buffer(data, buffer, current_size):
                        if data:
                            buffer.append(data + ';\n')
                            current_size += len(data)
                            if current_size >= buffer_size:
                                dotfile.writelines(buffer)
                                current_size = 0
                                buffer = []
                    for f1, f2s in call_mappings_dict.items():
                        if f1 not in parsed_nodes:
                            parsed_nodes.add(f1)
                            write_to_buffer(f'"{f1}"', buffer, current_size)
                            for f2 in f2s:
                                if f2 not in parsed_nodes:
                                    parsed_nodes.add(f2)
                                    write_to_buffer(f'"{f2}"', buffer, current_size)
                                if f'{f1}_{f2}' not in parsed_nodes:
                                    parsed_nodes.add(f'{f1}_{f2}')
                                    write_to_buffer(f'"{f1}" -> "{f2}"', buffer, current_size)
                    if buffer:
                        dotfile.writelines(buffer)
                        current_size = 0
                        buffer = []
                dotfile.write('}')
        slice_data_path = os.path.abspath(slice_data_path)
        if not os.path.exists(slice_data_path) or not os.path.isfile(slice_data_path):
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message='invalid slice data filepath')
        # ugly workaround: slice files are usually very large, adjust as needed
        csv.field_size_limit(9999999)
        basedir = os.path.dirname(slice_data_path)
        basename = os.path.splitext(os.path.basename(slice_data_path))[0]
        basepath = os.path.join(basedir, basename)
        if not sym_map_path:
            sym_map_path = f'{basedir}/{basename}.sym'
            self.generate_symmap_file(out_sym_map_file=sym_map_path)
        sym_map = get_symbols_from_map()
        post_process_slice_data(sym_map)
        call_mappings_dict = create_call_mappings()
        map_to_dot(call_mappings_dict)

class RegisterTracker:
    @dataclasses.dataclass
    class ResolvedData:
        symbol: str
        offset: int
        address: int
        access: int

    def __init__(self, functions: dict[int, ELFSymbol], variables: dict[int, ELFSymbol]):
        self.functions: dict[int, ELFSymbol] = functions
        self.variables: dict[int, ELFSymbol] = variables
        self.active_regs: dict[str, int] = {}
        self.stack_memory: dict[int, str] = {}
        self.resolved_data: dict[int, RegisterTracker.ResolvedData] = {}

    def track(self, reg: str|None, addr: int):
        logger.debug(f'track reg {reg} -> {hex(addr)}')
        self.active_regs[reg] = addr

    def stop_tracking(self, reg: str|None):
        if reg in self.active_regs:
            logger.debug(f'stop tracking reg {reg}')
            del self.active_regs[reg]

    def is_tracking(self, reg: str|None) -> bool:
        return reg in self.active_regs

    def get_value(self, reg: str|None) -> int|None:
        if reg not in self.active_regs:
            return None
        return self.active_regs[reg]

    def track_stack_store(self, src_reg: str|None, offset: int):
        if src_reg not in self.active_regs:
            return
        self.stack_memory[offset] = self.active_regs[src_reg]

    def resolve(self, insn_addr: int, base_reg: str, access: InsnType, disp: int = 0, indx_reg: str = None) -> int|None:
        if insn_addr in self.resolved_data:
            return self.resolved_data[insn_addr].address
        eff_addr = None
        access_to_stack = base_reg == 'sp'
        # If the stack is accessed, allow tracking the resolved address through it,
        # so that other registers can inherit the value (i.e., return the resolved address).
        # However, since only general-purpose registers are eligible for symbol resolution,
        # stack-based accesses in the current instruction will not be stored as resolved data for future reference.
        if access_to_stack:
            if disp not in self.stack_memory:
                logger.debug(f'stack pointer offset {hex(disp)} not tracked - skipping effective address resolution')
                return
            eff_addr = self.stack_memory[disp]
        else:
            if base_reg not in self.active_regs:
                logger.debug(f'base register {base_reg} not tracked - skipping effective address resolution')
                return
            if indx_reg and (indx_reg not in self.active_regs):
                logger.debug(f'indx register {base_reg} not tracked - skipping effective address resolution')
                return
            eff_addr = self.active_regs[base_reg] + (self.active_regs[indx_reg] if indx_reg else 0) + disp
        for addr, sym in self.variables.items():
            if addr <= eff_addr < addr + sym.size:
                ra = RegisterTracker.ResolvedData(symbol=sym.name_id, offset=(eff_addr - addr), address=eff_addr, access=access)
                if not access_to_stack:
                    self.resolved_data[insn_addr] = ra
                return ra.address
        if eff_addr in self.functions:
            ra = RegisterTracker.ResolvedData(symbol=self.functions[eff_addr].name_id, offset=0, address=eff_addr, access=access)
            if not access_to_stack:
                self.resolved_data[insn_addr] = ra
            return ra.address

@dataclasses.dataclass
class Bindiff:
    base_elf_analyser: ElfAnalyser
    comparing_elf_analyser: ElfAnalyser
    out_dir: str = ''
    verbose: bool = False

    def __init__(self,
                 base_elf_analyser: ElfAnalyser,
                 comparing_elf_analyser: ElfAnalyser,
                 out_dir: str = '',
                 verbose: bool = False):
        logger.info('initializing bindiff')
        self.base_elf_analyser = base_elf_analyser
        self.comparing_elf_analyser = comparing_elf_analyser
        self.out_dir = out_dir
        self.verbose = verbose

    @staticmethod
    def _create_report_symbol_entry(elf_for_analyses: ElfAnalyser,
                                    total_symbols: int,
                                    relevant_symbol: ELFSymbol,
                                    masked_instructions: list[str],
                                    instructions_hash: str,
                                    masked_instructions_hash: str,
                                    stt_type: str,
                                    instruction_mnemonics_hash: str = '') -> dict:
        elf_symbol_entry = {}
        elf_symbol_entry['elf_name'] = elf_for_analyses.elf_base_name
        elf_symbol_entry['elf_hash'] = elf_for_analyses.elf_hash
        elf_symbol_entry['elf_symbols_count'] = total_symbols
        elf_symbol_entry['symbol_name'] = relevant_symbol.name_id
        elf_symbol_entry['symbol_size'] = relevant_symbol.size
        elf_symbol_entry['masked_instructions'] = masked_instructions
        elf_symbol_entry['instructions_hash'] = instructions_hash
        elf_symbol_entry['masked_instructions_hash'] = masked_instructions_hash
        elf_symbol_entry['instruction_mnemonics_hash'] = instruction_mnemonics_hash
        elf_symbol_entry['stt_type'] = stt_type
        return elf_symbol_entry

    def analyse(self):
        logger.info('starting bindiff analyses')
        base_elf_symbols_details = self._analyse_elf_symbols(elf_for_analyses=self.base_elf_analyser, out_file_prefix='base', dump_analysis=self.verbose)
        comparing_elf_symbols_details = self._analyse_elf_symbols(elf_for_analyses=self.comparing_elf_analyser, out_file_prefix='comparing', dump_analysis=self.verbose)
        self._bindiff_analysis(base_elf_symbols=base_elf_symbols_details, comparing_elf_symbols=comparing_elf_symbols_details)

    @staticmethod
    def _resolve_addresses(insns: list[capstone.CsInsn],
                           functions: dict[int, ELFSymbol],
                           variables: dict[int, ELFSymbol],
                           arch: Architecture) -> dict[int, RegisterTracker.ResolvedData]:
        if not insns or (arch not in (Architecture.AARCH64, Architecture.ARM, Architecture.ARM_CORTEXM)):
            return {}
        rt = RegisterTracker(functions=functions, variables=variables)
        def _update_tracking(op, reg, mem):
            op_is_read = (op.access & capstone.CS_AC_READ) == capstone.CS_AC_READ
            op_is_write = (op.access & capstone.CS_AC_WRITE) == capstone.CS_AC_WRITE
            if op_is_write and rt.is_tracking(reg):
                rt.stop_tracking(reg)
                logger.debug(f"stopped tracking register '{reg}' re-written at 0x{insn.address:x}")
            elif op_is_read and rt.is_tracking(reg):
                logger.debug(f"tracked register '{reg}' read at 0x{insn.address:x}")

        for insn in insns:
            mnemonic = insn.mnemonic
            is_data_flow_handled = False

            if ElfInstruction.is_invalid(insn=insn):
                continue

            if mnemonic == "add":
                if 2 > len(insn.operands) > 3:
                    logger.warning(f'supported add instruction operands size mismatch. expected: 3. actual: {len(insn.operands)}.')
                else:
                    rd = insn.operands[0].reg
                    rn = insn.operands[1].reg
                    op = insn.operands[2] if len(insn.operands) == 3 else None

                    base_reg = insn.reg_name(rn)
                    dest_reg = insn.reg_name(rd)
                    offset = ASMSlicerUtils.get_imm(op)

                    if rt.is_tracking(reg=base_reg):
                        addr = rt.get_value(reg=base_reg)
                        rt.track(reg=dest_reg, addr=addr + offset)
                        is_data_flow_handled = True
            elif mnemonic == "adrp" and len(insn.operands) == 2:
                if len(insn.operands) != 2:
                    logger.warning(f'supported adrp instruction operands size mismatch. expected: 2. actual: {len(insn.operands)}.')
                else:
                    xd = insn.operands[0].reg
                    op = insn.operands[1]
                    addr = ASMSlicerUtils.get_imm(op)
                    rt.track(reg=insn.reg_name(xd), addr=addr)
                    is_data_flow_handled = True
            elif ElfInstruction.is_jump(insn, arch):
                for op in insn.operands:
                    if op.type == capstone.CS_OP_REG:
                        reg = insn.reg_name(op.reg)
                        if rt.resolve(insn_addr=insn.address, base_reg=reg, access=InsnType.CALL):
                            is_data_flow_handled = True
            elif ii:=ElfInstruction.parse_memory_access(insn=insn):
                # TODO: Add support as needed for 'ldp', 'ldxr', 'ldur', 'stp', 'stxr', 'stur'.
                if not ii.reg:
                    logger.warning(f'source/destination register not evaluated. skipping resolving address at insn: {hex(insn.address)}: {insn.mnemonic} {insn.op_str}')
                else:
                    resolved_addr = rt.resolve(insn_addr=insn.address, base_reg=ii.base, indx_reg=ii.index, disp=ii.disp, access=ii.type)
                    if resolved_addr:
                        is_data_flow_handled = True
                        if ii.type == InsnType.LOAD:
                            rt.track(reg=ii.reg, addr=resolved_addr)
                    if ii.base == 'sp' and ii.type == InsnType.STORE:
                        rt.track_stack_store(src_reg=ii.reg, offset=ii.disp)

            if not is_data_flow_handled:
                for op in insn.operands:
                    if not op:
                        continue
                    if op.type == capstone.CS_OP_REG:
                        reg = insn.reg_name(op.reg)
                        if not reg:
                            continue
                        _update_tracking(op=op, reg=reg, mem=False)
                    elif op.type == capstone.CS_OP_MEM:
                        mem = op.mem
                        if hasattr(mem, 'base'):
                            _update_tracking(op=op, reg=insn.reg_name(mem.base), mem=True)
                        if hasattr(mem, 'index'):
                            _update_tracking(op=op, reg=insn.reg_name(mem.index), mem=True)

        return rt.resolved_data

    @staticmethod
    def _insns(functions: dict[int, ELFSymbol], asm: dict[ELFSymbol, ElfDisassembler.Asm], elf: str):
        if not functions or not asm:
            return
        for function in functions.values():
            name = function.name_id
            size = function.size
            addr = function.addr
            if function in asm:
                node_insns = asm[function].instructions
                if not node_insns:
                    logger.warning(f'missing instructions for function: {name} with address {hex(addr)} and size {size} in {elf}')
                yield (function, node_insns)
            else:
                logger.warning(f'missing instructions for function: {name} with address {hex(addr)} and size {size} in {elf}')

    def _analyse_elf_symbols(self,
                             elf_for_analyses: ElfAnalyser,
                             out_file_prefix: str,
                             dump_analysis: bool) -> dict[str, dict]:
        logger.info(f'analysing elf {elf_for_analyses.elf_base_name}')
        bindiff_analysis_result: dict[str, dict] = {}
        if not elf_for_analyses:
            logger.error('elf not provided for bindiff')
            return bindiff_analysis_result
        relevant_functions: dict[int, ELFSymbol] = {sym.addr: sym for sym in sorted(list(elf_for_analyses.get_all_elf_symbols(symbol_type='STT_FUNC')), key=lambda x: x.addr)}
        relevant_variables: dict[int, ELFSymbol] = {sym.addr: sym for sym in sorted(list(elf_for_analyses.get_all_elf_symbols(symbol_type='STT_OBJECT')), key=lambda x: x.addr)}
        asm = ElfDisassembler.disassemble(elf_file=elf_for_analyses.elf, elffile_info=elf_for_analyses.elffile_info, relevant_symbols=relevant_functions)
        resolved_addresses: dict[str, dict[int, RegisterTracker.ResolvedData]] = {}

        # pre-process functions
        for relevant_function, node_insns in Bindiff._insns(functions=relevant_functions, asm=asm, elf=elf_for_analyses.elf_base_name):
            ra = Bindiff._resolve_addresses(insns=node_insns, arch=elf_for_analyses.elffile_info.architecture, functions=relevant_functions, variables=relevant_variables)
            resolved_addresses[relevant_function.name_id] = ra

        # process functions
        for relevant_function, node_insns in Bindiff._insns(functions=relevant_functions, asm=asm, elf=elf_for_analyses.elf_base_name):
            function_instructions: list[str] = []
            function_instructions_masked: list[str] = []
            instruction_mnemonics: list[str] = []
            for insn in node_insns:
                function_instructions.append(f'{insn.mnemonic} {insn.op_str}')
                instruction_mnemonics.append(insn.mnemonic)
                masked_instruction = Bindiff._mask_instruction(insn=insn, architecture=elf_for_analyses.elffile_info.architecture, functions=relevant_functions, variables=relevant_variables, resolved_data=resolved_addresses[relevant_function.name_id])
                function_instructions_masked.append(masked_instruction)
            instructions_hash = Bindiff._hash_instructions(function_instructions)
            masked_instructions_hash = Bindiff._hash_instructions(function_instructions_masked)
            instruction_mnemonics_hash = Bindiff._hash_instructions(instruction_mnemonics)
            bindiff_analysis_result[relevant_function.name_id] = Bindiff._create_report_symbol_entry(elf_for_analyses=elf_for_analyses,
                                                                                                        total_symbols=len(relevant_functions),
                                                                                                        relevant_symbol=relevant_function,
                                                                                                        masked_instructions=function_instructions_masked,
                                                                                                        instructions_hash=instructions_hash,
                                                                                                        masked_instructions_hash=masked_instructions_hash,
                                                                                                        instruction_mnemonics_hash=instruction_mnemonics_hash,
                                                                                                        stt_type='STT_FUNC')

        # process variables
        for relevant_variable in relevant_variables.values():
            # no need for hashing since variables will be checked if added/removed only
            instructions_hash = relevant_variable.name_id
            masked_instructions_hash = relevant_variable.name_id
            bindiff_analysis_result[relevant_variable.name_id] = Bindiff._create_report_symbol_entry(elf_for_analyses=elf_for_analyses,
                                                                                                     total_symbols=len(relevant_variables),
                                                                                                     relevant_symbol=relevant_variable,
                                                                                                     masked_instructions=[],
                                                                                                     instructions_hash=instructions_hash,
                                                                                                     masked_instructions_hash=masked_instructions_hash,
                                                                                                     stt_type='STT_OBJECT')
        if dump_analysis:
            out_bindiff_analysis_filepath = f'bindiff_analysis_{out_file_prefix}_{elf_for_analyses.elf_base_name}.csv'
            if self.out_dir:
                out_bindiff_analysis_filepath = os.path.join(self.out_dir, out_bindiff_analysis_filepath)
            with open(out_bindiff_analysis_filepath, 'w', encoding='utf8') as out_file:
                csv_writer = csv.writer(out_file)
                csv_writer.writerow(['elf_name', 'elf_hash', 'elf_symbols_count', 'symbol_name', 'symbol_size', 'op_hash', 'op_masked_hash'])
                for elf_symbol_entry in bindiff_analysis_result.values():
                    csv_writer.writerow([elf_symbol_entry['elf_name'],
                                         elf_symbol_entry['elf_hash'],
                                         elf_symbol_entry['elf_symbols_count'],
                                         elf_symbol_entry['symbol_name'],
                                         elf_symbol_entry['symbol_size'],
                                         elf_symbol_entry['instructions_hash'],
                                         elf_symbol_entry['masked_instructions_hash']])
        return bindiff_analysis_result

    @staticmethod
    def _find_reason(base_instructions_list: list[str], comparing_instructions_list: list[str], mnemonics_matched: bool):
        bil = len(base_instructions_list)
        cil = len(comparing_instructions_list)
        if (max(bil, cil)) == 0:
            return '-'
        if bil != cil:
            return 'FUNCTION_SIZE_MISMATCH'
        if not mnemonics_matched:
            return 'INSTRUCTION_MNEMONIC_MISMATCH'
        return 'MASKING_MISMATCH'


    @staticmethod
    def _calculate_similarity_ratio(symbol: str, sym_type: str, base_instructions_list: list[str], comparing_instructions_list: list[str], mnemonics_matched: bool) -> tuple[str, str, str, str]:
        base_instructions = ' '.join(base_instructions_list)
        comparing_instructions = ' '.join(comparing_instructions_list)
        base_instruction_words = base_instructions.split()
        comparing_instruction_words = comparing_instructions.split()
        base_instruction_len = len(base_instruction_words)
        comparing_instruction_len = len(comparing_instruction_words)
        reason = Bindiff._find_reason(base_instructions_list=base_instructions_list, comparing_instructions_list=comparing_instructions_list, mnemonics_matched=mnemonics_matched)
        if base_instruction_len == 0 and comparing_instruction_len == 0:
            return symbol, sym_type, 0.0, reason
        if base_instruction_len == 0 or comparing_instruction_len == 0:
            return symbol, sym_type, 100.0, reason
        prev_row = list(range(comparing_instruction_len + 1))
        for i in range(1, base_instruction_len + 1):
            current_row = [i] + [0] * comparing_instruction_len
            for j in range(1, comparing_instruction_len + 1):
                cost = 0 if base_instruction_words[i - 1] == comparing_instruction_words[j - 1] else 1
                current_row[j] = min(
                    prev_row[j] + 1, # remove
                    current_row[j - 1] + 1, # add
                    prev_row[j - 1] + cost # modify
                )
            prev_row = current_row
        distance = prev_row[comparing_instruction_len]
        max_len = max(base_instruction_len, comparing_instruction_len)
        ratio = 1 - (distance / max_len)
        return symbol, sym_type, f'{round(ratio, 7)}f', reason

    @staticmethod
    def _calculate_similarity_ratio_ext(symbol: str, sym_type: str, base_instructions_list: list[str], comparing_instructions_list: list[str], mnemonics_matched: bool) -> tuple[str, str, str, str]:
        distance = Levenshtein.distance(base_instructions_list, comparing_instructions_list)
        max_len = (max(len(base_instructions_list), len(comparing_instructions_list)))
        ratio = 0.0
        reason = Bindiff._find_reason(base_instructions_list=base_instructions_list, comparing_instructions_list=comparing_instructions_list, mnemonics_matched=mnemonics_matched)
        if max_len == 0:
            return symbol, sym_type, ratio, reason
        else:
            ratio = 1 - (distance/max_len)
            return symbol, sym_type, f'{ratio:.7f}', reason

    @staticmethod
    def _looks_synthetic(sym: str) -> bool:
        if '@' not in sym:
            return False

        head, _, tail = sym.partition('@')

        if not (6 <= len(head) <= 12 and all(c in "0123456789abcdef" for c in head)):
            return False

        if not all(c in "0123456789abcdef_" for c in tail):
            return False

        if '_' not in tail:
            return False

        return True
    
    @staticmethod
    def _filter_synthetic_symbols(symbols: Iterable[str]) -> Iterator[str]:
        for sym in symbols:
            if Bindiff._looks_synthetic(sym):
                continue
            if SYNTHETIC_FUNC_PATTERN.match(sym):
                continue
            yield sym

    def _bindiff_analysis(self, base_elf_symbols: dict[str, dict], comparing_elf_symbols: dict[str, dict]) -> None:
        logger.info('calculating bindiff')
        base_symbols: set[str] = set(Bindiff._filter_synthetic_symbols(base_elf_symbols.keys()))
        comparing_symbols: set[str] = set(Bindiff._filter_synthetic_symbols(comparing_elf_symbols.keys()))
        added_symbols: set[str] = comparing_symbols.difference(base_symbols)
        removed_symbols: set[str] = base_symbols.difference(comparing_symbols)
        modified_symbols: set[str] = {k for k, v in base_elf_symbols.items() if k in comparing_elf_symbols and comparing_elf_symbols[k]['masked_instructions_hash'] != v['masked_instructions_hash']}
        out_diff_filepath: str = f'{self.base_elf_analyser.elf_base_name}~{self.comparing_elf_analyser.elf_base_name}.diff.csv'
        if self.out_dir:
            out_diff_filepath = os.path.join(self.out_dir, out_diff_filepath)
        with open(out_diff_filepath, 'w', encoding='utf8') as out_csv_file:
            csv_writer = csv.writer(out_csv_file)
            csv_writer.writerow(['status', 'symbol', 'stt_type', 'similarity_ratio', 'reason'])
            for s in sorted(added_symbols):
                ratio = 0.0
                csv_writer.writerow(['added', s, comparing_elf_symbols[s]['stt_type'], ratio, '-'])
            for s in sorted(removed_symbols):
                ratio = 0.0
                csv_writer.writerow(['removed', s, base_elf_symbols[s]['stt_type'], ratio, '-'])

            with ThreadPoolExecutor(max_workers = mp.cpu_count() - 1) as executor:
                futures = [executor.submit(Bindiff._calculate_similarity_ratio_ext,
                                            s,
                                            base_elf_symbols[s]['stt_type'],
                                            base_elf_symbols[s]['masked_instructions'],
                                            comparing_elf_symbols[s]['masked_instructions'],
                                            base_elf_symbols[s]['instruction_mnemonics_hash'] == comparing_elf_symbols[s]['instruction_mnemonics_hash']
                                           ) for s in sorted(modified_symbols)]
                for future in as_completed(futures):
                    csv_writer.writerow(['modified', future.result()[0], future.result()[1], future.result()[2], future.result()[3]])
        if self.base_elf_analyser.compress_out_csv and self.comparing_elf_analyser.compress_out_csv:
            if out_diff_filepath:
                ASMSlicerUtils.compress_csv_file(input_file_path=out_diff_filepath, remove_original=True)
        if self.verbose:
            out_summary_filepath = f'bindiff_analysis_{self.base_elf_analyser}~{self.comparing_elf_analyser}_summary.json'
            if self.out_dir:
                out_summary_filepath = os.path.join(self.out_dir, out_summary_filepath)
            with open(out_summary_filepath, 'w', encoding='utf8') as out_bindiff_summary_file:
                json.dump({'added_symbols': list(added_symbols),
                            'removed_symbols': list(removed_symbols),
                            'modified_symbols': list(modified_symbols)}, out_bindiff_summary_file, indent=2)
            if self.base_elf_analyser.compress_out_csv and self.comparing_elf_analyser.compress_out_csv:
                if out_summary_filepath:
                    ASMSlicerUtils.compress_csv_file(input_file_path=out_summary_filepath, remove_original=True)

    @staticmethod
    def _mask_instruction(insn: capstone.CsInsn,
                          architecture: Architecture,
                          functions: dict[int, ELFSymbol],
                          variables: dict[int, ELFSymbol],
                          resolved_data: dict[int, RegisterTracker.ResolvedData]) -> str:
        if ElfInstruction.is_invalid(insn=insn) or not functions:
            return ''
        masked: list[str] = list([insn.mnemonic])
        ra_str = None
        if insn.address in resolved_data:
            ra = resolved_data[insn.address]
            ra_str = ra.symbol if ra.offset == 0 else f'{ra.symbol}+{hex(ra.offset)}'
        is_call_insn: bool = ElfInstruction.is_jump(insn=insn, architecture=architecture)
        for op in insn.operands:
            if op.type == capstone.CS_OP_INVALID: # invalid
                masked.append('<inv>')
            if op.type == capstone.CS_OP_REG: # registers
                reg_value = '<reg>'
                if hasattr(op, 'reg'):
                    reg_value = insn.reg_name(op.reg, '<reg>')
                if is_call_insn and ra_str:
                    reg_value = ra_str
                masked.append(reg_value)
            elif op.type == capstone.CS_OP_IMM: # immediate
                imm_value = '<imm>' # imm_value = f'{imm_addr}'
                if hasattr(op, 'imm'):
                    imm_addr = ASMSlicerUtils.get_imm(op)
                    is_str_load_insn: bool = insn.mnemonic in ['ldr', 'str']
                    if is_call_insn and imm_addr in functions:
                        imm_value = f'{functions[imm_addr].name_id}'
                    elif is_str_load_insn and imm_addr in variables:
                        imm_value = f'{variables[imm_addr].name_id}'
                masked.append(imm_value)
            elif op.type == capstone.CS_OP_MEM: # memory
                if ra_str:
                    mem_value = f'<mem: {ra_str}>'
                else:
                    disp_marker = '<dis>'
                    base_marker = '<bas>'
                    ind_marker  = '<ind>'
                    mem_op = op.mem if hasattr(op, 'mem') else None
                    base_reg = insn.reg_name(mem_op.base, base_marker) if mem_op and hasattr(mem_op, 'base') else base_marker
                    ind_reg  = insn.reg_name(mem_op.index, ind_marker) if mem_op and hasattr(mem_op, 'index') else ind_marker
                    # disp = insn.reg_name(mem_op.disp, disp_marker) if mem_op and hasattr(mem_op, 'disp') else disp_marker
                    mem_value = f'<mem: {base_reg}, {ind_reg}, {disp_marker}>'
                masked.append(mem_value)
            elif op.type == capstone.CS_OP_FP: # floating
                masked.append('<fp>')
            else: # should never happen
                masked.append('<oth>')
        # debug masked insn
        # print(f'insn: {insn}')
        # print(f'masked: {masked}')
        # print(f'insn_masked: {" ".join(masked)}')
        # print()
        return ' '.join(masked)

    @staticmethod
    def _hash_instructions(masked_instructions: list[str]) -> str:
        return hashlib.sha256(''.join(masked_instructions).encode()).hexdigest()

@dataclasses.dataclass
class TestImpactMapper:
    mtts_config_path: str
    architecture: str
    show_progress: bool

    def __init__(self, mtts_config_path: str = '', architecture = '', show_progress: bool = False, dump_cfg: bool = False, cfg_dir: str = ''):
        self.mtts_config_path = mtts_config_path
        self.architecture = architecture
        self.show_progress = show_progress

        mtts_config = self._load_mtts_config(mtts_config_path)
        if not mtts_config:
            logger.error('invalid mtts config')
            return
        test_execution_reports_location = mtts_config['test_execution_reports_location']
        test_elfs_location = mtts_config['test_elfs_location']
        release_elfs_location = mtts_config['release_elfs_location']
        test_source_files = set()
        xml_files = TestImpactMapper.find_xml_files(test_execution_reports_location)
        for xml_file in xml_files:
            test_source_files = test_source_files.union(TestImpactMapper.parse_junit_xml(file_path=xml_file))
        all_test_symbols = self.get_symbols_from_elfs(elfs_location=test_elfs_location, test_source_files=test_source_files, dump_cfg=dump_cfg, cfg_dir=cfg_dir)
        all_release_symbols = self.get_symbols_from_elfs(elfs_location=release_elfs_location, test_source_files=None, dump_cfg=dump_cfg, cfg_dir=cfg_dir)
        symbol_impacts_test_map = self.generate_symbol_impacts_test_map(test_symbols=all_test_symbols, release_symbols=all_release_symbols)
        with open('symbol_impacts_test_map.json', 'w', encoding='utf8') as f:
            json.dump(symbol_impacts_test_map, f, indent=2)

    @staticmethod
    def _load_mtts_config(mtts_config_path: str = '') -> dict:
        mtts_config_data = {}
        try:
            with open(mtts_config_path, 'r', encoding='utf-8') as file:
                mtts_config_data = json.load(file)
                return mtts_config_data
        except json.JSONDecodeError as e:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message=f'loading mtts config failed, invalid json: {e.msg} at line {e.lineno}, column {e.colno}') from e
        except FileNotFoundError as e:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message=f'loading mtts config failed, file {mtts_config_path} not found') from e
        except PermissionError as e:
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message=f'loading mtts config failed, permission denied to read {mtts_config_path}') from e
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'loading mtts config failed: {e}') from e
        return mtts_config_data

    @staticmethod
    def validate_directory(dir_path: str = '') -> Path:
        path = Path(dir_path)
        if not path.exists():
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message=f'directory {dir_path} does not exist.')
        if not path.is_dir():
            raise ASMSlicerException(error_code=ASMSlicerError.BAD_INPUT_ERROR, message=f'path {dir_path} is not a directory.')
        return path

    @staticmethod
    def find_elf_files(dir_path: str = '') -> list[Path]:
        root_path = TestImpactMapper.validate_directory(dir_path=dir_path)
        elf_files = []
        for file_path in root_path.rglob('*'):
            if file_path.is_file() and utility.is_elf_file(file_path):
                elf_files.append(file_path)
        return elf_files

    @staticmethod
    def find_xml_files(dir_path: str = '') -> list[Path]:
        root_path = TestImpactMapper.validate_directory(dir_path=dir_path)
        xml_files = []
        for file_path in root_path.rglob('*.xml'):
            if file_path.is_file():
                xml_files.append(file_path)
        return xml_files

    def get_symbols_from_elfs(self, elfs_location: str = '', test_source_files: set = None, dump_cfg: bool = False, cfg_dir: str = '') -> dict:
        all_symbols = {}
        for elf_path in TestImpactMapper.find_elf_files(dir_path=elfs_location):
            analyser = ElfAnalyser(elf_file_path=elf_path,
                                   elf_debug_file_path='',
                                   filter_functions=True,
                                   symbol_prefix=ASMSlicerUtils.get_elf_prefix(elf_path),
                                   provided_architecture=self.architecture,
                                   show_progress=self.show_progress,
                                   dump_cfg=dump_cfg,
                                   cfg_dir=cfg_dir)
            try:
                symbols_defined = set()
                symbols_undefined = set()
                elf_associated_objects = set()
                generated_symbols = set()
                for symbol in analyser.elf_data.get_functions():
                    if test_source_files and symbol.associated_object and symbol.associated_object not in test_source_files:
                        continue
                    if symbol.demangled_name == 'main':
                        continue
                    if symbol.associated_object:
                        elf_associated_objects.add(symbol.associated_object)
                    symbols_defined.add(symbol.demangled_name)
                    if symbol.symbol.generated:
                        generated_symbols.add(symbol.demangled_name)
                all_symbols[analyser.elf_base_name] = {
                    'defined': symbols_defined,
                    'undefined': symbols_undefined,
                    'associated_objects': elf_associated_objects,
                    'generated': generated_symbols,
                }
            except Exception as e:
                raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message='loading symbols from elf failed') from e
            finally:
                analyser.cleanup()
                analyser = None
                gc.collect()
        return all_symbols

    def generate_symbol_impacts_test_map(self, test_symbols: dict, release_symbols: dict) -> list:
        symbol_impacts_test_map = []
        for release_elf_name, release_elf_symbols in release_symbols.items():
            for test_elf_name, test_elf_symbols in test_symbols.items():
                shared_symbols = test_elf_symbols['defined'] & release_elf_symbols['defined']
                generated_symbols = test_elf_symbols['generated'].union(release_elf_symbols['generated'])
                if shared_symbols:
                    elf_relation = {}
                    elf_relation['release_elf'] = release_elf_name
                    elf_relation['test_elf'] = test_elf_name
                    elf_relation['common_symbols'] = [sym for sym in shared_symbols if not sym.startswith(SYMBOL_PREFIXES_TO_SKIP) and sym not in generated_symbols]
                    symbol_impacts_test_map.append(elf_relation)
                undefined_test_symbols = test_elf_symbols['undefined'] & release_elf_symbols['defined']
                if undefined_test_symbols:
                    elf_relation = {}
                    elf_relation['release_elf'] = release_elf_name
                    elf_relation['test_elf'] = test_elf_name
                    elf_relation['common_symbols'] = [sym for sym in undefined_test_symbols if not sym.startswith(SYMBOL_PREFIXES_TO_SKIP) and sym not in generated_symbols]
                    symbol_impacts_test_map.append(elf_relation)
        return symbol_impacts_test_map

    @staticmethod
    def parse_junit_xml(file_path: str = ''):
        test_source_files = set()
        try:
            tree = etree.parse(file_path)
            root = tree.getroot()
            for testsuite in root.iter('testsuite'):
                # print('-' * 50)
                # suite_name = testsuite.get('name')
                # total_tests = testsuite.get('tests')
                # failures = testsuite.get('failures')
                # errors = testsuite.get('errors')
                # skipped = testsuite.get('skipped')
                # print(f'suite_name: {suite_name}')
                # print(f'total_tests: {total_tests}')
                # print(f'failures: {failures}')
                # print(f'errors: {errors}')
                # print(f'skipped: {skipped}')
                for testcase in testsuite.iter('testcase'):
                    # print('-' * 30)
                    # test_name = testcase.get('name')
                    # test_class = testcase.get('classname')
                    # test_time = testcase.get('time')
                    test_file = Path(testcase.get('file')).name
                    test_source_files.add(test_file)
                #     failure = testcase.find('failure')
                #     error = testcase.find('error')
                #     print(f'test_name: {test_name}')
                #     print(f'test_class: {test_class}')
                #     print(f'test_time: {test_time}')
                #     print(f'test_file: {test_file}')
                #     if failure:
                #         print(f'failure: {failure.text}')
                #     elif error:
                #         print(f'error: {error.text}')
                #     else:
                #         print('passed')
                #     print('-' * 30)
                # print('-' * 50)
            return test_source_files
        except Exception as e:
            raise ASMSlicerException(error_code=ASMSlicerError.INTERNAL_ERROR, message=f'parsing junit xml failed: {e}') from e

def process(elf_file_path: str,
            elf_debug_file_path: str = '',
            comparing_elf_file_path: str = '',
            comparing_elf_debug_file_path: str = '',
            compare_out: str = '',
            compare_verbose: bool = False,
            output_file_path: str = '',
            blocks_file_path: str = '',
            out_sym_map_file: str = '',
            out_vars_file: str = '',
            out_plot_file: str = '',
            out_elfinfo_file: str = '',
            out_asm_file: str = '',
            dump_cfg: bool = False,
            cfg_dir: str = '',
            deps_info_file: str = '',
            use_angr: bool | None = None,
            filter_functions: bool = False,
            architecture = '',
            map_test_to_symbol: str = '',
            slice_to_cfg: str = '',
            compress_out_csv: bool = False,
            show_progress: bool = False,
            log: logging.Logger = None):
    global logger
    logger = log
    base_elf_analyser = None
    comparing_elf_analyser = None
    bindiff = None
    start_time = time.time()
    try:
        commit_id = utility.git_commit_id(repository_path=os.path.dirname(__file__))
        if commit_id:
            logger.info(f'version: {commit_id}')
        ASMSlicerUtils.setup_other_loggers(internal_loggers_level=logger.level)
        deps_info = ASMSlicerUtils.load_deps_info(deps_info_file)

        if map_test_to_symbol: # test impact mapper
            _ = TestImpactMapper(mtts_config_path=map_test_to_symbol, architecture=architecture, show_progress=show_progress, dump_cfg=dump_cfg, cfg_dir=cfg_dir)
        elif comparing_elf_file_path: # bindiff
            base_elf_analyser = ElfAnalyser(elf_file_path=elf_file_path, elf_debug_file_path=elf_debug_file_path, filter_functions=filter_functions, symbol_prefix=ASMSlicerUtils.get_elf_prefix(elf_file_path), provided_architecture=architecture, compress_out_csv=compress_out_csv, show_progress=show_progress, dump_cfg=dump_cfg, cfg_dir=cfg_dir, use_angr=False)
            comparing_elf_analyser = ElfAnalyser(elf_file_path=comparing_elf_file_path, elf_debug_file_path=comparing_elf_debug_file_path, filter_functions=filter_functions, symbol_prefix=ASMSlicerUtils.get_elf_prefix(comparing_elf_file_path), provided_architecture=architecture, compress_out_csv=compress_out_csv, show_progress=show_progress, dump_cfg=dump_cfg, cfg_dir=cfg_dir, use_angr=False)
            bindiff = Bindiff(base_elf_analyser=base_elf_analyser, comparing_elf_analyser=comparing_elf_analyser, out_dir=compare_out, verbose=compare_verbose)
            bindiff.analyse()
        else: # asmslicer data - symmap, callgraph, slice, vars
            base_elf_analyser = ElfAnalyser(
                elf_file_path=elf_file_path,
                elf_debug_file_path=elf_debug_file_path,
                filter_functions=filter_functions,
                symbol_prefix=ASMSlicerUtils.get_elf_prefix(elf_file_path),
                provided_architecture=architecture,
                compress_out_csv=compress_out_csv,
                use_angr=use_angr,
                show_progress=show_progress,
                dump_cfg=dump_cfg,
                cfg_dir=cfg_dir,
                deps_info=deps_info,
                out_asm_file=out_asm_file,
            )

            # TODO: allow symbol creation without building cfg

            # check if current elf has been used as stub, using symmap file path to determine working dir
            if out_sym_map_file:
                output_dir_path = out_sym_map_file.rsplit('/', 1)[0]
                pregenerated_path = os.path.join(output_dir_path, 'pregenerated', base_elf_analyser.elf_base_name)
                if au.Path.exists(pregenerated_path):
                    logger.info('skipping slicing for current elf since its used as stub')
                    return

            # build elf data
            base_elf_analyser.get_elf_data()

            # elfinfo - generate elfinfo file that contains basic elf information
            if out_elfinfo_file:
                base_elf_analyser.generate_elf_info_file(out_elfinfo_file=out_elfinfo_file)
            # slice to callgraph - postprocessing of tricore slicer data, used only for tricore, does not require call graph or control flow graph to be generated
            if slice_to_cfg:
                base_elf_analyser.slice_to_callgraph(slice_to_cfg, out_sym_map_file)
            # symmap - does not require call graph or control flow graph to be generated
            if out_sym_map_file:
                base_elf_analyser.generate_symmap_file(out_sym_map_file=out_sym_map_file)
            # callgraph - requires callgraph
            if out_plot_file:
                base_elf_analyser.generate_callgraph_file(output_dotfile_path=out_plot_file)
            # fatbin - does require fatbin elf, symmap and callgraph for current fatbin
            if  base_elf_analyser.elffile_info.is_fatbin and au.Path.exists(out_sym_map_file) and au.Path.exists(out_plot_file):
                fatbin_filename = f'{base_elf_analyser.elf_base_name}.fatbin.json'
                fatbin_path = os.path.join(out_sym_map_file.rsplit('/', 1)[0], fatbin_filename)
                base_elf_analyser.generate_fatbin_file(out_fatbin_file=fatbin_path, out_sym_map_file=out_sym_map_file, out_plot_file=out_plot_file)
            # slice - requires control flow graph
            if output_file_path:
                base_elf_analyser.generate_segments_file(output_file_path=output_file_path)
            # blocks - requires control flow graph
            if blocks_file_path:
                base_elf_analyser.generate_blocks_file(blocks_file_path=blocks_file_path)
            # vars - requires control flow graph and angr
            if out_vars_file and base_elf_analyser.elf_angr_project:
                base_elf_analyser.generate_vars_file(out_file=out_vars_file)
    finally:
        if base_elf_analyser:
            base_elf_analyser.cleanup()
            base_elf_analyser = None
        if comparing_elf_analyser:
            comparing_elf_analyser.cleanup()
            comparing_elf_analyser = None
        if bindiff:
            bindiff = None
        end_time = time.time()
        total_time = round((end_time - start_time), 2)
        logger.info(f'asmslicer done in {total_time} seconds')
        gc.collect()

def parse_args():
    parser = argparse.ArgumentParser(prog='slicer')
    parser.add_argument('-e', '--elf', required=True, help='ELF file path')
    # TODO: The debug elf file path should be embedded in .gnu_debuglink section of the elf if the section exists. We could additionally (or exclusively) look for that file.
    parser.add_argument('-d', '--elf-debug', required=False, help='ELF.debug file path, which holds .symtab and other debug sections data')
    parser.add_argument('-ce', '--comparing-elf', required=False, help='Path to comparing elf, used for bindiff')
    parser.add_argument('-cd', '--comparing-elf-debug', required=False, help='Path to comparing elf debug file, used for bindiff')
    parser.add_argument('-co', '--compare-out', required=False, help='Output directory for files created by bindiff')
    parser.add_argument('-cv', '--compare-verbose', action='store_true', default=False, required=False, help='Dump verbose info for bindiff. If false, dumps only diff summary file.')
    parser.add_argument('--slice', required=False, help='Slice ELF\'s assembly instructions into segments. Dump data to \'csv\' or \'json\' format.', default='')
    parser.add_argument('--blocks', required=False, help='Slice ELF\'s assembly instructions into blocks.', default='')
    parser.add_argument('--plot', required=False, help='Plot CFG in either .png or .dot file.', default='')
    parser.add_argument('--elfinfo', required=False, help='Generate .elfinfo.csv file with basic elf information.', default='')
    parser.add_argument('--dump-sym-map', required=False, help='Dump in provided map file, all blocks of all symbols. Data dumped is: symbol name [+offset], block start address and block size.', default='')
    parser.add_argument('--dump-symbols', help='Output CSV file to dump symbols in.', type=str, default='')
    parser.add_argument('--dump-vars', help='Output CSV file to dump global and static symbols and functions that access them.', type=str, default='')
    parser.add_argument('--dump-asm', help='Output ASM file.', type=str, default='')
    parser.add_argument('--dump-cfg', action='store_true', help='Pickle and dump generated CFG in elfs\' dirname. This option alone won\'t trigger CFG generation, it must be additionally requested. Works only for angr generated CFG. If provided and dumped CFG file already exists, it will be regenerated.', default=False)
    parser.add_argument('--cfg-dir', help='Directory where to [do lookup of/dump] generated CFGs. Default: elf\'s directory.', type=str, default='')
    parser.add_argument('--filter-functions', action='store_true', default=False)
    parser.add_argument('--architecture', required=False, help='Machine architecture')
    parser.add_argument('--deps-info', required=False, type=str, default='', help='JSON file containing symbol dependency info')
    parser.add_argument('--use-angr', action=argparse.BooleanOptionalAction, default=None, help='Use angr for processing')
    parser.add_argument('-l', '--log', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], default='INFO', help='Logging level', type=lambda s: s.upper())
    # example mtts config
    # {
    #     "test_execution_reports_location": "/build/test-report-release",
    #     "test_elfs_location": "/build/test-release",
    #     "release_elfs_location":"/build/elf-release"
    # }
    #
    parser.add_argument('-mtts', '--map-test-to-symbol', help='Path to mtts json config file.', type=str, default='')
    # for now, tricore slicer csv layout is supported:
    # s2.container,r.cyc,r.from_addr,r.to_addr,r.asm,s1.name,s2.name
    parser.add_argument('-stcfg', '--slice-to-cfg', help='Path to slice data in csv format.', type=str, default='')
    parser.add_argument('-coc', '--compress-out-csv', help='Enables compressed csv output for slice data, symbol maps and var list', action='store_true', default=False)
    args = parser.parse_args()

    def validate_extensions(path: str, valid_extensions: list[str]):
        return any(path.lower().endswith(extension) for extension in valid_extensions)

    if args.slice and not validate_extensions(path=args.slice, valid_extensions=['.csv', '.json']):
        parser.error('[--slice] file path is supporting only \'csv\' and \'json\' formats')

    if args.plot and not validate_extensions(path=args.plot, valid_extensions=['.dot', '.png']):
        parser.error('[--plot] file is supported in only `dot` and `csv` formats')

    return args

if __name__ == '__main__':
    main_args = parse_args()
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(funcName)s | %(lineno)d | %(message)s',
                        datefmt="%H:%M:%S", force=True)
    logger = logging.getLogger('slicer')
    logger.setLevel(main_args.log.upper())

    try:
        process(elf_file_path=main_args.elf,
                elf_debug_file_path=main_args.elf_debug,
                comparing_elf_file_path=main_args.comparing_elf,
                comparing_elf_debug_file_path=main_args.comparing_elf_debug,
                compare_out=main_args.compare_out,
                compare_verbose=main_args.compare_verbose,
                filter_functions=main_args.filter_functions,
                output_file_path=main_args.slice,
                blocks_file_path=main_args.blocks,
                out_sym_map_file=main_args.dump_sym_map,
                out_vars_file=main_args.dump_vars,
                out_plot_file=main_args.plot,
                out_elfinfo_file=main_args.elfinfo,
                out_asm_file=main_args.dump_asm,
                architecture=main_args.architecture,
                map_test_to_symbol=main_args.map_test_to_symbol,
                slice_to_cfg=main_args.slice_to_cfg,
                compress_out_csv=main_args.compress_out_csv,
                dump_cfg=main_args.dump_cfg,
                cfg_dir=main_args.cfg_dir,
                deps_info_file=main_args.deps_info,
                log=logger)
    except ASMSlicerException as e:
        logger.error(e.message)
        logger.debug('Traceback: %s', traceback.format_exc())
        sys.exit(e.error_code)
    except Exception as e:
        logger.error(e)
        logger.debug('Traceback: %s', traceback.format_exc())
        sys.exit(ASMSlicerError.UNDEFINED_ERROR)
    sys.exit(0)
