import logging
import os
import re
import pickle
import struct
import subprocess
import tempfile
from pathlib import PurePosixPath, PureWindowsPath

import capstone
import smart_open as so
import xxhash
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection

from . import aws_utils as au

# pylint: disable=broad-exception-caught
# pylint: disable=missing-module-docstring
# pylint: disable=too-many-return-statements
# pylint: disable=too-many-branches

VER_FLG_BASE = 0x1
VER_FLG_WEAK = 0x2
VER_NDX_LOCAL = 0
VER_NDX_GLOBAL = 1

_is_rust_cache: dict[str, bool] = {}

def get_file_lines(filename: str, strip: bool = True, skip_empty: bool = True):
    with so.open(filename, 'r', encoding='utf-8') as fh:
        while True:
            line = fh.readline()
            if not line:
                break
            if strip:
                line = line.strip()
            if skip_empty and not line:
                continue
            yield line


def hash_file_xxh128(file_path: str) -> str:
    chunk_size = 0x10000
    hasher = xxhash.xxh128()
    with so.open(file_path, 'rb') as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


def hash_data_xxh128(data) -> str:
    return xxhash.xxh128(data).hexdigest()


def is_elf_data(data: bytes) -> bool:
    # ELF magic number: 0x7f, 'E', 'L', 'F'
    return data and len(data) >= 4 and data[:4] == b'\x7fELF'


def is_elf_file(file: au.Uri|au.LocalFile|au.S3File) -> bool:
    if not file:
        return False
    f_str = file
    if isinstance(file, au.S3File):
        f_str = au.to_uri(file)
    if isinstance(file, au.LocalFile):
        f_str = file.path
    if au.Path.is_file(file):
        try:
            with so.open(f_str, 'rb') as f:
                return is_elf_data(f.read(4))
        except OSError:
            pass
    return False


def is_pic(elf: ELFFile):
    if elf.header['e_type'] != 'ET_DYN':
        return False
    seg = next((x for x in elf.iter_segments() if x['p_type'] == 'PT_LOAD'), None)
    if seg is None:
        return False
    if seg['p_vaddr'] != 0:
        return False
    for sec in elf.iter_sections():
        if sec.name == '.got':
            return True
        if sec.header['sh_type'] in {'SHT_REL', 'SHT_RELA'}:
            return True
    return False


def get_cache_dir(elf_path: str = None):
    if elf_path and os.path.isfile(elf_path):
        elf_dir = os.path.dirname(elf_path)
        cache_dir = os.path.join(elf_dir, '.cache')
        if os.path.isdir(cache_dir):
            return cache_dir
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cache_dir = os.path.join(script_dir, '.cache')
    if os.path.isdir(cache_dir):
        return cache_dir
    return os.path.expanduser('~/.cache/tdp')


def unquote(s: str) -> str:
    if len(s) > 1 and s.startswith('"') and s.endswith('"'):
        return s[1:-1]
    return s


def load_from_pickle(file: str, logger: logging.Logger = None):
    if not file or not au.Path.is_file(file):
        return None
    try:
        with so.open(file, 'rb') as file:
            return pickle.load(file)
    except Exception as ex:
        if logger:
            logger.error(f"Error loading {file} from pickle. Msg: {ex}")
        return None


def pickle_and_dump(file: str, obj):
    with so.open(file, 'wb') as f:
        f.write(pickle.dumps(obj, -1))


def use_gen_symbols(is_elf_stripped: bool, use_angr: bool):
    return is_elf_stripped and use_angr


def get_elf_info(file_path: str):
    def _get_elf_info(local_path: str):
        try:
            result = subprocess.run(['file', local_path], capture_output=True, text=True, check=True)
            output = result.stdout
            is_elf = ': ELF ' in output and ' stripped' in output
            is_stripped = is_elf and ", stripped" in output
            return is_elf, is_stripped
        except subprocess.CalledProcessError as ex:
            print(f'file command failed: {ex}')
            return False, False
    if au.Path.is_s3(file_path):
        data = None
        with so.open(file_path, "rb") as f:
            data = f.read()
        with tempfile.NamedTemporaryFile(delete=True) as tmp:
            tmp.write(data)
            return _get_elf_info(tmp.name)
    return _get_elf_info(file_path)


def gen_cfg_file_slim(elf_hash: str, use_gen_syms: bool, filter_functions: bool):
    return f"{hash_data_xxh128(f'{elf_hash}:{not use_gen_syms and filter_functions}')}.cfg"


def gen_cfg_file(elf_path: str):
    _, is_stripped = get_elf_info(elf_path)
    return gen_cfg_file_slim(elf_hash=hash_file_xxh128(elf_path),
                                use_gen_syms=use_gen_symbols(is_stripped, use_angr=True),
                                filter_functions=False)


def gen_slicer_file(elf_path: str, architecture: str, filter_functions: bool):
    h = hash_file_xxh128(elf_path)
    return hash_data_xxh128(f'{h}:{architecture}:{filter_functions}')

def is_absolute(path: str) -> bool:
    return PurePosixPath(path).is_absolute() or PureWindowsPath(path).is_absolute()


def git_commit_id(repository_path=".") -> str|None:
    git_path = os.path.join(repository_path, '.git')
    head_path = os.path.join(git_path, "HEAD")
    if not os.path.exists(head_path):
        return None
    try:
        with open(head_path, "r", encoding="utf-8") as file:
            content = file.read().strip()
        commit_id = None
        if content.startswith("ref:"):
            # content example "ref => ref: refs/heads/main"
            ref_path = os.path.join(git_path, content.split("ref:", 1)[1].strip())
            if os.path.exists(ref_path):
                with open(ref_path, "r", encoding="utf-8") as file:
                    commit_id = file.read().strip()[:7]
        else:
            # detached HEAD — head is the commit id
            commit_id = content[:7]
        return commit_id
    except Exception:
        return None


def get_arch_and_mode(elf: ELFFile, architecture: str = '') -> tuple[int, int, bool, str]:
    cs_arch = -1
    cs_mode = -1
    skipdata = False
    error_str = None
    machine = elf.header['e_machine']

    if machine == 'EM_ARM':
        cs_arch = capstone.CS_ARCH_ARM
        cs_mode = capstone.CS_MODE_ARM
        if architecture and architecture.lower() == 'cortexm'.lower():
            cs_mode |= capstone.CS_MODE_LITTLE_ENDIAN | capstone.CS_MODE_THUMB | capstone.CS_MODE_MCLASS
            skipdata = True
    elif machine == 'EM_AARCH64':
        cs_arch = capstone.CS_ARCH_ARM64
        cs_mode = capstone.CS_MODE_ARM
    elif machine == 'EM_X86_64':
        cs_arch = capstone.CS_ARCH_X86
        cs_mode = capstone.CS_MODE_64
    elif machine == 'EM_TRICORE':
        tricore_mode_map: dict[int, int] = {
            0x80000000: capstone.CS_MODE_TRICORE_110,  # EF_TRICORE_V1_1
            0x40000000: capstone.CS_MODE_TRICORE_120,  # EF_TRICORE_V1_2
            0x20000000: capstone.CS_MODE_TRICORE_130,  # EF_TRICORE_V1_3
            0x00800000: capstone.CS_MODE_TRICORE_131,  # EF_TRICORE_V1_3_1
            0x00400000: capstone.CS_MODE_TRICORE_160,  # EF_TRICORE_V1_6
            0x00200000: capstone.CS_MODE_TRICORE_161,  # EF_TRICORE_V1_6_1
            0x00100000: capstone.CS_MODE_TRICORE_162,  # EF_TRICORE_V1_6_2
        }
        e_flags = elf.header["e_flags"]
        if e_flags not in tricore_mode_map:
            error_str = f'unsupported tricore mode. flags: {e_flags}'
        else:
            cs_mode = tricore_mode_map[e_flags]
            cs_arch = capstone.CS_ARCH_TRICORE
            skipdata = True
    elif machine == 'EM_PPC':
        cs_arch = capstone.CS_ARCH_PPC
        cs_mode = capstone.CS_MODE_32 | capstone.CS_MODE_BIG_ENDIAN
    elif machine == 'EM_PPC64':
        cs_arch = capstone.CS_ARCH_PPC
        cs_mode = capstone.CS_MODE_64 | capstone.CS_MODE_BIG_ENDIAN
    else:
        error_str = f'unsupported architecture: {machine}'

    return cs_arch, cs_mode, skipdata, error_str


def _read_versym_array(elf: ELFFile, versym_sec):
    """ return list[int] of versym entries (uint16) or [] if missing. """
    if not versym_sec:
        return []
    data = versym_sec.data()
    if not data:
        return []
    endian = '<' if elf.little_endian else '>'
    count = len(data) // 2
    fmt = f"{endian}{count}H"
    return list(struct.unpack(fmt, data))


def get_dynsym_with_versions(elf: ELFFile) -> dict[int, list[str]]:
    """
    return mapping address (st_value) -> list of distinct symbol names.
    each list contains the plain symbol name and any versioned variants
    (e.g. "SSL_ctrl@OPENSSL_3.0.0" or "SSL_ctrl@@OPENSSL_3.0.0").
    """
    dynsym = elf.get_section_by_name('.dynsym')
    if not dynsym:
        return {}

    # read versym array (SHT_GNU_versym)
    versym = _read_versym_array(elf, elf.get_section_by_name('.gnu.version'))

    # parse .gnu.version_d (definitions)
    verdefs = {}          # map verdef index -> first verdaux name
    verdef_names = {}     # map verdef index -> list of all verdaux names
    default_defs = set()  # verdef indices that are "base/default"
    verdef_sec = elf.get_section_by_name('.gnu.version_d')
    if verdef_sec:
        for verdef, verdaux_iter in verdef_sec.iter_versions():
            ndx = verdef['vd_ndx']
            flags = verdef['vd_flags']
            names = []
            for verdaux in verdaux_iter:
                names.append(verdaux.name)
            if names:
                verdefs[ndx] = names[0]  # keep first name for compatibility
                verdef_names[ndx] = names
            # default version: not BASE and not WEAK
            if not flags & (VER_FLG_BASE | VER_FLG_WEAK):
                default_defs.add(ndx)

    # parse .gnu.version_r (requirements)
    verneeds = {}  # map vna_other -> name
    verneed_sec = elf.get_section_by_name('.gnu.version_r')
    if verneed_sec:
        for _verneed, vernaux_iter in verneed_sec.iter_versions():
            for vernaux in vernaux_iter:
                verneeds[vernaux['vna_other']] = vernaux.name

    addr_to_names = {}

    for idx, sym in enumerate(dynsym.iter_symbols()):
        name = sym.name
        if not name:
            continue

        addr = int(sym['st_value'])
        names = {name}

        if idx < len(versym):
            vndx = versym[idx]
            if vndx in (VER_NDX_LOCAL, VER_NDX_GLOBAL):
                pass  # unversioned
            elif vndx in verdefs:
                # only add the newest version if this is a default version
                if vndx in default_defs:
                    if vndx in verdef_names:
                        vername = verdef_names[vndx][0]  # use first name (newest version)
                    else:
                        vername = verdefs[vndx]
                    names.add(f"{name}@@{vername}")
            elif vndx in verneeds:
                vername = verneeds[vndx]
                # extract vernaux flags to identify default versions
                verneed_sec = elf.get_section_by_name('.gnu.version_r')
                vernaux_flags = 0
                for _verneed, vernaux_iter in verneed_sec.iter_versions():
                    for vernaux in vernaux_iter:
                        if vernaux['vna_other'] == vndx:
                            vernaux_flags = vernaux['vna_flags']
                            break
                if vernaux_flags & VER_FLG_WEAK:
                    names.add(f"{name}@{vername}")
                else:
                    names.add(f"{name}@@{vername}")
            else:
                # unknown index - skip
                pass

        addr_to_names.setdefault(addr, set()).update(names)

    return {addr: sorted(list(nset)) for addr, nset in addr_to_names.items()}

def extract_symbol_simple_name(demangled_symbol_name: str = '') -> tuple[str, str, str]:
    OPEN_BRACKETS = ['(', '[', '{', '<']
    CLOSE_BRACKETS = [')', ']', '}', '>']
    OPERATOR = 'operator'
    def find_next_bracket(name: str = '', position: int = -1) -> int:
        if name and position:
            current_name_substring = name[position:]
            if current_name_substring:
                if current_name_substring.startswith(OPERATOR):
                    for index, char in enumerate(current_name_substring):
                        current_string_length = len(current_name_substring)
                        previous_character_index = index - 1
                        first_brace_index = index + 1
                        second_brace_index = first_brace_index + 1
                        if char in OPEN_BRACKETS:
                            if current_string_length > first_brace_index and current_name_substring[first_brace_index] in CLOSE_BRACKETS:
                                return position + second_brace_index
                            elif current_string_length > first_brace_index and current_name_substring[first_brace_index] in OPEN_BRACKETS and char == current_name_substring[first_brace_index]:
                                return position + second_brace_index
                            elif current_string_length > previous_character_index and not current_name_substring[previous_character_index].isalnum():
                                return position + index
                            else:
                                return position + first_brace_index
                        elif char in CLOSE_BRACKETS:
                            if current_string_length > first_brace_index and current_name_substring[first_brace_index] in CLOSE_BRACKETS and char == current_name_substring[first_brace_index]:
                                return position + second_brace_index
                            else:
                                return position + first_brace_index
                else:
                    for index, char in enumerate(current_name_substring):
                        if char in OPEN_BRACKETS + CLOSE_BRACKETS:
                            return position + index
        return len(name)
    symbol_return_type = ''
    symbol_namespace = ''
    symbol_simple_name = ''
    if demangled_symbol_name:
        brace_counter = 0
        last_valid_scope_position_start = -1
        last_valid_scope_position_end = -1
        last_valid_space = 0
        # space_character_found = False
        for index, char in enumerate(demangled_symbol_name):
            if char in OPEN_BRACKETS:
                brace_counter += 1
            elif char in CLOSE_BRACKETS:
                brace_counter -= 1
            if brace_counter == 0:
                if char == ':' and demangled_symbol_name[index + 1] == ':':
                    last_valid_scope_position_start = index + 2
                    last_valid_scope_position_end = find_next_bracket(demangled_symbol_name, last_valid_scope_position_start)
                    symbol_namespace = demangled_symbol_name[last_valid_space:last_valid_scope_position_start]
                    symbol_simple_name = demangled_symbol_name[last_valid_scope_position_start:last_valid_scope_position_end]
                # elif char.isspace() and not space_character_found:
                #     space_character_found = True
                #     symbol_return_type = demangled_symbol_name[0:index]
                #     last_valid_space = index + 1
        if not symbol_simple_name:
            symbol_return_type = ''
            symbol_namespace = ''
            last_valid_scope_position_start = 0
            last_valid_scope_position_end = find_next_bracket(demangled_symbol_name, last_valid_scope_position_start)
            symbol_simple_name = demangled_symbol_name[last_valid_scope_position_start:last_valid_scope_position_end]
            if not symbol_simple_name:
                symbol_simple_name = demangled_symbol_name
    for idx, bracket in enumerate(OPEN_BRACKETS):
        if bracket in symbol_simple_name:
            new_simple_name = symbol_simple_name.split(bracket)[0]
            if not new_simple_name:
                close_bracket = CLOSE_BRACKETS[idx]
                close_idx = symbol_simple_name.find(close_bracket)
                if close_idx != -1 and (close_idx + 1) < len(symbol_simple_name):
                    new_simple_name = symbol_simple_name[close_idx + 1:]
            symbol_simple_name = new_simple_name
    if not symbol_simple_name and demangled_symbol_name:
        # Handle cases like Rust closures where the name tail is "{closure#0}" or "{{closure}}"
        brace_match = re.search(r'\{\{([^{}]+)\}\}\s*$', demangled_symbol_name)
        if not brace_match:
            brace_match = re.search(r'\{([^{}]+)\}\s*$', demangled_symbol_name)
        if brace_match:
            symbol_simple_name = brace_match.group(1).strip()
        if not symbol_simple_name:
            # Last resort: use the full demangled name to avoid empty short names.
            symbol_simple_name = demangled_symbol_name
    return symbol_return_type, symbol_namespace, symbol_simple_name

def _is_rust_elf_impl(elf: ELFFile) -> bool:
    try:
        if elf.has_dwarf_info():
            dwarf = elf.get_dwarf_info()
            for cu in dwarf.iter_CUs():
                top = cu.get_top_DIE()
                prod_attr = top.attributes.get("DW_AT_producer")
                if not prod_attr:
                    continue
                val = prod_attr.value
                if isinstance(val, bytes):
                    val = val.decode(errors="ignore")
                if "rustc" in val.lower():
                    return True
    except Exception:
        pass

    # rust runtime functions
    rx_runtime = re.compile(r".*(__rust_alloc|__rust_dealloc|__rust_realloc|__rust_alloc_error_handler|"
                            r"rust_eh_personality|rust_begin_unwind|rust_panic|rust_oom)$")

    for sec in elf.iter_sections():
        if not isinstance(sec, SymbolTableSection):
            continue
        for sym in sec.iter_symbols():
            name = sym.name or ""
            if not name:
                continue
            if rx_runtime.match(name):
                return True

    return False

def is_rust_elf(elf: ELFFile) -> bool:
    path = getattr(elf.stream, "name", None)
    if path and path in _is_rust_cache:
        return _is_rust_cache[path]
    result = _is_rust_elf_impl(elf)
    if path:
        _is_rust_cache[path] = result
    return result
