"""
DWARF info reader
"""

import bisect
import dataclasses
import logging
import os
import time
from typing import Callable

import elftools.dwarf.die
import elftools.dwarf.dwarfinfo
from elftools.common.exceptions import ELFError
from elftools.dwarf.descriptions import describe_form_class
from elftools.dwarf.dwarfinfo import DWARFInfo
from elftools.elf.elffile import ELFFile

from . import utility

PROGRAM_NAME = os.path.splitext(os.path.basename(os.path.abspath(__file__)))[0]

logger = logging.getLogger(PROGRAM_NAME)
logger.setLevel(level=logging.INFO)

@dataclasses.dataclass(frozen=True)
class LineEntry:
    address: int
    filename: str
    line_number: int
    column_number: int

@dataclasses.dataclass(frozen=True)
class FunctionInfo:
    name: str
    beg: int
    end: int

def find_line_entry(address: int, entries: list[LineEntry], functions: list[FunctionInfo] = None, function_entry_map: dict[int, list[int]] = None) -> LineEntry | None:
    if not entries:
        return None
    if functions:
        func, func_idx = find_function_for_address(address, functions)
        if not func:
            return None
        # Filter entries within function range
        func_idx_entries = function_entry_map[func_idx]
        if not func_idx_entries:
            return None
        func_entries = [entries[entry_idx] for entry_idx in func_idx_entries]
        index = bisect.bisect_right(func_entries, address, key=lambda x: x.address)
        return func_entries[index - 1] if index > 0 else None
    index = bisect.bisect_right(entries, address, key=lambda x: x.address)
    return entries[index - 1] if index > 0 else None

def find_function_for_address(address: int, functions: list[FunctionInfo]) -> tuple[FunctionInfo, int] | tuple[None, None]:
    left, right = 0, len(functions) - 1
    while left <= right:
        mid = (left + right) // 2
        f = functions[mid]
        if f.beg <= address < f.end:
            return f, mid
        elif address < f.beg:
            right = mid - 1
        else:
            left = mid + 1
    return None, None

class DWARFReader:
    def __init__(self, filename: str):
        self.filename = filename
        self._functions: list[FunctionInfo] | None = None
        self._line_entries: list[LineEntry] | None = None

    def get_line_entries(self) -> list[LineEntry]:
        if self._line_entries is None:
            self._line_entries = []
            def callback(dwarf_info: DWARFInfo):
                self._line_entries = DWARFReader._load_line_entries(dwarf_info, self.filename)
            DWARFReader._initialize(filename=self.filename, callback=callback)
        return self._line_entries

    def get_functions(self) -> list[FunctionInfo]:
        if self._functions is None:
            self._functions = []
            def callback(dwarf_info: DWARFInfo):
                self._functions = self._load_functions(dwarf_info)
            DWARFReader._initialize(filename=self.filename, callback=callback)
        return self._functions

    @staticmethod
    def has_dwarf_info(filename: str) -> bool:
        return DWARFReader._initialize(filename=filename, callback=lambda _: None, silent=True)

    @staticmethod
    def _initialize(filename: str, callback: Callable[[DWARFInfo], None], silent: bool = False) -> bool:
        if not os.path.isfile(filename):
            if not silent:
                logger.warning('file: %s. not found', filename)
            return False
        with open(filename, 'rb') as fh:
            try:
                elf = ELFFile(fh)
                if not elf.has_dwarf_info():
                    if not silent:
                        logger.warning('file: %s. no dwarf info', filename)
                    return False
                callback(elf.get_dwarf_info())
                return True
            except ELFError as ex:
                if not silent:
                    logger.warning('file: %s. elf error: %s', filename, ex)
        return False

    @staticmethod
    def _load_line_entries(dwarf_info: elftools.dwarf.dwarfinfo.DWARFInfo, elf_path: str) -> list[LineEntry]:
        logger.debug('loading line entries...')
        start_time = time.perf_counter()

        added_addresses: set[int] = set()
        line_entries: list[LineEntry] = []

        for cu in dwarf_info.iter_CUs():
            line_program = dwarf_info.line_program_for_CU(cu)
            if line_program is None:
                continue
            file_entries = line_program['file_entry']
            directories = line_program['include_directory']
            for entry in line_program.get_entries():
                if entry.state is None:
                    continue
                address = entry.state.address
                if address <= 0:
                    continue
                if address in added_addresses:
                    continue
                try:
                    cu_dwarf_version = cu.structs.dwarf_version
                    # for dwarf version < 5, file/directory index is off by 1, and should be adjusted
                    if cu_dwarf_version < 5:
                        file_index = entry.state.file - 1
                        file_entry = file_entries[file_index]
                        dir_index = file_entry.dir_index - 1
                    else:
                        file_index = entry.state.file
                        file_entry = file_entries[file_index]
                        dir_index = file_entry.dir_index
                    filename = file_entry.name.decode('utf-8')
                    added_addresses.add(address)
                    if directories and dir_index is not None:
                        if not (cu_dwarf_version == 5 and dir_index == 0):
                            directory = directories[dir_index].decode('utf-8')
                            # check if path is relative or absolute
                            if not utility.is_absolute(directory):
                                directory = os.path.abspath(os.path.join(os.path.dirname(elf_path), directory))
                            filename = os.path.join(directory, filename)
                    filename = filename.replace('\\', '/')
                    line_entry = LineEntry(
                        address=address,
                        filename=filename,
                        line_number=entry.state.line,
                        column_number=entry.state.column)
                    line_entries.append(line_entry)
                    # print(f'dwarf info | instruction address: {hex(address)} file: {filename} line: {entry.state.line} column: {entry.state.column}')
                except Exception as e:
                    logger.warning(f'retreiving dwarf info failed: {e}')

        line_entries.sort(key=lambda x: x.address)
        elapsed_time = time.perf_counter() - start_time
        logger.info('line entries: %d. time: %.2f sec', len(line_entries), elapsed_time)
        return line_entries

    @staticmethod
    def _load_functions(dwarf_info: elftools.dwarf.dwarfinfo.DWARFInfo) -> list[FunctionInfo]:
        logger.info('loading functions...')
        start_time = time.perf_counter()

        added_addresses: set[int] = set()
        functions: list[FunctionInfo] = []

        for cu in dwarf_info.iter_CUs():
            for die in cu.iter_DIEs():
                if die.tag != 'DW_TAG_subprogram':
                    continue

                # Ensure the DIE has address attributes and it is not a declaration
                if 'DW_AT_low_pc' not in die.attributes:
                    continue
                if 'DW_AT_high_pc' not in die.attributes:
                    continue
                if 'DW_AT_declaration' in die.attributes and die.attributes['DW_AT_declaration'].value != 0:
                    continue

                low_pc = die.attributes['DW_AT_low_pc'].value
                if low_pc == 0:
                    continue

                # DWARF v4 in section 2.17 describes how to interpret the DW_AT_high_pc attribute
                # based on the class of its form.
                # For class 'address' it's taken as an absolute address (similarly to DW_AT_low_pc)
                # For class 'constant', it's an offset from DW_AT_low_pc
                high_pc_attr = die.attributes['DW_AT_high_pc']
                high_pc_attr_class = describe_form_class(high_pc_attr.form)
                if high_pc_attr_class == 'address':
                    high_pc = high_pc_attr.value
                elif high_pc_attr_class == 'constant':
                    high_pc = low_pc + high_pc_attr.value
                else:
                    print('Error: invalid DW_AT_high_pc class:', high_pc_attr_class)
                    continue

                if low_pc >= high_pc:
                    # This should not happen
                    print(f'Error: low: {low_pc}. high: {high_pc}')
                    continue

                name = DWARFReader._get_referenced_name(die)
                if not name:
                    print(f'Error: low: {low_pc}. high: {high_pc}. no name')
                    continue  # Skip unnamed functions

                address = low_pc
                if address in added_addresses:
                    continue

                added_addresses.add(address)
                functions.append(FunctionInfo(name=name, beg=low_pc, end=high_pc))

        functions.sort(key=lambda x: x.beg)
        elapsed_time = time.perf_counter() - start_time
        logger.info('functions: %d. time: %.2f sec', len(functions), elapsed_time)
        return functions

    @staticmethod
    def _get_referenced_name(die: elftools.dwarf.die.DIE) -> str:
        if 'DW_AT_linkage_name' in die.attributes:
            return die.attributes['DW_AT_linkage_name'].value.decode('utf-8')
            # Check for MIPS linkage name (older attribute, less common)
        if 'DW_AT_MIPS_linkage_name' in die.attributes:
            return die.attributes['DW_AT_MIPS_linkage_name'].value.decode('utf-8')
            # Follow reference to abstract origin (e.g., for inline functions)
        if 'DW_AT_abstract_origin' in die.attributes:
            ref_die = die.get_DIE_from_attribute('DW_AT_abstract_origin')
            return DWARFReader._get_referenced_name(ref_die)
            # Follow reference to specification (e.g., for inherited functions)
        if 'DW_AT_specification' in die.attributes:
            ref_die = die.get_DIE_from_attribute('DW_AT_specification')
            return DWARFReader._get_referenced_name(ref_die)
            # Use the basic name attribute as a fallback
        if 'DW_AT_name' in die.attributes:
            return die.attributes['DW_AT_name'].value.decode('utf-8')
        return ''
