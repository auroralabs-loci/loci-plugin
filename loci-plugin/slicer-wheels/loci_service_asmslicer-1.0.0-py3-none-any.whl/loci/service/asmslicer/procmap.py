import dataclasses
import logging
import os.path
import re
import sys

import smart_open as so

from . import aws_utils as au
from .utility import get_file_lines

missing_elfs = dict()
logger: logging.Logger

@dataclasses.dataclass
class MappingEntry:
    mi_vaddr: str
    ri_flags: str
    mi_flags: str
    mi_pte_prot: str
    mi_prot: str
    ri_prot: str
    ri_maxprot: str
    mi_paddr: str
    mi_hwattr: str
    mi_pgsize: str
    mi_sharecnt: str
    dev: str
    ino: str
    ri_offset: str
    object_name: str


@dataclasses.dataclass
class PMapEntry:
    vaddr: str
    size: str
    flags: str
    prot: str
    maxprot: str
    dev: str
    ino: str
    offset: str
    rsv: str
    guardsize: str
    refcnt: str
    mapcnt: str
    path: str


@dataclasses.dataclass
class RecordEntry:
    cycle_information_flags: str
    data_byte_enable_mask: str
    cpu_specific_information: str
    core_number: str
    space_id: str
    address: str
    data: str
    timestamp: str
    branching_instr: str
    cycle_details: str
    symbol: str
    is_entry: str
    is_context_switch: str


@dataclasses.dataclass
class TaskEntry:
    magic: str
    pid: int
    space_id: int
    thr: int
    name: str


@dataclasses.dataclass
class ProcessResult:
    file_magic_map: dict[str, set[str]]
    referenced_binaries: set[str]


class ProcData:
    def __init__(self, pid: int, space_id: int, magic: str, command: str, filename: str):
        self.pid: int = pid
        self.space_id: int = space_id
        self.magic: str = magic
        self.command: str = command
        self.filename: str = filename
        self.mappings: list[MappingEntry] = []
        self.pmap_entries: list[PMapEntry] = []
        self.address_ranges: list[tuple[int, int]] = []


def read_tasks_file(filename: str):
    tasks = []
    line_num = 0
    for line in get_file_lines(filename):
        tokens = line.split('|')
        line_num += 1
        if len(tokens) != 5:
            logger.error(f'invalid tasks line: {line}')
            sys.exit(1)
        if line_num == 1:
            continue
        tasks.append(TaskEntry(
            magic=tokens[0].strip().rstrip('*'),
            pid=int(tokens[1].strip().rstrip('.')),
            space_id=int(tokens[2].strip(), base=16),
            thr=int(tokens[3].strip().rstrip('.')),
            name=tokens[4].strip()
        ))
    return tasks


def parse_pmap(data: dict[int, ProcData], filename: str):
    with so.open(filename, encoding='utf-8') as fh:
        pid: int = -1
        while True:
            line = fh.readline()
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            if line.startswith('PID:'):
                pid = int(line[4:].strip())
                continue
            tokens = line.split(',')
            if len(tokens) != 13:
                logger.error(f'invalid tokens. pid: {pid}. tokens: {line}')
                sys.exit(1)
            if tokens[0] == 'vaddr':
                continue
            entry = PMapEntry(
                vaddr=tokens[0].strip(),
                size = tokens[1].strip(),
                flags = tokens[2].strip(),
                prot = tokens[3].strip(),
                maxprot = tokens[4].strip(),
                dev = tokens[5].strip(),
                ino = tokens[6].strip(),
                offset = tokens[7].strip(),
                rsv = tokens[8].strip(),
                guardsize = tokens[9].strip(),
                refcnt = tokens[10].strip(),
                mapcnt = tokens[11].strip(),
                path=tokens[12].strip())
            if pid not in data:
                logger.error(f'unknown pid: {pid}')
                sys.exit(1)
            data[pid].pmap_entries.append(entry)


def parse_mappings(data: dict[int, ProcData], filename: str):
    with so.open(filename, encoding='utf-8') as fh:
        pid: int = -1
        while True:
            line = fh.readline()
            if not line:
                break
            line = line.strip()
            if not line:
                continue
            if line.startswith('PID:'):
                pid = int(line[4:].strip())
                continue
            tokens = line.split(',')
            if len(tokens) != 15:
                logger.error(f'invalid tokens. pid: {pid}. tokens: {line}')
                sys.exit(1)
            if tokens[0] == 'mi_vaddr':
                continue
            entry = MappingEntry(
                mi_vaddr=tokens[0],
                ri_flags=tokens[1],
                mi_flags=tokens[2],
                mi_pte_prot=tokens[3],
                mi_prot=tokens[4],
                ri_prot=tokens[5],
                ri_maxprot=tokens[6],
                mi_paddr=tokens[7],
                mi_hwattr=tokens[8],
                mi_pgsize=tokens[9],
                mi_sharecnt=tokens[10],
                dev=tokens[11],
                ino=tokens[12],
                ri_offset=tokens[13],
                object_name=tokens[14])
            if pid not in data:
                logger.error(f'unknown pid: {pid}')
                sys.exit(1)
            data[pid].mappings.append(entry)


def parse_address_ranges(data: dict[int, ProcData]):
    for pid in data.keys():
        address_ranges = get_pid_address_ranges(pid, data)
        data[pid].address_ranges = merge_address_ranges(address_ranges)


def get_pid_address_ranges(pid: int, data: dict[int, ProcData]) -> list[tuple[int,int]]:
    if pid not in data:
        logger.warning(f'pid not in data: {pid}')
        return []
    ranges = []
    pid_data = data[pid]
    for e in pid_data.pmap_entries:
        if e.path.endswith(pid_data.filename):
            beg_addr = int(e.vaddr, base=16)
            end_addr = beg_addr + int(e.size, base=16)
            ranges.append((beg_addr, end_addr))
    return ranges


def get_mapped_address_ranges(mappings: list[MappingEntry]) -> list[tuple[int,int]]:
    ranges = []
    for m in mappings:
        b = int(m.mi_paddr, base=16)
        p = int(m.mi_pgsize, base=16)
        e = b + p
        ranges.append((b, e))
    return ranges


def sort_address_ranges(ranges: list[tuple[int,int]]):
    return sorted(ranges, key=lambda x: x[0])


def merge_address_ranges(ranges: list[tuple[int,int]]):
    if not ranges:
        return []

    merged_ranges = []
    sorted_ranges = sort_address_ranges(ranges)
    current_begin, current_end = sorted_ranges[0]

    for begin, end in sorted_ranges[1:]:
        if begin <= current_end:  # there is overlap or they are adjacent
            current_end = max(current_end, end)  # extend the current range
        else:
            # no overlap, push the current range and start a new one
            merged_ranges.append((current_begin, current_end))
            current_begin, current_end = begin, end

    # add the last range
    merged_ranges.append((current_begin, current_end))

    return merged_ranges


def is_address_in_address_ranges(address: int, ranges: list[tuple[int,int]]):
    for beg, end in ranges:
        if beg > address:
            # the ranges are sorted, so bail out fast
            break
        if beg <= address < end:
            return True
    return False


def dump_tasks_file(data: dict[int, ProcData], filename: str):
    # fields:
    # - magic
    # - command
    # - state    - unused
    # - uid      - unused
    # - pid      - unused
    # - spaceid
    # - tty      - unused
    # - flags    - unused
    # - cpu      - unused
    with open(filename, 'w', encoding='utf-8') as fh:
        # header
        fh.write('magic|command|state|uid|pid|spaceid|tty|flags|cpu\n')
        for proc_data in data.values():
            if proc_data.filename.startswith('Ct') or True:
                command = proc_data.filename
                space_id = f'0x{proc_data.space_id:04X}'
                fh.write(f'{proc_data.magic}|{command}|state|uid|{proc_data.pid}|{space_id}|tty|flags|cpu\n')


def check_elf_exists(elf_path: str, elf_dirs: list[str]):
    filename = os.path.basename(elf_path)
    if filename in missing_elfs:
        return

    files = set()
    for elf_dir in elf_dirs:
        for file, _, _ in au.Path.list_files(elf_dir, dirs=False, files=True):
            if not file.endswith('.symmap'):
                files.add(file)

    if filename not in files:
        suggestion = None
        for f in files:
            if f.startswith(filename) or filename.startswith(f):
                suggestion = f
                break
        missing_elfs[filename] = suggestion


def dump_mmap_files(data: dict[int, ProcData], out_mmap_file_prefix: str, out_mmap_file_suffix: str, elf_dirs: list[str]):
    def _get_prot_str(prot_val: str) -> str:
        prot_num = int(prot_val, base=16)
        res_prot_str = ''
        res_prot_str += 'r' if prot_num & 1 else '-'
        res_prot_str += 'w' if prot_num & 2 else '-'
        res_prot_str += 'x' if prot_num & 4 else '-'
        res_prot_str += 'p '
        return res_prot_str

    for proc_data in data.values():
        filename = f'{out_mmap_file_prefix}{proc_data.magic}{out_mmap_file_suffix}'
        if proc_data.filename.startswith('Ct') or True:
            with open(filename, 'w', encoding='utf-8') as fh:
                fh.write('magic___________|address_range_____________________|offset__________|perms|dev_|inode_______|pathname___\n')
                for e in proc_data.pmap_entries:
                    prot_str = _get_prot_str(e.prot)
                    end_addr = int(e.vaddr, base=16) + int(e.size, base=16) - 1
                    end_addr = f'{end_addr:016X}'
                    beg_addr = f'{int(e.vaddr, base=16):016X}'
                    offset = f'{int(e.offset, base=16):016X}'
                    device = f'{int(e.dev, base=16):04X}'
                    inode = f'{int(e.ino, base=16):12}'
                    fh.write(f'{proc_data.magic}|{beg_addr}--{end_addr}|{offset}|{prot_str}|{device}|{inode}|{e.path}\n')
                    check_elf_exists(e.path, elf_dirs)


def is_valid_tasks_map_path_entry(pathname: str) -> bool:
    if not pathname:
        return False
    if pathname.startswith('*'):
        return False
    if pathname.startswith('{'):
        return False
    if pathname.startswith('/dev/'):
        return False
    return True


def get_referenced_binaries(data: dict[int, ProcData]) -> set[str]:
    paths: set[str] = set()
    for proc_data in data.values():
        for pmap in proc_data.pmap_entries:
            if is_valid_tasks_map_path_entry(pmap.path):
                paths.add(pmap.path)
    return paths


def parse_mmaps(directory: str, log: logging.Logger) -> ProcessResult:
    global logger
    logger = log
    result = ProcessResult(file_magic_map={}, referenced_binaries=set())
    pattern = re.compile(r'task_maps_0x([0-9A-Fa-f]+)\.txt')
    for filename, filepath, _ in au.Path.list_files(directory, dirs=False, files=True):
        m = pattern.match(filename)
        if m:
            magic = m[1]
            line_num = 0
            for line in get_file_lines(filepath):
                tokens = line.split('|')
                line_num += 1
                if len(tokens) != 7:
                    logger.error(f'invalid task_maps line: {line}')
                    sys.exit(1)
                if line_num == 1:
                    continue
                pathname = tokens[6].strip()
                if not is_valid_tasks_map_path_entry(pathname):
                    continue
                result.referenced_binaries.add(pathname)
                elf_name = pathname
                elf_name = elf_name.split('/')[-1]
                elf_name = elf_name.split('\\')[-1]
                if elf_name not in result.file_magic_map:
                    result.file_magic_map[elf_name] = set()
                result.file_magic_map[elf_name].add(magic)
    return result


def process(target_tasks_file: str, target_pmap_file: str, target_mappings_file: str, elf_dirs: list[str], out_dir: str,
            log: logging.Logger) -> ProcessResult:
    global logger
    logger = log

    output_tasks_file = f'{out_dir}/tasks.txt'
    out_mmap_file_prefix = f'{out_dir}/task_maps_0x'
    out_mmap_file_suffix = '.txt'

    tasks = read_tasks_file(target_tasks_file)
    data: dict[int, ProcData] = dict()

    for task in tasks:
        proc_data = ProcData(
            pid=task.pid,
            space_id=task.space_id,
            magic=task.magic,
            command=task.name,
            filename=task.name.split('/')[-1])
        if task.pid in data:
            logger.error(f'Duplicate PID: {task.pid}')
            sys.exit(1)
        data[task.pid] = proc_data

    parse_pmap(data, target_pmap_file)
    parse_mappings(data, target_mappings_file)

    for pid in data.keys():
        proc_data = data[pid]
        proc_data.address_ranges = merge_address_ranges(get_mapped_address_ranges(
            [x for x in proc_data.mappings]))

    for x in data.values():
        logger.debug(f'pid: {x.pid}. magic: {x.magic}. file: {x.filename}. pmap_entries: {len(x.pmap_entries)}')
        for b, e in x.address_ranges:
            logger.debug(f'  {hex(b)} - {hex(e)}')

    dump_tasks_file(data, output_tasks_file)
    dump_mmap_files(data, out_mmap_file_prefix, out_mmap_file_suffix, elf_dirs)

    for elf_file, suggestion in missing_elfs.items():
        if suggestion:
            logger.warning(f'elf not found: {elf_file}. did you mean: {suggestion}')

    file_magic_map: dict[str, set[str]] = {}

    for proc_data in data.values():
        if proc_data.filename not in file_magic_map:
            file_magic_map[proc_data.filename] = set()
        file_magic_map[proc_data.filename].add(proc_data.magic)

    return ProcessResult(file_magic_map, get_referenced_binaries(data))


if __name__ == '__main__':
    logging.basicConfig(format='%(asctime)s.%(msecs)03d | %(levelname).1s | %(message)s',
                        datefmt="%H:%M:%S", level=logging.DEBUG)
    data_dir = 'C:/Users/User/Downloads/a53-1st-run-mdata'
    process(target_tasks_file=os.path.join(data_dir, 'target_qnx_tasks.txt'),
            target_pmap_file=os.path.join(data_dir, 'target_processes.pmap.txt'),
            target_mappings_file=os.path.join(data_dir, 'target_processes.mappings.txt'),
            elf_dirs=['C:/Playground/TTTechAuto/slice-data'],
            out_dir=f'{data_dir}/out',
            log=logging.getLogger('procmap'))
