"""
Trace Data Processor

Input data
- trace32 analyzer export data (*.ad file)
- process memory files
- binary files (ELF files and shared libraries)
1. Process the process memory files, and generate tasks.txt and task_maps_*.txt files
2. Process the stripped binaries and using angr generate *.symmap.csv files for them
3. Process the trace (*.ad) file with onguard and output csv file
4. Process the onguard generated csv file and update it with asm instructions
"""

import argparse
import csv
import dataclasses
import gc
import logging
import os.path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from concurrent.futures.process import ProcessPoolExecutor
from typing import Callable

import smart_open as so
import yaml
from capstone import *
from elftools.common.exceptions import ELFError
from elftools.elf.elffile import ELFFile

from . import asmslicer, elfgen, procmap, utility
from . import aws_utils as au
from .asmcache import ASMCache

# pylint: disable=broad-exception-caught
# pylint: disable=wrong-import-position
# pylint: disable=trailing-whitespace
# pylint: disable=global-statement
# pylint: disable=too-many-locals
# pylint: disable=too-many-lines


@dataclasses.dataclass
class ProcMapConfig:
    elf_dirs: list[str]
    target_tasks_file: str = ''
    target_pmap_file: str = ''
    target_mappings_file: str = ''
    task_maps_directory: str = ''
    excluded_elfs: set[str] = dataclasses.field(default_factory=set)


@dataclasses.dataclass
class Config:
    root_dir: str
    onguard: str
    architecture: str
    baremetal_trace: bool
    coresight_trace: bool
    proc_map: ProcMapConfig


class ELFProcInfo:
    def __init__(self, arch: int, mode: int, cache_path: str):
        self.elf_arch: int = arch
        self.elf_mode: int = mode
        self.elf_path: str = ''
        self.sym_path: str = ''
        self.dot_path: str = ''
        self.var_path: str = ''
        self.seg_path: str = ''
        self.blc_path: str = ''
        self.stripped: bool = False
        self.task_magics: set[str] = set()
        self.symbols: dict[str, str] = dict()
        self.cache_path: str = cache_path


class ELFScanInfo:
    def __init__(self, arch: int, mode: int, cache_path: str):
        self.elf_arch: int = arch
        self.elf_mode: int = mode
        self.task_magics: set[str] = set()
        self.elf_stripped: str = ''
        self.elf_non_stripped: str = ''
        self.map_path: str = ''
        self.cache_path: str = cache_path


@dataclasses.dataclass
class ELFSectionData:
    beg: int
    end: int
    data: bytes


class SlicerData:
    def __init__(self, sym_path: str, dot_path: str, var_path: str, seg_path: str, blc_path: str):
        self.sym_path = sym_path
        self.dot_path = dot_path
        self.var_path = var_path
        self.seg_path = seg_path
        self.blc_path = blc_path


class TraceDataProcessor:
    def __init__(self, config_path: str, trace_file: str, out_lite: str, out_full: str, temp_dir: str, keep_empty: bool,
                 jobs: int, clean: bool = False, dryrun: bool = False, recache: bool = False, recache_lite: bool = False, keep_temp: bool = False,
                 filter_functions: bool = True, analyse: bool = True, show_progress: bool = False, process_traces: bool = True,
                 out_elfs: bool = False, log: logging.Logger = None, include_elfs: list[str] = []):
        global logger
        self._jobs: int = jobs
        self._clean: bool = clean
        self._dryrun: bool = dryrun
        self._recache: bool = recache
        self._recache_lite: bool = recache_lite
        self._analyse: bool = analyse
        self._keep_temp: bool = keep_temp
        self._filter_functions: bool = filter_functions
        self._process_traces: bool = process_traces
        self._temp_path: str = temp_dir or os.path.join(tempfile.gettempdir(), f'tdp_{self._trace_name}_{time.time_ns():x}')
        self._config: Config = self._load_config(config_path, self._process_traces, self._temp_path)
        self._trace_file, self._trace_name = TraceDataProcessor._get_trace_paths(temp_dir=self._temp_path,
                                                                                 coresight_trace=self._config.coresight_trace,
                                                                                 trace_file=TraceDataProcessor._fix_path(self._config.root_dir, trace_file))
        self._out_full: str = au.Path.expanduser(out_full) if out_full else ''
        self._out_lite: str = au.Path.expanduser(out_lite) if out_lite else ''
        self._keep_empty: bool = keep_empty
        self._show_progress: bool = show_progress
        self._out_elfs: bool = out_elfs
        self._include_elfs: list[str] = include_elfs
        self._elf_infos: dict[str, ELFProcInfo] = {}
        self._counted_messages: dict[str, int] = {}
        self._process_result: procmap.ProcessResult = procmap.ProcessResult(dict(), set())
        self._asm_ins_cache: dict[str, str] = {}
        self._asm_cache: ASMCache = ASMCache(log=log)
        logger = log
        logger.info(f'temp: {self._temp_path}')


    def _load_symmaps(self):
        # loading post-processed symmaps
        for base_name in self._elf_infos.keys():
            if self._elf_infos[base_name].symbols:
                continue
            sym_path = self._elf_infos[base_name].sym_path
            if not au.Path.exists(sym_path):
                continue
            with so.open(sym_path, 'r') as csv_file:
                csv_reader = csv.reader(csv_file)
                for idx, row in enumerate(csv_reader):
                    if idx == 0:
                        if row[0] != 'name' or row[1] != 'long_name':
                            raise RuntimeError(f'invalid header: {sym_path}')
                        continue
                    self._elf_infos[base_name].symbols[row[1]] = row[0]


    def process(self):
        self._do_sanity_check()

        if self._dryrun:
            return

        target_dirs: list[str] = [x for x in [self._out_lite, self._out_full] if x]

        if not target_dirs:
            logger.info('no targets')

        self._create_out_dirs()
        self._create_temp_dirs()

        for target_dir in target_dirs:
            if self._clean:
                self._recreate_directory(target_dir)
            else:
                au.Path.makedirs(target_dir)

        if not self._config.coresight_trace and not self._config.baremetal_trace:
            procmap_logger = logging.getLogger('procmap')
            procmap_logger.setLevel(logger.level)
            if self._config.proc_map.task_maps_directory:
                logger.info('loading task mappings')
                self._process_result = procmap.parse_mmaps(directory=self._config.proc_map.task_maps_directory,
                                                        log=procmap_logger)
            else:
                # Process the process memory files, and generate tasks.txt and task_maps_*.txt files
                logger.info('generating task mappings')
                self._process_result = procmap.process(target_tasks_file=self._config.proc_map.target_tasks_file,
                                                    target_pmap_file=self._config.proc_map.target_pmap_file,
                                                    target_mappings_file=self._config.proc_map.target_mappings_file,
                                                    elf_dirs=self._config.proc_map.elf_dirs,
                                                    out_dir=self._get_tasks_temp_dir(),
                                                    log=procmap_logger)

        logger.info('copying elf files')
        self._copy_elf_files_to_temp()

        # Process binaries and generate *.symmap.csv, *.callgraph.dot, *.vars.csv, *.segments.csv files for them
        logger.info('generating slicer files')
        self._generate_all_slicer_files()

        # Process the trace (*.ad) file with onguard and output csv file
        if self._process_traces:
            self._copy_elfs_symmaps()
            logger.info('processing trace data')
            out_trace_csvs = self._process_trace_data()

        self._load_symmaps()

        if self._process_traces:
            # Process the onguard generated csv file and update it with asm instructions
            logger.info('generating output data')
            for csv_index, out_trace_csv, trace_id in out_trace_csvs:
                trace_name = self._trace_name if csv_index < 0 else f'{self._trace_name}_{trace_id if self._config.coresight_trace else csv_index}'
                self._generate_output_data(trace_name, out_trace_csv)

        self._copy_files_in_target_dirs()

        self._flush_counted_messages()
        self.cleanup()


    def cleanup(self):
        if self._keep_temp is not None:
            if not self._keep_temp:
                temp_dir = self._get_temp_dir()
                if os.path.isdir(temp_dir):
                    shutil.rmtree(temp_dir)
            self._keep_temp = None

        self._jobs = None
        self._clean = None
        self._dryrun = None
        self._recache = None
        self._recache_lite = None
        self._analyse = None
        self._filter_functions = None
        self._process_traces = None
        self._config = None
        self._trace_file = None
        self._trace_name = None
        self._temp_path = None
        self._out_full = None
        self._out_lite = None
        self._keep_empty = None
        self._show_progress = None
        self._out_elfs = None
        self._elf_infos = None
        self._counted_messages = None
        self._process_result = None
        self._asm_ins_cache = None
        self._asm_cache = None


    def _log_counted_message(self, message):
        if message in self._counted_messages:
            self._counted_messages[message] += 1
        else:
            self._counted_messages[message] = 1


    def _flush_counted_messages(self):
        messages = sorted([(x[1], x[0]) for x in self._counted_messages.items()], key=lambda n: n[0], reverse=True)
        for cnt, msg in messages:
            logger.warning(f'{cnt:6}: {msg}')
        self._counted_messages.clear()


    def _get_temp_dir(self, subdir: str = '') -> str:
        return os.path.join(self._temp_path, subdir) if subdir else self._temp_path


    def _get_elfs_temp_dir(self) -> str:
        return self._get_temp_dir(subdir='elfs')


    def _get_tasks_temp_dir(self) -> str:
        return self._get_temp_dir(subdir='tasks')


    def _get_symbols_temp_dir(self) -> str:
        return self._get_temp_dir(subdir='symbols')


    def _create_out_dirs(self):
        if self._out_lite:
            au.Path.makedirs(self._out_lite)
        if self._out_full:
            au.Path.makedirs(self._out_full)


    def _create_temp_dirs(self):
        if self._clean and os.path.isdir(self._get_temp_dir()):
            shutil.rmtree(self._get_temp_dir())
        os.makedirs(self._get_elfs_temp_dir(), exist_ok=True)
        os.makedirs(self._get_tasks_temp_dir(), exist_ok=True)
        os.makedirs(self._get_symbols_temp_dir(), exist_ok=True)


    @staticmethod
    def _fix_path(root: str, filename: str) -> str:
        if filename:
            if not au.Path.isabs(filename):
                filename = au.Path.expanduser(filename)
                if root and not au.Path.isabs(filename):
                    filename = f'{root}/{filename}'
        return filename


    @staticmethod
    def _load_config(filename: str, process_traces: bool, temp_dir: str) -> Config:
        filepath = au.Path.expanduser(filename)
        logger.info(f'config: {filepath}')

        def get_path(a_root: str, a_name: str, download: bool = False) -> str:
            path = TraceDataProcessor._fix_path(root=a_root, filename=a_name)
            if not path or not download:
                return path

            f = au.to_file(path)
            if isinstance(f, au.LocalFile):
                return path

            if au.Path.is_file(f):
                return au.download_file_s3(f, temp_dir, logger=logger).path

            local = au.Path.join(temp_dir, os.path.basename(au.Path.dirname(path)))
            if au.sync_s3_to_local(path, local, logger=logger):
                return local
            raise RuntimeError(f"Failed download file: {path}")

        with open(filepath, 'r', encoding='utf8') as fh:
            config_data = yaml.safe_load(fh)
            root_dir = au.Path.expanduser(config_data.get('root_dir', '.'))
            onguard = au.Path.expanduser(config_data['onguard']) if process_traces else ''
            proc_map = ProcMapConfig(**config_data['proc_map'])
            architecture = config_data.get('architecture', '')
            baremetal_trace = config_data.get('baremetal_trace', False)
            coresight_trace = config_data.get('coresight_trace', False)

            # Note: if any of the *_tasks, *_pmap and *_mappings files are S3 files, they will be directly read from there
            # while task_maps files will be locally generated. In case of present task_maps_directory, data will have to be
            # downloaded from the S3 source and used as such.
            proc_map.target_tasks_file = get_path(root_dir, proc_map.target_tasks_file)
            proc_map.target_pmap_file = get_path(root_dir, proc_map.target_pmap_file)
            proc_map.target_mappings_file = get_path(root_dir, proc_map.target_mappings_file)
            proc_map.task_maps_directory = get_path(root_dir, proc_map.task_maps_directory, download=True)
            for i in range(len(proc_map.elf_dirs)):
                proc_map.elf_dirs[i] = get_path(root_dir, proc_map.elf_dirs[i])
            proc_map.target_pmap_file = au.Path.expanduser(proc_map.target_pmap_file)
            proc_map.target_tasks_file = au.Path.expanduser(proc_map.target_tasks_file)
            proc_map.target_mappings_file = au.Path.expanduser(proc_map.target_mappings_file)
            return Config(root_dir=root_dir, onguard=onguard, architecture=architecture,
                          baremetal_trace=baremetal_trace, coresight_trace=coresight_trace, proc_map=proc_map)


    @staticmethod
    def _recreate_directory(directory: str):
        if au.Path.is_dir(directory):
            au.Path.rmtree(directory)
        au.Path.makedirs(directory)


    @staticmethod
    def _ensure_file_exists(filename: str):
        if not au.Path.is_file(filename):
            raise ValueError(f'file not found: {filename}')


    @staticmethod
    def _ensure_no_file(filename: str):
        if filename:
            raise ValueError(f'unexpected file set: {filename}')


    @staticmethod
    def _ensure_directory_exists(dir_uri: str):
        if not au.Path.is_dir(dir_uri):
            raise ValueError(f'directory not found: {dir_uri}')


    @staticmethod
    def _ensure_no_directory(directory: str):
        if directory:
            raise ValueError(f'unexpected directory set: {directory}')


    def _do_sanity_check(self):
        config = self._config

        if self._process_traces and not self._out_lite and not self._out_full:
            raise ValueError('no output directory set')

        if self._process_traces:
            if config.coresight_trace:
                self._ensure_directory_exists(self._trace_file)
            else:
                self._ensure_file_exists(self._trace_file)

        if config.coresight_trace:
            self._ensure_no_file(config.proc_map.target_tasks_file)
            self._ensure_no_file(config.proc_map.target_pmap_file)
            self._ensure_no_file(config.proc_map.target_mappings_file)
        elif config.baremetal_trace:
            self._ensure_no_file(config.proc_map.target_tasks_file)
            self._ensure_no_file(config.proc_map.target_pmap_file)
            self._ensure_no_file(config.proc_map.target_mappings_file)
        elif config.proc_map.task_maps_directory:
            self._ensure_no_file(config.proc_map.target_tasks_file)
            self._ensure_no_file(config.proc_map.target_pmap_file)
            self._ensure_no_file(config.proc_map.target_mappings_file)
            self._ensure_directory_exists(config.proc_map.task_maps_directory)
        else:
            self._ensure_file_exists(config.proc_map.target_tasks_file)
            self._ensure_file_exists(config.proc_map.target_pmap_file)
            self._ensure_file_exists(config.proc_map.target_mappings_file)
            self._ensure_no_directory(config.proc_map.task_maps_directory)

        for elf_dir in config.proc_map.elf_dirs:
            self._ensure_directory_exists(elf_dir)

        logger.info('sanity check: passed')


    @staticmethod
    def _get_filename(filepath: str, remove_extension: bool = False) -> str:
        if filepath:
            filename = filepath.strip()
            filename = filename.split('/')[-1]
            filename = filename.split('\\')[-1]
            if remove_extension:
                index = filename.rfind('.')
                if index > 0:
                    filename = filename[:index]
            return filename
        return filepath


    def _scan_elf_directories(self) -> dict[str, ELFScanInfo]:
        coresight: bool = self._config.coresight_trace
        baremetal: bool = self._config.baremetal_trace
        referenced: set[str] = set()
        if not coresight and not baremetal:
            for filepath in self._process_result.referenced_binaries:
                filename = self._get_filename(filepath)
                if filename:
                    referenced.add(filename)
        proc_names: set[str] = set()
        scan_infos: dict[str, ELFScanInfo] = dict()
        for directory in self._config.proc_map.elf_dirs:
            dir_cache = os.path.join(directory, '.cache/')
            cache_path = dir_cache if dir_cache and au.Path.is_dir(dir_cache) else None

            for filename, filepath, _ in au.Path.list_files(directory, dirs=False, files=True):
                if filepath in proc_names:
                    continue
                if self._include_elfs and filepath not in self._include_elfs:
                    continue
                proc_names.add(filepath)
                base_name = filename
                debug_suffix = '.debug'
                is_debug = filename.endswith(debug_suffix)
                if is_debug:
                    base_name = base_name[:-len(debug_suffix)]
                if not coresight and not baremetal and base_name not in referenced:
                    logger.info(f'discarding: {filepath}')
                    continue
                is_elf, is_stripped, elf_arch, elf_mode = self._check_file(filepath)
                if not is_elf:
                    continue
                if elf_arch == -1:
                    logger.error(f'unknown arch: {filepath}')
                    continue
                if elf_mode == -1:
                    logger.error(f'unknown mode: {filepath}')
                    continue
                task_magics = self._process_result.file_magic_map.get(base_name, set())
                if not task_magics:
                    logger.info(f'no magic: {filepath}')
                if base_name in self._config.proc_map.excluded_elfs:
                    continue
                if base_name not in scan_infos:
                    scan_infos[base_name] = ELFScanInfo(arch=elf_arch, mode=elf_mode, cache_path=cache_path)
                else:
                    prev_arch = scan_infos[base_name].elf_arch
                    prev_mode = scan_infos[base_name].elf_mode
                    if prev_arch != elf_arch:
                        raise RuntimeError(f'arch mismatch. {prev_arch} vs {elf_arch}. name: {base_name}')
                    if prev_mode != elf_mode:
                        raise RuntimeError(f'mode mismatch. {prev_mode} vs {elf_mode}. name: {base_name}')
                if task_magics:
                    scan_infos[base_name].task_magics = scan_infos[base_name].task_magics.union(task_magics)
                if is_stripped:
                    if scan_infos[base_name].elf_stripped:
                        raise RuntimeError(f'multiple stripped elfs: {base_name}')
                    scan_infos[base_name].elf_stripped = filepath
                else:
                    if scan_infos[base_name].elf_non_stripped:
                        raise RuntimeError(f'multiple non-stripped elfs: {base_name}')
                    scan_infos[base_name].elf_non_stripped = filepath
        for base_name in scan_infos.keys():
            if not isinstance(scan_infos[base_name], ELFScanInfo):
                continue
            if scan_infos[base_name].elf_non_stripped:
                continue
            if not scan_infos[base_name].elf_stripped:
                raise RuntimeError(f'elf without path: {base_name}')
            map_path = os.path.splitext(scan_infos[base_name].elf_stripped)[0] + '.map'
            if au.Path.is_file(map_path):
                scan_infos[base_name].map_path = map_path
        return scan_infos


    def _copy_elf_files_to_temp(self):
        def _gen_elf(elf_file: str, sym_file: str, out_file: str, gen_fn: Callable[[str, str, str, logging.Logger], bool]):
            elfgen_logger = logging.getLogger('elfgen')
            elfgen_logger.setLevel(logger.level)
            ef = au.to_file(elf_file)
            sf = au.to_file(sym_file)
            ef_iss3 = isinstance(ef, au.S3File)
            sf_iss3 = isinstance(sf, au.S3File)
            if ef_iss3 or sf_iss3:
                with tempfile.TemporaryDirectory() as temp:
                    el = au.download_file_s3(ef, temp).path if ef_iss3 else ef.path
                    sl = au.download_file_s3(sf, temp).path if sf_iss3 else sf.path
                    gen_fn(el, sl, out_file, elfgen_logger)
            else:
                gen_fn(elf_file, sym_file, out_file, elfgen_logger)
        temp_directory = self._get_elfs_temp_dir()
        for base_name, scan_info in self._scan_elf_directories().items():
            temp_path = os.path.join(temp_directory, base_name)
            stripped: bool = False
            if not os.path.isfile(temp_path):
                if scan_info.elf_stripped and scan_info.elf_non_stripped:
                    # create a new file from the stripped elf and the symbols from the non-stripped elf
                    logger.info(f'elf-gen: {base_name} (stripped + non-stripped)')
                    _gen_elf(elf_file=scan_info.elf_stripped, sym_file=scan_info.elf_non_stripped, out_file=temp_path, gen_fn=elfgen.generate_with_debug_elf)
                elif scan_info.elf_stripped and scan_info.map_path:
                    # create a new file from the stripped elf and the symbols from the map file
                    logger.info(f'elf-gen: {base_name} (stripped + map)')
                    _gen_elf(elf_file=scan_info.elf_stripped, sym_file=scan_info.map_path, out_file=temp_path, gen_fn=elfgen.generate_with_map_file)
                elif scan_info.elf_non_stripped:
                    logger.info(f'copying: {base_name} (non-stripped)')
                    au.copy_file(scan_info.elf_non_stripped, temp_path, logger=logger)
                elif scan_info.elf_stripped:
                    logger.info(f'copying: {base_name} (stripped)')
                    au.copy_file(scan_info.elf_stripped, temp_path, logger=logger)
                    stripped = True
                else:
                    raise RuntimeError(f'no elf file for {base_name}')
                if not os.path.isfile(temp_path):
                    raise RuntimeError(f'failed to create temp file: {base_name}')
            self._elf_infos[base_name] = ELFProcInfo(arch=scan_info.elf_arch, mode=scan_info.elf_mode, cache_path=scan_info.cache_path)
            self._elf_infos[base_name].elf_path = temp_path
            self._elf_infos[base_name].stripped = stripped


    @staticmethod
    def _is_identical_file(path_a: str, path_b: str) -> bool:
        chunk_size: int = 0x1000
        with open(path_a, 'rb') as file_a, open(path_b, 'rb') as file_b:
            while True:
                chunk_a = file_a.read(chunk_size)
                chunk_b = file_b.read(chunk_size)
                if not chunk_a and not chunk_b:
                    return True
                if chunk_a != chunk_b:
                    return False


    def _get_arch_and_mode(self, filepath: str):
        with so.open(filepath, 'rb') as fh:
            try:
                elf = ELFFile(fh)
                arch, mode, _skip, error = utility.get_arch_and_mode(elf=elf, architecture=self._config.architecture)
                if error:
                    raise RuntimeError(f'file: {filepath}. error: {error}')
                return arch, mode
            except ELFError:
                logger.warning(f'not elf: {filepath}')
                return None, None


    def _check_file(self, file_path):
        is_elf, is_stripped = utility.get_elf_info(file_path)
        elf_arch, elf_mode = self._get_arch_and_mode(file_path) if is_elf else (-1, -1)
        return is_elf, is_stripped, elf_arch, elf_mode


    def _generate_slicer_files(self, id_info: tuple[str, ELFProcInfo]) -> tuple[str, SlicerData]:
        base_name, info = id_info
        architecture = self._config.architecture

        try:
            cache_path = info.cache_path or utility.get_cache_dir(info.elf_path)
            cache_slc_path = os.path.join(cache_path, 'slicer')
            cache_cfg_path = os.path.join(cache_path, 'cfg')

            cache_slc_filename = utility.gen_slicer_file(info.elf_path, architecture, self._filter_functions)
            cache_cfg_filename = utility.gen_cfg_file(info.elf_path)

            logger.info(f'using cache: {cache_path}')
            logger.info(f'generate slicer files: {base_name}. hash: {cache_slc_filename}')
            logger.info(f'generate cfg files: {base_name}. hash: {cache_cfg_filename}')

            cache_sym_file = f'{cache_slc_path}/{cache_slc_filename}.sym'
            cache_dot_file = f'{cache_slc_path}/{cache_slc_filename}.dot'
            cache_var_file = f'{cache_slc_path}/{cache_slc_filename}.var'
            cache_seg_file = f'{cache_slc_path}/{cache_slc_filename}.seg'
            cache_blc_file = f'{cache_slc_path}/{cache_slc_filename}.blc'
            cache_cfg_file = f'{cache_cfg_path}/{cache_cfg_filename}'

            au.Path.makedirs(cache_slc_path, exist_ok=True)
            au.Path.makedirs(cache_cfg_path, exist_ok=True)

            if self._recache or self._recache_lite:
                if au.Path.exists(cache_sym_file):
                    au.Path.rm(cache_sym_file)
                if au.Path.exists(cache_dot_file):
                    au.Path.rm(cache_dot_file)
                if au.Path.exists(cache_var_file):
                    au.Path.rm(cache_var_file)
                if au.Path.exists(cache_seg_file):
                    au.Path.rm(cache_seg_file)
                if au.Path.exists(cache_blc_file):
                    au.Path.rm(cache_blc_file)
            if self._recache:
                if au.Path.exists(cache_cfg_file):
                    au.Path.rm(cache_cfg_file)

            common_path = os.path.join(self._get_symbols_temp_dir(), base_name)
            sym_file = f'{common_path}.symmap.csv'
            dot_file = f'{common_path}.callgraph.dot' if self._analyse else ''
            var_file = f'{common_path}.vars.csv' if (self._out_full or not self._process_traces) and self._analyse else ''
            seg_file = f'{common_path}.segments.csv' if self._out_full and self._analyse else ''
            blc_file = f'{common_path}.blocks.csv' if False and self._out_full and self._analyse else '' # don't generate blocks by default

            if self._dryrun:
                logger.info(f'generating sym: {sym_file} (dryrun)')
                if self._analyse:
                    logger.info(f'generating dot: {dot_file} (dryrun)')
                    if self._out_full:
                        logger.info(f'generating var: {var_file} (dryrun)')
                        logger.info(f'generating seg: {seg_file} (dryrun)')
                        if blc_file:
                            logger.info(f'generating blc: {blc_file} (dryrun)')
                return base_name, SlicerData(sym_path=sym_file,
                                             dot_path=dot_file,
                                             var_path=var_file,
                                             seg_path=seg_file,
                                             blc_path=blc_file)

            def should_generate_file(file: str, cache_file: str, gen_cfg: bool = False, file_type: str = '') -> bool:
                if not file:
                    return False
                if au.Path.exists(file) and not gen_cfg:
                    logger.debug(f'{file_type} exists: {file}')
                    return False
                if au.Path.exists(cache_file) and not gen_cfg:
                    logger.debug(f'{file_type} cached: {file}')
                    au.copy_file(cache_file, file, logger=logger)
                    return False
                return True

            gen_cfg = should_generate_file(cache_cfg_file, cache_cfg_file)
            gen_sym = should_generate_file(sym_file, cache_sym_file, gen_cfg, 'sym')
            gen_dot = should_generate_file(dot_file, cache_dot_file, gen_cfg, 'dot')
            gen_var = should_generate_file(var_file, cache_var_file, gen_cfg, 'var')
            gen_seg = should_generate_file(seg_file, cache_seg_file, gen_cfg, 'seg')
            gen_blc = should_generate_file(blc_file, cache_blc_file, gen_cfg, 'blc')

            if gen_sym or gen_dot or gen_var or gen_seg or gen_blc:
                gen_types: list[str] = []
                if gen_sym:
                    gen_types.append('sym')
                if gen_dot:
                    gen_types.append('dot')
                if gen_var:
                    gen_types.append('var')
                if gen_seg:
                    gen_types.append('seg')
                if gen_blc:
                    gen_types.append('blc')

                logger.info(f'generating: {cache_slc_filename}. types: {", ".join(gen_types)}. name: {base_name}')
                slicer_logger = logging.getLogger('slicer')
                slicer_logger.setLevel(logger.level)
                asmslicer.process(elf_file_path=info.elf_path,
                                  output_file_path=seg_file if gen_seg else None,
                                  blocks_file_path=blc_file if gen_blc else None,
                                  out_sym_map_file=sym_file if gen_sym else None,
                                  out_plot_file=dot_file if gen_dot else None,
                                  out_vars_file=var_file if gen_var else None,
                                  filter_functions=self._filter_functions,
                                  architecture=architecture,
                                  show_progress=self._show_progress,
                                  dump_cfg=gen_cfg and any([gen_sym, gen_var, gen_dot, gen_seg, gen_blc]),
                                  cfg_dir=cache_cfg_path,
                                  log=slicer_logger)

                if gen_sym and not au.Path.exists(sym_file):
                    raise RuntimeError(f'failed to generate sym: {sym_file}')

                if gen_dot and not au.Path.exists(dot_file):
                    raise RuntimeError(f'failed to generate dot: {dot_file}')

                if gen_var and not au.Path.exists(var_file):
                    raise RuntimeError(f'failed to generate var: {var_file}')

                if gen_seg and not au.Path.exists(seg_file):
                    raise RuntimeError(f'failed to generate seg: {seg_file}')

                if gen_blc and not os.path.isfile(blc_file):
                    raise RuntimeError(f'failed to generate blc: {blc_file}')

                if gen_sym:
                    au.copy_file(src=sym_file, dst=cache_sym_file)
                if gen_dot:
                    au.copy_file(src=dot_file, dst=cache_dot_file)
                if gen_var:
                    au.copy_file(src=var_file, dst=cache_var_file)
                if gen_seg:
                    au.copy_file(src=seg_file, dst=cache_seg_file)
                if gen_blc:
                    au.copy_file(src=blc_file, dst=cache_blc_file)

            return base_name, SlicerData(sym_path=sym_file,
                                         dot_path=dot_file,
                                         var_path=var_file,
                                         seg_path=seg_file,
                                         blc_path=blc_file)
        except asmslicer.ASMSlicerException as e:
            logger.error(e.message)
            sys.exit(e.error_code)
        except Exception as ex:
            logger.error(f'Traceback: {traceback.format_exc()}')
            raise RuntimeError(f'Failed generating symmap and dot files. Error: {ex}') from ex


    def _generate_all_slicer_files(self):
        if not self._elf_infos:
            return

        num_jobs: int|None = None

        if self._jobs > 0:
            num_jobs = min(self._jobs, len(self._elf_infos))

        name_info_list: list[tuple[str, ELFProcInfo]] = [(k, v) for k, v in self._elf_infos.items()]

        if len(name_info_list) > 1 and (num_jobs is None or num_jobs > 1):
            with ProcessPoolExecutor(max_workers=num_jobs) as executor:
                for base_name, slicer_data in executor.map(self._generate_slicer_files, name_info_list):
                    self._elf_infos[base_name].sym_path = slicer_data.sym_path
                    self._elf_infos[base_name].dot_path = slicer_data.dot_path
                    self._elf_infos[base_name].var_path = slicer_data.var_path
                    self._elf_infos[base_name].seg_path = slicer_data.seg_path
                    self._elf_infos[base_name].blc_path = slicer_data.blc_path
        else:
            for idx_name_pack in name_info_list:
                base_name, slicer_data = self._generate_slicer_files(idx_name_pack)
                self._elf_infos[base_name].sym_path = slicer_data.sym_path
                self._elf_infos[base_name].dot_path = slicer_data.dot_path
                self._elf_infos[base_name].var_path = slicer_data.var_path
                self._elf_infos[base_name].seg_path = slicer_data.seg_path
                self._elf_infos[base_name].blc_path = slicer_data.blc_path

        for base_name, info in self._elf_infos.items():
            if not info.sym_path or (self._analyse and not info.dot_path):
                raise RuntimeError(f'failed to generate slicer files for: {base_name}')


    def _copy_elfs_symmaps(self):
        elfs_temp = os.path.normpath(self._get_elfs_temp_dir())
        for info in self._elf_infos.values():
            src_file = info.sym_path
            dst_file: str = os.path.join(elfs_temp, os.path.basename(src_file))
            if not os.path.isfile(dst_file):
                au.copy_file(src_file, dst_file)


    @staticmethod
    def _get_trace_paths(trace_file: str, temp_dir: str, coresight_trace: bool) -> tuple[str, str]:
        if not trace_file:
            return '', ''

        f = au.to_file(trace_file)
        if isinstance(f, au.LocalFile):
            trace_name =  os.path.basename(os.path.dirname(trace_file)) if coresight_trace else TraceDataProcessor._get_filename(trace_file, remove_extension=True)
            return trace_file, trace_name

        if coresight_trace:
            trace_as_file = trace_file.rstrip('/') # _trace_file is directory in coresight traces
            dn = au.Path.dirname(trace_as_file).rstrip('/')
            bn = os.path.basename(dn)
            result = au.sync_s3_to_local(dn, os.path.join(temp_dir, bn), logger=logger)
            if not result:
                logger.error(f"Cannot download traces: {trace_file}")
                return
            trace_file = os.path.join(temp_dir, bn, 'cstrace.bin.merged')
            return trace_file, bn
        else:
            df = au.download_file_s3(f, temp_dir, logger=logger)
            trace_file = df.path
            return trace_file, TraceDataProcessor._get_filename(trace_file, remove_extension=True)


    def _copy_files_in_target_dirs(self):
        output_dir_name = 'symbols'
        out_lite: str = os.path.join(self._out_lite, output_dir_name) if self._out_lite else ''
        out_full: str = os.path.join(self._out_full, output_dir_name) if self._out_full else ''

        if out_lite:
            au.Path.makedirs(out_lite)
        if out_full:
            au.Path.makedirs(out_full)

        def copy_file_to_dir(src_file: str, dst_dir: str):
            if src_file and dst_dir:
                dst_dir = au.Path.abspath(dst_dir)
                dst_file: str = os.path.join(dst_dir, os.path.basename(src_file))
                if not au.Path.exists(dst_file):
                    au.copy_file(src_file, dst_file)
        for info in self._elf_infos.values():
            if self._out_elfs:
                copy_file_to_dir(info.elf_path, out_lite)
                copy_file_to_dir(info.elf_path, out_full)
            if self._analyse:
                copy_file_to_dir(info.sym_path, out_lite)
                copy_file_to_dir(info.sym_path, out_full)
            copy_file_to_dir(info.dot_path, out_lite)
            copy_file_to_dir(info.dot_path, out_full)
            copy_file_to_dir(info.var_path, out_full)
            copy_file_to_dir(info.seg_path, out_full)
            copy_file_to_dir(info.blc_path, out_full)


    def _has_elf_for_magic(self, magic: str) -> bool:
        for pack in self._elf_infos.values():
            if magic in pack.task_magics:
                return True
        return False


    def _get_files_for_magic(self, magic: str) -> list[str]:
        result: list[str] = []
        for filename, magics in self._process_result.file_magic_map.items():
            if magic in magics and filename not in result:
                result.append(filename)
        return result


    @staticmethod
    def get_task_maps_filenames(directory: str) -> list[str]:
        filenames: list[str] = []
        pattern = re.compile(r'task_maps_0x[0-9A-Fa-f]+\.txt')
        for filename, _, is_dir in au.Path.list_files(directory, dirs=False, files=True):
            if not is_dir and pattern.match(filename):
                filenames.append(filename)
        return filenames


    def _generate_onguard_sympaths(self, out_dir: str) -> dict[str, str]:
        sym_paths: dict[str, str] = {}
        for base_name, info in self._elf_infos.items():
            if not info.sym_path:
                continue
            sym_filename = base_name + '.sym'
            sym_file = os.path.join(out_dir, sym_filename)
            with so.open(info.sym_path, 'r', encoding='utf-8') as in_file:
                with open(sym_file, 'w', encoding='utf-8') as out_file:
                    csv_reader = csv.reader(in_file)
                    csv_writer = csv.writer(out_file)
                    for idx, row in enumerate(csv_reader):
                        if idx > 0:
                            csv_writer.writerow([row[1]])
            sym_paths[base_name] = sym_filename
        return sym_paths


    def _process_trace_data(self) -> list[tuple[int, str, str]]:
        output_dir = self._get_temp_dir()
        trace_csv: str = ''

        if not self._config.coresight_trace:
            trace_csv = os.path.normpath(os.path.join(self._get_temp_dir(), f'trace32_{self._trace_name}.csv'))

            if not os.path.isfile(trace_csv):
                logger.info(f'generating: {trace_csv}')
            elif self._clean:
                logger.info(f'regenerating: {trace_csv}')
                os.remove(trace_csv)
            else:
                logger.info(f'file exists: {trace_csv}')
                return [(-1, trace_csv, '')]

        onguard = self._config.onguard
        trace_file = self._trace_file

        tasks_dir = self._config.proc_map.task_maps_directory or self._get_tasks_temp_dir()
        tasks_file: str = os.path.join(tasks_dir, 'tasks.txt')
        map_files: list[str] = self.get_task_maps_filenames(tasks_dir)

        arch = ''
        if self._config.architecture:
            arch = self._config.architecture.lower()
            if arch not in [arch.value for arch in asmslicer.Architecture]:
                raise ValueError(f'unsupported provided architecture: {arch}')
        else:
            # auto-detect architecture from the elfs
            has_arm: bool = False
            has_tricore: bool = False

            for info in self._elf_infos.values():
                has_arm |= info.elf_arch in {CS_ARCH_ARM, CS_ARCH_ARM64}
                has_tricore |= info.elf_arch in {CS_ARCH_TRICORE}

            if has_arm and has_tricore:
                raise RuntimeError('mixed architectures')

            if has_arm:
                arch = 'arm'
            elif has_tricore:
                arch = 'tricore'
            else:
                raise RuntimeError('unsupported elf architecture')

        logger.info(f'architecture: {arch}')

        command = [onguard]

        if self._config.coresight_trace:
            command.extend(['parse'])
            command.extend(['--dump_csv_data'])
            command.extend(['--use_atoms'])
            command.extend(['--elfpath', self._get_elfs_temp_dir()])
            command.extend(['--offline_dir', trace_file])
        else:
            command.extend(['parse-trace32'])
            command.extend(['-i', trace_file])
            command.extend(['--no_json_data'])
            command.extend(['--metadata_root_dir', tasks_dir])
            command.extend(['--elfs_root_dir', self._get_elfs_temp_dir()])
            command.extend(['--elfpaths', ','.join(sorted(self._elf_infos))])
            command.extend(['--arch', arch])
            command.extend(['--exclude_idle_time'])
            if self._show_progress:
                command.append('--show_progress')

        command.extend(['--keep_dump_data'])
        command.extend(['--output_dir', output_dir])

        if self._filter_functions or self._config.coresight_trace:
            # create target symbol file for each elf in the meta directory
            sym_paths = self._generate_onguard_sympaths(out_dir=tasks_dir)
            if sym_paths:
                if self._config.coresight_trace:
                    command.extend(['--sympath', tasks_dir])
                else:
                    sym_paths_str = ','.join([f'{k}:{v}' for k, v in sym_paths.items()])
                    command.extend(['--sympaths', sym_paths_str])

        if self._out_full:
            command.extend(['--address_ranges', 'merged'])

        if self._config.coresight_trace:
            command.extend(['--no_wait_keypress'])
        elif self._config.baremetal_trace:
            command.extend(['--baremetal_trace'])
        else:
            command.extend(['--tasks_file', tasks_file])
            command.extend(['--mmap_files', ','.join(map_files)])

        command.extend(['--use_all_branches'])

        logger.info(f'onguard command: {" ".join(command)}')

        with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) as proc:
            # if not self._config.coresight_trace:
                # when processing coresight trace this gets stuck
                # for line in proc.stdout:
                    # logger.info(line.rstrip())

            stderr_output, _ = proc.communicate()
            if stderr_output:
                logger.error(stderr_output.rstrip())

            if proc.returncode is not None and proc.returncode != 0:
                raise RuntimeError(f'onguard failed. code: {proc.returncode}')

        if self._config.coresight_trace:
            csv_pattern = rf'csal_{self._trace_name}_(\d+)\.json_data\.csv'
            csv_data_dir: str = os.path.normpath(os.path.join(output_dir, 'dumps_json'))
            csv_files: list[tuple[int, str]] = [(re.search(csv_pattern, f).group(1), f) for f in os.listdir(csv_data_dir) if re.match(csv_pattern, f)]
            csv_files = sorted(csv_files, key=lambda x: x[0])
            csv_files = [(idx, os.path.normpath(os.path.abspath(os.path.join(csv_data_dir, x[1]))), x[0]) for idx, x in enumerate(csv_files)]
            return csv_files

        output_csv: str = os.path.normpath(os.path.join(output_dir, 'trace32.json_data.csv'))
        if not os.path.isfile(output_csv):
            raise RuntimeError(f'onguard failed. missing csv: {output_csv}')
        shutil.move(src=output_csv, dst=trace_csv)
        if not os.path.isfile(trace_csv):
            raise RuntimeError(f'move failed. missing csv: {trace_csv}')
        return [(-1, trace_csv, trace_file)]


    @staticmethod
    def _count_rows_in_csv(csv_file_path: str) -> int:
        with open(csv_file_path, 'r', encoding='utf-8') as csv_file:
            csv_reader = csv.reader(csv_file)
            return sum(1 for _ in csv_reader)


    def _get_short_name(self, elf_name: str, sym_name: str) -> str:
        info: ELFProcInfo | None = self._elf_infos.get(elf_name, None)
        if not info:
            if elf_name  == '_':
                return ' _ '
            raise RuntimeError(f'elf not found: {elf_name}')
        if sym_name not in info.symbols:
            if sym_name == '->' or sym_name == '@plt':
                return sym_name
            raise RuntimeError(f'symbol not found: {sym_name}. elf: {elf_name}')
        return info.symbols[sym_name]


    def _generate_output_data(self, trace_name: str, trace_csv: str):
        target_csv_lite: str = ''
        target_csv_full: str = ''

        if self._out_lite:
            target_csv_lite = os.path.join(self._out_lite, f'trace32_lite_{trace_name}.csv')

        if self._out_full:
            target_csv_full = os.path.join(self._out_full, f'trace32_full_{trace_name}.csv')

        if target_csv_lite and not target_csv_full:
            shutil.copyfile(src=trace_csv, dst=target_csv_lite)
            logger.info(f'csv_lite: {target_csv_lite}')
            return

        logger.info(f"Generate output data. Temp: {trace_csv}")

        total_rows = 0
        if self._show_progress:
            logger.info('counting number of rows')
            total_rows: int = TraceDataProcessor._count_rows_in_csv(trace_csv)
            logger.info(f'number of rows: {total_rows}')

        with open(trace_csv, 'r', encoding='utf-8') as csv_file:
            csv_reader = csv.reader(csv_file)

            csv_lite = so.open(target_csv_lite, 'w', encoding='utf-8') if target_csv_lite else None
            csv_full = so.open(target_csv_full, 'w', encoding='utf-8') if target_csv_full else None

            lite_writer = csv.writer(csv_lite) if csv_lite else None
            full_writer = csv.writer(csv_full) if csv_full else None

            csv_expected_header = [
                'r.prev_name',      #  0
                's1.name',          #  1
                's2.name',          #  2
                's1.container',     #  3
                's1.long_name',     #  4
                's2.container',     #  5
                's2.long_name',     #  6
                'r.dt',             #  7
                'r.delta_dt',       #  8
                'r.cyc',            #  9
                'r.prev_container', # 10
                'r.prev',           # 11
                'r.prev_delta_dt',  # 12
                'r.prev_cyc',       # 13
                'r.ctx_switch',     # 14
                'r.is_lbl',         # 15
                'r.type',           # 16
                'r.path_ids',       # 17
                'r.link_idx',       # 18
                'r.from_addr',      # 19
                'r.to_addr',        # 20
                'r.core_num',       # 21
            ]

            row_number = 0

            for row in csv_reader:
                row_number += 1
                if row_number == 1:
                    if csv_expected_header != row:
                        logger.error(f'invalid csv header: {", ".join(row)}')
                        break
                if row_number > 1:
                    if len(row) != 22:
                        logger.error(f"Length of csv row is: {len(row)}. Should be 22. Row: {row}. Terminating.")
                        raise ValueError("Invalid csv")
                    # update mangled names to short names where needed
                    prev_elf = row[10].split(':')[1].strip()
                    from_elf = row[3].split(':')[1].strip()
                    to_elf = row[5].split(':')[1].strip()
                    row[0] = self._get_short_name(prev_elf, row[11])
                    row[1] = self._get_short_name(from_elf, row[4])
                    row[2] = self._get_short_name(to_elf, row[6])
                if lite_writer:
                    lite_writer.writerow(row[:19] + row[21:])
                if full_writer:
                    if row_number == 1:
                        full_writer.writerow(row + ['r.asm'])
                    else:
                        elf_name = row[3].strip().split(':')[1]
                        from_addr = row[19].strip()
                        to_addr = row[20].strip()
                        has_addr = len(from_addr) > 0 and len(to_addr) > 0
                        asm_insn = self._get_asm_instructions(from_addr, to_addr, elf_name) if has_addr else ''
                        if not asm_insn:
                            if has_addr:
                                self._log_counted_message(f'elf: {elf_name}. no asm. range: {from_addr} - {to_addr}')
                            else:
                                self._log_counted_message(f'elf: {elf_name}. no asm. missing range')
                        if asm_insn or self._keep_empty:
                            full_writer.writerow(row + [asm_insn])
                if self._show_progress:
                    if row_number % 100_000 == 0:
                        logger.info(f'record: {row_number:,} / {total_rows:,}')

            if self._show_progress:
                logger.info(f'record: {row_number:,} / {total_rows:,}')

            if csv_lite:
                csv_lite.close()
                logger.info(f'csv_lite: {target_csv_lite}')

            if csv_full:
                csv_full.close()
                logger.info(f'csv_full: {target_csv_full}')
        return


    def _get_asm_instructions(self, from_address_str: str, to_address_str: str, elf_name: str) -> str:
        if len(from_address_str) == 0 or len(to_address_str) == 0:
            return ''

        ins_key = f'{elf_name}:{from_address_str}:{to_address_str}'
        cached_response = self._asm_ins_cache.get(ins_key, '')
        if cached_response:
            return cached_response

        asm: str = ''

        if elf_name not in self._elf_infos:
            self._asm_ins_cache[ins_key] = asm
            return asm

        info: ELFProcInfo = self._elf_infos[elf_name]

        for beg_str, end_str in zip(from_address_str.split('|'), to_address_str.split('|')):
            beg = int(beg_str, base=16)
            end = int(end_str, base=16)
            instructions = self._asm_cache.get_asm_instructions(
                elf_path=info.elf_path,
                arch=info.elf_arch,
                mode=info.elf_mode,
                start_addr=beg,
                end_addr=end,
                provided_architecture=self._config.architecture,
            )
            if instructions:
                if asm:
                    asm += '\n'
                asm += instructions

        self._asm_ins_cache[ins_key] = asm
        return asm


def process(config_path: str, trace_file: str, out_lite: str, out_full: str, temp_dir: str, keep_empty: bool,
                 jobs: int, clean: bool = False, dryrun: bool = False, recache: bool = False, recache_lite: bool = False,
                 keep_temp: bool = False, filter_functions: bool = True, analyse: bool = True, show_progress: bool = False,
                 process_traces: bool = True, log: logging.Logger = None, raise_exception: bool = False, include_elfs: list[str] = []):
    global logger
    logger = log

    processor = TraceDataProcessor(config_path=config_path,
                                   trace_file=trace_file,
                                   out_lite=out_lite,
                                   out_full=out_full,
                                   temp_dir=temp_dir,
                                   analyse=analyse,
                                   keep_empty=keep_empty,
                                   filter_functions=filter_functions,
                                   jobs=jobs,
                                   clean=clean,
                                   dryrun=dryrun,
                                   recache=recache,
                                   recache_lite=recache_lite,
                                   keep_temp=keep_temp,
                                   show_progress=show_progress,
                                   process_traces=process_traces,
                                   include_elfs=include_elfs,
                                   log=log)

    try:
        processor.process()
    except BaseException as ex:
        logger.error(ex)
        logger.error('Traceback: %s', traceback.format_exc())
        if raise_exception:
            processor.cleanup()
            raise ex
    finally:
        processor.cleanup()
        processor = None
        gc.collect()


def main(args, log: logging.Logger):
    global logger
    logger = log

    start_time = time.perf_counter()
    process(config_path=args.config,
            trace_file=args.trace,
            out_lite=args.out_lite,
            out_full=args.out_full,
            temp_dir=args.temp_dir,
            keep_empty=args.keep_empty,
            jobs=args.jobs,
            clean=args.clean,
            dryrun=args.dryrun,
            recache=args.recache,
            keep_temp=args.keep_temp,
            show_progress=args.progress,
            log=log)
    elapsed_time = time.perf_counter() - start_time
    logger.info(f'finished in {elapsed_time:.2f} seconds')


def parse_args():
    parser = argparse.ArgumentParser(prog='tdp', description='Trace Data Processor')
    parser.add_argument('-f', '--config', help='Config file')
    parser.add_argument('-x', '--trace', help='Trace file', type=str, required=True)
    parser.add_argument('-j', '--jobs', type=int, help='Maximum number of parallel tasks', default=1)
    parser.add_argument('-e', '--keep-empty', action='store_true', help='Keep lines with no ASM')
    parser.add_argument('-c', '--clean', action='store_true', help='Clean output directory')
    parser.add_argument('-d', '--dryrun', action='store_true', help='Dry run')
    parser.add_argument('-r', '--recache', action='store_true', help='Re-cache files')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose logging')
    parser.add_argument('-p', '--progress', action='store_true', help='Show progress')
    parser.add_argument('-m', '--keep-temp', action='store_true', help='Keep temporary data')
    parser.add_argument('--temp-dir', type=str, help='Temporary directory')
    parser.add_argument('--out-lite', type=str, help='Output directory for lite version')
    parser.add_argument('--out-full', type=str, help='Output directory for full version')
    parser.add_argument('-l', '--log', choices=['debug', 'info', 'warning', 'error', 'critical'],
                        default='warning', help='Logging level', type=lambda s: s.lower())
    return parser.parse_args()


if __name__ == '__main__':
    main_args = parse_args()
    LOG_FORMAT = '%(asctime)s.%(msecs)03d | %(name)-7s | %(levelname).1s | %(message)s' if not main_args.verbose else \
        '%(asctime)s.%(msecs)03d | %(name)-7s | %(levelname).1s | %(funcName)s | %(message)s'
    logging.basicConfig(format=LOG_FORMAT, datefmt="%H:%M:%S", force=True)
    logger = logging.getLogger('tdp')
    logger.setLevel(main_args.log.upper())
    main(main_args, log=logger)
